using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace HexBoxOverlay
{
    // =========================================================================
    //  RectSelInfo  矩形選択1件のデータ
    //
    //  矩形は「行番号(絶対) × 列番号」で保持する。
    //  ピクセル座標はスクロール時に変わるので、描画時に毎回再計算する。
    // =========================================================================
    public class RectSelInfo
    {
        // 絶対行番号（スクロールに依存しない）
        public int  StartRow    { get; private set; }
        public int  EndRow      { get; private set; }
        public int  StartCol    { get; private set; }
        public int  EndCol      { get; private set; }
        public int  BytesPerLine{ get; private set; }

        // 選択バイトの先頭・末尾オフセット（先頭行左端 ～ 末尾行右端）
        public long FirstOffset { get { return (long)StartRow * BytesPerLine + StartCol; } }
        public long LastOffset  { get { return (long)EndRow   * BytesPerLine + EndCol;   } }
        public long ByteCount   { get { return LastOffset - FirstOffset + 1; } }
        public int  RowCount    { get { return EndRow - StartRow + 1; } }
        public int  ColCount    { get { return EndCol - StartCol + 1; } }

        public RectSelInfo(int startRow, int startCol, int endRow, int endCol, int bpl)
        {
            StartRow    = Math.Min(startRow, endRow);
            EndRow      = Math.Max(startRow, endRow);
            StartCol    = Math.Min(startCol, endCol);
            EndCol      = Math.Max(startCol, endCol);
            BytesPerLine = bpl;
        }

        /// <summary>矩形内の全バイトオフセットを行ごとに返す</summary>
        public IEnumerable<long[]> GetRowOffsets()
        {
            for (int row = StartRow; row <= EndRow; row++)
            {
                List<long> rowOffs = new List<long>();
                for (int col = StartCol; col <= EndCol; col++)
                    rowOffs.Add((long)row * BytesPerLine + col);
                yield return rowOffs.ToArray();
            }
        }

        /// <summary>スクロール位置を考慮してこの矩形のピクセル矩形を計算する</summary>
        public Rectangle GetPixelRect(int hexLeft, int cellW, int lineH, int firstY, long scrollOffset)
        {
            int topLine = (int)(scrollOffset / BytesPerLine);
            int y0 = firstY + (StartRow - topLine) * lineH;
            int y1 = firstY + (EndRow   - topLine + 1) * lineH;
            int x0 = hexLeft + StartCol * cellW;
            int x1 = hexLeft + (EndCol + 1) * cellW - 2;
            return Rectangle.FromLTRB(x0, y0, x1, y1);
        }

        public bool IsVisible(long scrollOffset, int visibleLines)
        {
            int topLine = (int)(scrollOffset / BytesPerLine);
            return EndRow >= topLine && StartRow <= topLine + visibleLines;
        }
    }

    // =========================================================================
    //  OverlayHexBox
    //  Be.Windows.Forms.HexBox を継承し、OnPaint の後に矩形選択を上描きする。
    // =========================================================================
    public class OverlayHexBox : HexBox
    {
        // ----- レイアウト定数 (Courier New 9pt / 16列 / LineInfo+ColumnInfo あり) -----
        // ※ HexBox のフォントや設定を変えた場合は要調整
        private const int HEX_LEFT = 58;   // アドレス列の右端X
        private const int CELL_W   = 26;   // 1バイト分の幅
        private const int LINE_H   = 18;   // 1行の高さ
        private const int FIRST_Y  = 22;   // ColumnInfo ヘッダ分の高さ
        private const int BPL      = 16;

        // ----- 矩形選択の状態 -----
        private readonly List<RectSelInfo> _sels = new List<RectSelInfo>();
        private bool  _dragging;
        private Point _dragStart;
        private Point _dragNow;

        // ----- 色（視認性重視）-----
        // 半透明の明るい黄色で塗りつぶす → 暗背景でも明背景でも見える
        private static readonly Color C_Fill    = Color.FromArgb(120, 255, 220, 0);
        private static readonly Color C_Border  = Color.FromArgb(255, 255, 160, 0);
        private static readonly Color C_DFill   = Color.FromArgb(80,  200, 255, 100);
        private static readonly Color C_DBorder = Color.FromArgb(220, 100, 255, 100);
        private static readonly Color C_LblBg   = Color.FromArgb(230, 180, 100, 0);
        private static readonly Color C_LblFg   = Color.Black;

        public event EventHandler RectSelectionChanged;

        public IList<RectSelInfo> RectSelections
        {
            get { return _sels.AsReadOnly(); }
        }

        public OverlayHexBox()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.AllPaintingInWmPaint, true);
        }

        // --- スクロール位置（先頭表示バイト）取得 ---
        public long GetScrollOffset()
        {
            foreach (Control c in Controls)
            {
                VScrollBar v = c as VScrollBar;
                if (v != null) return (long)v.Value * BPL;
            }
            return 0;
        }

        private int GetVisibleLines()
        {
            return Math.Max(1, (ClientSize.Height - FIRST_Y) / LINE_H) + 1;
        }

        // ピクセル座標 → 絶対行・列番号
        private void PixelToRowCol(Point pt, out int row, out int col)
        {
            long scroll = GetScrollOffset();
            int topLine = (int)(scroll / BPL);
            int relY = pt.Y - FIRST_Y;
            int relX = pt.X - HEX_LEFT;
            row = topLine + Math.Max(0, relY / LINE_H);
            col = Math.Max(0, Math.Min(relX / CELL_W, BPL - 1));
        }

        // --- 矩形選択クリア ---
        public void ClearRectSelections()
        {
            _sels.Clear();
            Invalidate();
            if (RectSelectionChanged != null)
                RectSelectionChanged(this, EventArgs.Empty);
        }

        // ---- OnPaint: HexBox の描画後に矩形を上描き ----
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            PaintOverlay(e.Graphics);
        }

        private void PaintOverlay(Graphics g)
        {
            long scroll    = GetScrollOffset();
            int  visLines  = GetVisibleLines();

            using (SolidBrush fb  = new SolidBrush(C_Fill))
            using (Pen        bp  = new Pen(C_Border, 2.5f))
            using (SolidBrush lbg = new SolidBrush(C_LblBg))
            using (SolidBrush lfg = new SolidBrush(C_LblFg))
            using (Font       lf  = new Font("Courier New", 7.5f, FontStyle.Bold))
            {
                for (int i = 0; i < _sels.Count; i++)
                {
                    RectSelInfo s = _sels[i];
                    if (!s.IsVisible(scroll, visLines)) continue;

                    Rectangle pr = s.GetPixelRect(HEX_LEFT, CELL_W, LINE_H, FIRST_Y, scroll);

                    // クリップして画面外にはみ出さないようにする
                    Rectangle clipped = Rectangle.Intersect(pr,
                        new Rectangle(0, FIRST_Y, ClientSize.Width, ClientSize.Height - FIRST_Y));
                    if (clipped.IsEmpty) continue;

                    g.FillRectangle(fb, clipped);
                    g.DrawRectangle(bp, pr);    // 枠線は元のサイズで描く

                    // ラベル
                    string lbl = string.Format(
                        "[{0}] 0x{1:X4}-0x{2:X4}  {3}行×{4}列={5}bytes",
                        i + 1, s.FirstOffset, s.LastOffset,
                        s.RowCount, s.ColCount, s.RowCount * s.ColCount);
                    SizeF  sz = g.MeasureString(lbl, lf);
                    float  lx = pr.X;
                    float  ly = pr.Y - sz.Height - 3f;
                    if (ly < FIRST_Y) ly = pr.Bottom + 2f;
                    if (lx + sz.Width > ClientSize.Width)
                        lx = ClientSize.Width - sz.Width - 4f;
                    RectangleF lr = new RectangleF(lx, ly, sz.Width + 4f, sz.Height + 2f);
                    g.FillRectangle(lbg, lr);
                    g.DrawString(lbl, lf, lfg, new PointF(lr.X + 2f, lr.Y + 1f));
                }
            }

            // ドラッグ中
            if (_dragging)
            {
                Rectangle dr = Norm(_dragStart, _dragNow);
                using (SolidBrush df = new SolidBrush(C_DFill))
                using (Pen        dp = new Pen(C_DBorder, 2f))
                {
                    dp.DashStyle = DashStyle.Dash;
                    g.FillRectangle(df, dr);
                    g.DrawRectangle(dp, dr);
                }
            }
        }

        // ---- マウス操作 (Alt+ドラッグ で矩形選択) ----
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left &&
                (ModifierKeys & Keys.Alt) == Keys.Alt)
            {
                _dragging  = true;
                _dragStart = e.Location;
                _dragNow   = e.Location;
                if ((ModifierKeys & Keys.Control) == 0)
                    _sels.Clear();
                Invalidate();
                return;
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_dragging)
            {
                _dragNow = e.Location;
                Invalidate();
                return;
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_dragging && e.Button == MouseButtons.Left)
            {
                _dragging = false;
                _dragNow  = e.Location;

                int r0, c0, r1, c1;
                PixelToRowCol(_dragStart, out r0, out c0);
                PixelToRowCol(_dragNow,   out r1, out c1);

                // 最小1セル以上のドラッグを選択として確定
                if (Math.Abs(_dragNow.X - _dragStart.X) > 4 ||
                    Math.Abs(_dragNow.Y - _dragStart.Y) > 4)
                {
                    RectSelInfo info = new RectSelInfo(r0, c0, r1, c1, BPL);
                    _sels.Add(info);
                    if (RectSelectionChanged != null)
                        RectSelectionChanged(this, EventArgs.Empty);
                }
                Invalidate();
                return;
            }
            base.OnMouseUp(e);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            Invalidate();
        }

        // --- Tab区切り・改行コードでクリップボードにコピー ---
        public void CopyRectSelectionsToClipboard()
        {
            if (_sels.Count == 0 || ByteProvider == null) return;

            StringBuilder sb = new StringBuilder();
            for (int si = 0; si < _sels.Count; si++)
            {
                RectSelInfo sel = _sels[si];
                if (si > 0) sb.AppendLine(); // 複数選択は空行で区切る

                foreach (long[] rowOffs in sel.GetRowOffsets())
                {
                    for (int ci = 0; ci < rowOffs.Length; ci++)
                    {
                        long off = rowOffs[ci];
                        if (off >= 0 && off < ByteProvider.Length)
                            sb.Append(ByteProvider.ReadByte(off).ToString("X2"));
                        else
                            sb.Append("--");

                        if (ci < rowOffs.Length - 1)
                            sb.Append('\t'); // 列区切り：Tab
                    }
                    sb.AppendLine(); // 行区切り：改行
                }
            }

            try
            {
                Clipboard.SetText(sb.ToString());
            }
            catch { }
        }

        private static Rectangle Norm(Point a, Point b)
        {
            return Rectangle.FromLTRB(
                Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
                Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
        }
    }

    // =========================================================================
    //  MainForm
    // =========================================================================
    public class MainForm : Form
    {
        private OverlayHexBox _hexBox;
        private Panel         _sidePanel;
        private ListBox       _selList;
        private Label         _statusLabel;
        private ToolStrip     _toolStrip;

        public MainForm()
        {
            InitializeComponent();
            LoadSampleData();
        }

        private void InitializeComponent()
        {
            this.Text          = "HexBox 矩形選択 - アプローチ① (Be.Windows.Forms.HexBox 1.6.1)";
            this.Size          = new Size(1100, 700);
            this.MinimumSize   = new Size(900, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("MS UI Gothic", 9f);

            // ---- ToolStrip ----
            _toolStrip      = new ToolStrip();
            _toolStrip.Dock = DockStyle.Top;

            ToolStripButton btnOpen = new ToolStripButton("ファイルを開く");
            btnOpen.Click += new EventHandler(BtnOpen_Click);

            ToolStripButton btnClear = new ToolStripButton("矩形選択クリア");
            btnClear.Click += new EventHandler(BtnClear_Click);

            ToolStripButton btnSample = new ToolStripButton("サンプルデータ読込");
            btnSample.Click += new EventHandler(BtnSample_Click);

            ToolStripButton btnCopy = new ToolStripButton("矩形選択をコピー (Tab/改行)");
            btnCopy.Click += new EventHandler(BtnCopy_Click);

            _toolStrip.Items.Add(btnOpen);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnSample);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnClear);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnCopy);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(new ToolStripLabel(
                "  【矩形選択】Alt+ドラッグ  Ctrl+Alt+ドラッグ:追加  " +
                "Ctrl+C:コピー(Tab/改行)"));

            // ---- ステータスバー ----
            _statusLabel           = new Label();
            _statusLabel.Dock      = DockStyle.Bottom;
            _statusLabel.Height    = 24;
            _statusLabel.BackColor = Color.FromArgb(0, 100, 0);
            _statusLabel.ForeColor = Color.White;
            _statusLabel.Font      = new Font("Courier New", 8.5f);
            _statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            _statusLabel.Padding   = new Padding(8, 0, 0, 0);
            _statusLabel.Text      = "Alt+ドラッグで矩形選択。Ctrl+Alt+ドラッグで複数追加。";

            // ---- サイドパネル ----
            _sidePanel           = new Panel();
            _sidePanel.Dock      = DockStyle.Right;
            _sidePanel.Width     = 300;
            _sidePanel.BackColor = Color.FromArgb(40, 40, 50);
            _sidePanel.Padding   = new Padding(6);

            Label lblTitle = new Label();
            lblTitle.Text      = "矩形選択リスト";
            lblTitle.Dock      = DockStyle.Top;
            lblTitle.ForeColor = Color.LightSkyBlue;
            lblTitle.Font      = new Font("MS UI Gothic", 10f, FontStyle.Bold);
            lblTitle.Height    = 28;

            _selList             = new ListBox();
            _selList.Dock        = DockStyle.Fill;
            _selList.BackColor   = Color.FromArgb(25, 25, 35);
            _selList.ForeColor   = Color.LightGreen;
            _selList.Font        = new Font("Courier New", 8f);
            _selList.BorderStyle = BorderStyle.None;

            Label lblNote = new Label();
            lblNote.Text      = "Ctrl+C または「矩形選択をコピー」ボタンで\nTsv形式(Tab/改行)でコピーできます";
            lblNote.Dock      = DockStyle.Bottom;
            lblNote.ForeColor = Color.LightYellow;
            lblNote.Font      = new Font("MS UI Gothic", 8f);
            lblNote.Height    = 40;

            _sidePanel.Controls.Add(_selList);
            _sidePanel.Controls.Add(lblTitle);
            _sidePanel.Controls.Add(lblNote);

            // ---- OverlayHexBox ----
            _hexBox = new OverlayHexBox();
            _hexBox.Dock                 = DockStyle.Fill;
            _hexBox.Font                 = new Font("Courier New", 9f);
            _hexBox.BytesPerLine         = 16;
            _hexBox.UseFixedBytesPerLine = true;
            _hexBox.VScrollBarVisible    = true;
            _hexBox.ColumnInfoVisible    = true;
            _hexBox.LineInfoVisible      = true;
            _hexBox.StringViewVisible    = true;
            _hexBox.BackColor            = Color.FromArgb(30, 30, 30);
            _hexBox.ForeColor            = Color.FromArgb(200, 230, 200);
            _hexBox.SelectionBackColor   = Color.FromArgb(80, 100, 180);
            _hexBox.SelectionForeColor   = Color.White;
            _hexBox.InfoForeColor        = Color.FromArgb(120, 120, 160);
            _hexBox.RectSelectionChanged += new EventHandler(HexBox_RectSelectionChanged);
            // Ctrl+C をフォームレベルで捕捉
            _hexBox.KeyDown += new KeyEventHandler(HexBox_KeyDown);

            // フォームへ追加（順序: Top→Bottom→Right→Fill）
            this.Controls.Add(_hexBox);
            this.Controls.Add(_sidePanel);
            this.Controls.Add(_statusLabel);
            this.Controls.Add(_toolStrip);
        }

        // ================================================================
        //  イベントハンドラ
        // ================================================================
        private void HexBox_RectSelectionChanged(object sender, EventArgs e)
        {
            UpdateSelList();
        }

        private void HexBox_KeyDown(object sender, KeyEventArgs e)
        {
            // Ctrl+C で矩形選択コピー（矩形選択がある場合のみ）
            if (e.Control && e.KeyCode == Keys.C &&
                _hexBox.RectSelections.Count > 0)
            {
                _hexBox.CopyRectSelectionsToClipboard();
                _statusLabel.Text = "クリップボードにコピーしました（TSV形式: Tab区切り/改行）";
                e.SuppressKeyPress = true; // HexBox デフォルトのコピーを抑制
            }
        }

        private void UpdateSelList()
        {
            _selList.Items.Clear();
            IList<RectSelInfo> sels = _hexBox.RectSelections;
            for (int i = 0; i < sels.Count; i++)
            {
                RectSelInfo s = sels[i];
                _selList.Items.Add(string.Format(
                    "[{0}] 0x{1:X4}～0x{2:X4}  {3}行×{4}列 ({5}bytes)",
                    i + 1, s.FirstOffset, s.LastOffset,
                    s.RowCount, s.ColCount, s.RowCount * s.ColCount));
            }
            if (_selList.Items.Count > 0)
                _selList.SelectedIndex = _selList.Items.Count - 1;

            if (sels.Count > 0)
            {
                RectSelInfo last = sels[sels.Count - 1];
                _statusLabel.Text = string.Format(
                    "矩形選択: 0x{0:X4}～0x{1:X4}  {2}行×{3}列={4}bytes  " +
                    "| Ctrl+C または「矩形選択をコピー」でTSV形式コピー",
                    last.FirstOffset, last.LastOffset,
                    last.RowCount, last.ColCount, last.RowCount * last.ColCount);
            }
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title  = "バイナリファイルを開く";
            dlg.Filter = "すべてのファイル (*.*)|*.*";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                _hexBox.ByteProvider = new DynamicFileByteProvider(dlg.FileName);
                _hexBox.ClearRectSelections();
                _selList.Items.Clear();
                FileInfo fi = new FileInfo(dlg.FileName);
                _statusLabel.Text = string.Format("読込完了: {0}  ({1:N0} bytes)",
                    dlg.FileName, fi.Length);
            }
            catch (Exception ex)
            {
                MessageBox.Show("読込エラー:\n" + ex.Message, "エラー",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            _hexBox.ClearRectSelections();
            _selList.Items.Clear();
            _statusLabel.Text = "矩形選択をクリアしました";
        }

        private void BtnSample_Click(object sender, EventArgs e)
        {
            LoadSampleData();
        }

        private void BtnCopy_Click(object sender, EventArgs e)
        {
            if (_hexBox.RectSelections.Count == 0)
            {
                _statusLabel.Text = "矩形選択がありません。Alt+ドラッグで選択してください。";
                return;
            }
            _hexBox.CopyRectSelectionsToClipboard();
            _statusLabel.Text = "クリップボードにコピーしました（TSV形式: Tab区切り/改行）";
        }

        private void LoadSampleData()
        {
            byte[] data = new byte[512];
            data[0]  = 0x89; data[1]  = 0x50; data[2]  = 0x4E; data[3]  = 0x47;
            data[4]  = 0x0D; data[5]  = 0x0A; data[6]  = 0x1A; data[7]  = 0x0A;
            data[8]  = 0x00; data[9]  = 0x00; data[10] = 0x00; data[11] = 0x0D;
            data[12] = 0x49; data[13] = 0x48; data[14] = 0x44; data[15] = 0x52;
            for (int i = 16; i < data.Length; i++)
                data[i] = (byte)(i & 0xFF);

            _hexBox.ByteProvider = new DynamicByteProvider(data);
            _hexBox.ClearRectSelections();
            _selList.Items.Clear();
            _statusLabel.Text = string.Format(
                "サンプルデータ ({0}bytes)。Alt+ドラッグで矩形選択してください。",
                data.Length);
        }
    }
}
