using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace HexBoxOverlay
{
    // =========================================================================
    //  RectSelInfo  矩形選択1件のデータ
    // =========================================================================
    public class RectSelInfo
    {
        public Rectangle PixelRect   { get; private set; }
        public long      StartOffset { get; private set; }
        public long      EndOffset   { get; private set; }
        public long      ByteCount   { get; private set; }

        public RectSelInfo(Rectangle px, int hexLeft, int cellW, int lineH,
                            int bpl, int firstY, long scroll)
        {
            PixelRect = px;
            int c0 = Math.Max(0, Math.Min((px.Left  - hexLeft) / cellW, bpl - 1));
            int c1 = Math.Max(0, Math.Min((px.Right - hexLeft) / cellW, bpl - 1));
            int r0 = Math.Max(0, (px.Top    - firstY) / lineH);
            int r1 = Math.Max(0, (px.Bottom - firstY) / lineH);
            StartOffset = scroll + (long)r0 * bpl + c0;
            EndOffset   = scroll + (long)r1 * bpl + c1;
            ByteCount   = Math.Max(1L, EndOffset - StartOffset + 1L);
        }
    }

    // =========================================================================
    //  OverlayHexBox
    //  Be.Windows.Forms.HexBox を継承し、OnPaint の後に矩形選択を上描きする。
    //  透明パネルの重ね合わせは一切使わない。
    //  マウスイベントもこのクラス自身で処理する。
    // =========================================================================
    public class OverlayHexBox : HexBox
    {
        // ----- レイアウト定数 (Courier New 9pt / 16列 実測値) -----
        private const int HEX_LEFT   = 58;
        private const int CELL_W     = 26;
        private const int LINE_H     = 18;
        private const int FIRST_Y    = 4;
        private const int BPL        = 16;

        // ----- 矩形選択の状態 -----
        private readonly List<RectSelInfo> _sels = new List<RectSelInfo>();
        private bool  _dragging;
        private Point _dragStart;
        private Point _dragNow;

        // ----- 色 -----
        private static readonly Color C_Fill    = Color.FromArgb(70, 0, 120, 255);
        private static readonly Color C_Border  = Color.FromArgb(220, 0, 80, 200);
        private static readonly Color C_DFill   = Color.FromArgb(50, 0, 160, 255);
        private static readonly Color C_DBorder = Color.FromArgb(200, 0, 100, 220);
        private static readonly Color C_LblBg   = Color.FromArgb(200, 0, 60, 150);

        public event EventHandler SelectionChanged;

        public IList<RectSelInfo> RectSelections
        {
            get { return _sels.AsReadOnly(); }
        }

        public OverlayHexBox()
        {
            // ダブルバッファを有効にして自前描画のちらつきを防ぐ
            SetStyle(ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.AllPaintingInWmPaint, true);
        }

        // --- スクロール位置取得 ---
        private long GetScrollOffset()
        {
            foreach (Control c in Controls)
            {
                VScrollBar v = c as VScrollBar;
                if (v != null) return (long)v.Value * BPL;
            }
            return 0;
        }

        // --- 矩形選択をクリア ---
        public void ClearRectSelections()
        {
            _sels.Clear();
            Invalidate();
            if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
        }

        // ---- OnPaint: HexBox の描画後に矩形を上描き ----
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);          // ← Be.HexBox 本来の描画
            PaintOverlay(e.Graphics); // ← 矩形を重ねて描く
        }

        private void PaintOverlay(Graphics g)
        {
            using (SolidBrush fb  = new SolidBrush(C_Fill))
            using (Pen        bp  = new Pen(C_Border, 2f))
            using (SolidBrush lbg = new SolidBrush(C_LblBg))
            using (SolidBrush lfg = new SolidBrush(Color.White))
            using (Font       lf  = new Font("Courier New", 7.5f, FontStyle.Bold))
            {
                for (int i = 0; i < _sels.Count; i++)
                {
                    RectSelInfo s = _sels[i];
                    g.FillRectangle(fb, s.PixelRect);
                    g.DrawRectangle(bp, s.PixelRect);

                    string lbl = string.Format("[{0}] 0x{1:X4}-0x{2:X4} ({3}bytes)",
                        i + 1, s.StartOffset, s.EndOffset, s.ByteCount);
                    SizeF  sz  = g.MeasureString(lbl, lf);
                    float  ly  = s.PixelRect.Y - sz.Height - 2f;
                    if (ly < 0) ly = s.PixelRect.Bottom + 2f;
                    RectangleF lr = new RectangleF(s.PixelRect.X, ly, sz.Width + 4f, sz.Height + 2f);
                    g.FillRectangle(lbg, lr);
                    g.DrawString(lbl, lf, lfg, new PointF(lr.X + 2f, lr.Y + 1f));
                }
            }

            // ドラッグ中のリアルタイム矩形
            if (_dragging)
            {
                Rectangle dr = Norm(_dragStart, _dragNow);
                using (SolidBrush df = new SolidBrush(C_DFill))
                using (Pen        dp = new Pen(C_DBorder, 1.5f))
                {
                    dp.DashStyle = DashStyle.Dash;
                    g.FillRectangle(df, dr);
                    g.DrawRectangle(dp, dr);
                }
            }
        }

        // ---- マウス操作 ----
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left &&
                (ModifierKeys & Keys.Alt) == Keys.Alt)
            {
                // Alt+ドラッグ で矩形選択モード
                _dragging  = true;
                _dragStart = e.Location;
                _dragNow   = e.Location;
                if ((ModifierKeys & Keys.Control) == 0)
                    _sels.Clear();
                // base を呼ばない → HexBoxの線形選択を開始させない
                Invalidate();
                return;
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_dragging)
            {
                _dragNow = e.Location;
                Invalidate();
                return;
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_dragging && e.Button == MouseButtons.Left)
            {
                _dragging = false;
                _dragNow  = e.Location;
                Rectangle rect = Norm(_dragStart, _dragNow);
                if (rect.Width > 4 && rect.Height > 4)
                {
                    RectSelInfo info = new RectSelInfo(
                        rect, HEX_LEFT, CELL_W, LINE_H, BPL, FIRST_Y,
                        GetScrollOffset());
                    _sels.Add(info);
                    if (SelectionChanged != null)
                        SelectionChanged(this, EventArgs.Empty);
                }
                Invalidate();
                return;
            }
            base.OnMouseUp(e);
        }

        // マウスホイールでスクロール後に再描画
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            Invalidate();
        }

        private static Rectangle Norm(Point a, Point b)
        {
            return Rectangle.FromLTRB(
                Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
                Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
        }
    }

    // =========================================================================
    //  MainForm
    // =========================================================================
    public class MainForm : Form
    {
        private OverlayHexBox _hexBox;
        private Panel         _sidePanel;
        private ListBox       _selList;
        private Label         _statusLabel;
        private ToolStrip     _toolStrip;

        private const int BPL = 16;

        public MainForm()
        {
            InitializeComponent();
            LoadSampleData();
        }

        private void InitializeComponent()
        {
            this.Text          = "HexBox 矩形選択 - アプローチ① オーバーレイ (Be.Windows.Forms.HexBox 1.6.1)";
            this.Size          = new Size(1100, 700);
            this.MinimumSize   = new Size(900, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("MS UI Gothic", 9f);

            // ---- ToolStrip ----
            _toolStrip      = new ToolStrip();
            _toolStrip.Dock = DockStyle.Top;

            ToolStripButton btnOpen = new ToolStripButton("ファイルを開く");
            btnOpen.Click += new EventHandler(BtnOpen_Click);

            ToolStripButton btnClear = new ToolStripButton("矩形選択クリア");
            btnClear.Click += new EventHandler(BtnClear_Click);

            ToolStripButton btnSample = new ToolStripButton("サンプルデータ読込");
            btnSample.Click += new EventHandler(BtnSample_Click);

            _toolStrip.Items.Add(btnOpen);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnClear);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnSample);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(new ToolStripLabel(
                "  【矩形選択】Alt+ドラッグ  / Ctrl+Alt+ドラッグ:追加  " +
                "【通常選択】そのままドラッグ"));

            // ---- ステータスバー ----
            _statusLabel           = new Label();
            _statusLabel.Dock      = DockStyle.Bottom;
            _statusLabel.Height    = 24;
            _statusLabel.BackColor = Color.FromArgb(0, 100, 0);
            _statusLabel.ForeColor = Color.White;
            _statusLabel.Font      = new Font("Courier New", 8.5f);
            _statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            _statusLabel.Padding   = new Padding(8, 0, 0, 0);
            _statusLabel.Text      = "Alt+ドラッグで矩形選択。Ctrl+Alt+ドラッグで複数追加。";

            // ---- サイドパネル ----
            _sidePanel           = new Panel();
            _sidePanel.Dock      = DockStyle.Right;
            _sidePanel.Width     = 280;
            _sidePanel.BackColor = Color.FromArgb(40, 40, 50);
            _sidePanel.Padding   = new Padding(6);

            Label lblTitle = new Label();
            lblTitle.Text      = "矩形選択リスト";
            lblTitle.Dock      = DockStyle.Top;
            lblTitle.ForeColor = Color.LightSkyBlue;
            lblTitle.Font      = new Font("MS UI Gothic", 10f, FontStyle.Bold);
            lblTitle.Height    = 28;

            _selList             = new ListBox();
            _selList.Dock        = DockStyle.Fill;
            _selList.BackColor   = Color.FromArgb(25, 25, 35);
            _selList.ForeColor   = Color.LightGreen;
            _selList.Font        = new Font("Courier New", 8f);
            _selList.BorderStyle = BorderStyle.None;
            _selList.SelectedIndexChanged += new EventHandler(SelList_SelectedIndexChanged);

            Label lblNote = new Label();
            lblNote.Text      = "※ リスト選択でHexBoxの\n  線形選択に反映します";
            lblNote.Dock      = DockStyle.Bottom;
            lblNote.ForeColor = Color.Gray;
            lblNote.Font      = new Font("MS UI Gothic", 8f);
            lblNote.Height    = 36;

            _sidePanel.Controls.Add(_selList);
            _sidePanel.Controls.Add(lblTitle);
            _sidePanel.Controls.Add(lblNote);

            // ---- OverlayHexBox ----
            _hexBox = new OverlayHexBox();
            _hexBox.Dock                 = DockStyle.Fill;
            _hexBox.Font                 = new Font("Courier New", 9f);
            _hexBox.BytesPerLine         = BPL;
            _hexBox.UseFixedBytesPerLine = true;
            _hexBox.VScrollBarVisible    = true;
            _hexBox.ColumnInfoVisible    = true;
            _hexBox.LineInfoVisible      = true;
            _hexBox.StringViewVisible    = true;
            _hexBox.BackColor            = Color.FromArgb(30, 30, 30);
            _hexBox.ForeColor            = Color.FromArgb(200, 230, 200);
            _hexBox.SelectionBackColor   = Color.FromArgb(80, 100, 180);
            _hexBox.SelectionForeColor   = Color.White;
            _hexBox.InfoForeColor        = Color.FromArgb(120, 120, 160);
            _hexBox.SelectionChanged    += new EventHandler(HexBox_SelectionChanged);

            // ---- フォームへ追加（順序が重要: Top→Bottom→Right→Fill）----
            this.Controls.Add(_hexBox);      // Fill（最初に追加すると最背面）
            this.Controls.Add(_sidePanel);   // Right
            this.Controls.Add(_statusLabel); // Bottom
            this.Controls.Add(_toolStrip);   // Top
        }

        // ================================================================
        //  イベントハンドラ
        // ================================================================
        private void HexBox_SelectionChanged(object sender, EventArgs e)
        {
            UpdateSelList();
        }

        private void UpdateSelList()
        {
            _selList.Items.Clear();
            IList<RectSelInfo> sels = _hexBox.RectSelections;
            for (int i = 0; i < sels.Count; i++)
            {
                RectSelInfo s = sels[i];
                _selList.Items.Add(string.Format(
                    "[{0}] 0x{1:X4}～0x{2:X4} ({3}bytes)",
                    i + 1, s.StartOffset, s.EndOffset, s.ByteCount));
            }
            if (_selList.Items.Count > 0)
                _selList.SelectedIndex = _selList.Items.Count - 1;

            if (sels.Count > 0)
            {
                RectSelInfo last = sels[sels.Count - 1];
                _statusLabel.Text = string.Format(
                    "矩形選択確定: 0x{0:X4} ～ 0x{1:X4}  ({2} bytes)",
                    last.StartOffset, last.EndOffset, last.ByteCount);
                try
                {
                    _hexBox.SelectionStart  = last.StartOffset;
                    _hexBox.SelectionLength = last.ByteCount;
                }
                catch { }
            }
        }

        private void SelList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = _selList.SelectedIndex;
            IList<RectSelInfo> sels = _hexBox.RectSelections;
            if (idx < 0 || idx >= sels.Count) return;
            RectSelInfo s = sels[idx];
            try
            {
                _hexBox.SelectionStart  = s.StartOffset;
                _hexBox.SelectionLength = s.ByteCount;
            }
            catch { }
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title  = "バイナリファイルを開く";
            dlg.Filter = "すべてのファイル (*.*)|*.*";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                _hexBox.ByteProvider = new DynamicFileByteProvider(dlg.FileName);
                _hexBox.ClearRectSelections();
                _selList.Items.Clear();
                FileInfo fi = new FileInfo(dlg.FileName);
                _statusLabel.Text = string.Format("読込完了: {0}  ({1:N0} bytes)",
                    dlg.FileName, fi.Length);
            }
            catch (Exception ex)
            {
                MessageBox.Show("読込エラー:\n" + ex.Message, "エラー",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            _hexBox.ClearRectSelections();
            _selList.Items.Clear();
            _statusLabel.Text = "矩形選択をクリアしました";
        }

        private void BtnSample_Click(object sender, EventArgs e)
        {
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            byte[] data = new byte[512];
            data[0]  = 0x89; data[1]  = 0x50; data[2]  = 0x4E; data[3]  = 0x47;
            data[4]  = 0x0D; data[5]  = 0x0A; data[6]  = 0x1A; data[7]  = 0x0A;
            data[8]  = 0x00; data[9]  = 0x00; data[10] = 0x00; data[11] = 0x0D;
            data[12] = 0x49; data[13] = 0x48; data[14] = 0x44; data[15] = 0x52;
            for (int i = 16; i < data.Length; i++)
                data[i] = (byte)(i & 0xFF);

            _hexBox.ByteProvider = new DynamicByteProvider(data);
            _hexBox.ClearRectSelections();
            _selList.Items.Clear();
            _statusLabel.Text = string.Format(
                "サンプルデータ ({0}bytes)。Alt+ドラッグで矩形選択してください。",
                data.Length);
        }
    }
}
