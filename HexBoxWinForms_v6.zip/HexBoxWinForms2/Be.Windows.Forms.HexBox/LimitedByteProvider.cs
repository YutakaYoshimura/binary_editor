using System;
using System.Collections.Generic;

namespace Be.Windows.Forms
{
    /// <summary>
    /// 最大バイト数（行数 × BytesPerLine）で入力を制限する ByteProvider。
    /// DynamicByteProvider を継承し、SupportsInsertBytes() で上限チェックを行う。
    /// HexBox.cs / DynamicByteProvider.cs の改修は不要。
    /// </summary>
    /// <example>
    /// // 1行8バイト × 1行 = 最大8バイトに制限する例
    /// var provider = new LimitedByteProvider(new byte[0], maxLines: 1, bytesPerLine: 8);
    /// hexBox.BytesPerLine = 8;
    /// hexBox.UseFixedBytesPerLine = true;
    /// hexBox.ByteProvider = provider;
    /// </example>
    public class LimitedByteProvider : DynamicByteProvider
    {
        private readonly long _maxBytes;

        /// <summary>
        /// コンストラクタ（byte配列版）
        /// </summary>
        /// <param name="data">初期バイトデータ</param>
        /// <param name="maxLines">最大行数</param>
        /// <param name="bytesPerLine">1行あたりのバイト数（HexBox.BytesPerLine と合わせること）</param>
        public LimitedByteProvider(byte[] data, int maxLines, int bytesPerLine)
            : base(data)
        {
            if (maxLines <= 0)    throw new ArgumentOutOfRangeException("maxLines",    "1以上を指定してください。");
            if (bytesPerLine <= 0) throw new ArgumentOutOfRangeException("bytesPerLine", "1以上を指定してください。");
            _maxBytes = (long)maxLines * bytesPerLine;
        }

        /// <summary>
        /// コンストラクタ（List版）
        /// </summary>
        public LimitedByteProvider(List<byte> bytes, int maxLines, int bytesPerLine)
            : base(bytes)
        {
            if (maxLines <= 0)    throw new ArgumentOutOfRangeException("maxLines",    "1以上を指定してください。");
            if (bytesPerLine <= 0) throw new ArgumentOutOfRangeException("bytesPerLine", "1以上を指定してください。");
            _maxBytes = (long)maxLines * bytesPerLine;
        }

        /// <summary>許容する最大バイト数</summary>
        public long MaxBytes { get { return _maxBytes; } }

        /// <summary>
        /// 上限に達していない場合のみ true を返す。
        /// HexBox はこれが false のとき挿入入力を自動的に拒否する。
        /// </summary>
        public override bool SupportsInsertBytes()
        {
            return Length < _maxBytes;
        }
    }
}
