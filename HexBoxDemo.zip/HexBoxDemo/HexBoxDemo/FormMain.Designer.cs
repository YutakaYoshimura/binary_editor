namespace HexBoxDemo
{
    partial class FormMain
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel  _panelHexBox;
        private System.Windows.Forms.GroupBox _groupHex;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this._panelBottom   = new System.Windows.Forms.Panel();
            this._lblStatus     = new System.Windows.Forms.Label();
            this._lblInfo       = new System.Windows.Forms.Label();
            this._btnClear      = new System.Windows.Forms.Button();
            this._btnShowBytes  = new System.Windows.Forms.Button();
            this._panelHexBox   = new System.Windows.Forms.Panel();
            this._groupHex      = new System.Windows.Forms.GroupBox();

            this._panelBottom.SuspendLayout();
            this._groupHex.SuspendLayout();
            this.SuspendLayout();

            // ---- _lblInfo ----
            this._lblInfo.AutoSize  = true;
            this._lblInfo.Font      = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this._lblInfo.ForeColor = System.Drawing.Color.Navy;
            this._lblInfo.Location  = new System.Drawing.Point(12, 14);
            this._lblInfo.Text      = "制限: 1行 × 8バイト = 最大 8バイトまで入力できます";

            // ---- _groupHex ----
            this._groupHex.Text     = "HexBox（入力制限あり）";
            this._groupHex.Font     = new System.Drawing.Font("Meiryo UI", 9f);
            this._groupHex.Location = new System.Drawing.Point(12, 40);
            this._groupHex.Size     = new System.Drawing.Size(560, 100);
            this._groupHex.Controls.Add(this._panelHexBox);

            // ---- _panelHexBox ----
            this._panelHexBox.Dock    = System.Windows.Forms.DockStyle.Fill;
            this._panelHexBox.Padding = new System.Windows.Forms.Padding(8);

            // ---- _panelBottom ----
            this._panelBottom.Location = new System.Drawing.Point(0, 155);
            this._panelBottom.Size     = new System.Drawing.Size(596, 80);
            this._panelBottom.Controls.Add(this._lblStatus);
            this._panelBottom.Controls.Add(this._btnClear);
            this._panelBottom.Controls.Add(this._btnShowBytes);

            // ---- _lblStatus ----
            this._lblStatus.AutoSize  = false;
            this._lblStatus.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._lblStatus.Location  = new System.Drawing.Point(12, 10);
            this._lblStatus.Size      = new System.Drawing.Size(560, 24);
            this._lblStatus.Text      = "入力バイト数: 0 / 8 バイト";

            // ---- _btnClear ----
            this._btnClear.Text     = "クリア";
            this._btnClear.Font     = new System.Drawing.Font("Meiryo UI", 9f);
            this._btnClear.Location = new System.Drawing.Point(12, 40);
            this._btnClear.Size     = new System.Drawing.Size(100, 28);
            this._btnClear.Click   += new System.EventHandler(this.BtnClear_Click);

            // ---- _btnShowBytes ----
            this._btnShowBytes.Text     = "バイトデータ確認";
            this._btnShowBytes.Font     = new System.Drawing.Font("Meiryo UI", 9f);
            this._btnShowBytes.Location = new System.Drawing.Point(120, 40);
            this._btnShowBytes.Size     = new System.Drawing.Size(140, 28);
            this._btnShowBytes.Click   += new System.EventHandler(this.BtnShowBytes_Click);

            // ---- FormMain ----
            this.Text            = "HexBox 入力制限デモ（1行8バイト）";
            this.Font            = new System.Drawing.Font("Meiryo UI", 9f);
            this.ClientSize      = new System.Drawing.Size(596, 250);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Controls.Add(this._lblInfo);
            this.Controls.Add(this._groupHex);
            this.Controls.Add(this._panelBottom);

            this._panelBottom.ResumeLayout(false);
            this._groupHex.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
