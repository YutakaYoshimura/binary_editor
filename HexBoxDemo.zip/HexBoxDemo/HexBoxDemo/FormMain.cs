using System;
using System.Drawing;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace HexBoxDemo
{
    /// <summary>
    /// LimitedByteProvider を使って 1行8バイト（最大8バイト）に制限した
    /// HexBox デモフォーム。
    /// </summary>
    public partial class FormMain : Form
    {
        // 定数：1行8バイト × 1行 = 最大8バイト
        private const int BYTES_PER_LINE = 8;
        private const int MAX_LINES      = 1;

        private HexBox           _hexBox;
        private LimitedByteProvider _provider;
        private Label            _lblStatus;
        private Label            _lblInfo;
        private Button           _btnClear;
        private Button           _btnShowBytes;
        private Panel            _panelBottom;

        public FormMain()
        {
            InitializeComponent();
            InitHexBox();
        }

        // -------------------------------------------------------
        // HexBox 初期化
        // -------------------------------------------------------
        private void InitHexBox()
        {
            // --- LimitedByteProvider：1行8バイト × 1行 ---
            _provider = new LimitedByteProvider(new byte[0], MAX_LINES, BYTES_PER_LINE);
            _provider.Changed       += Provider_Changed;
            _provider.LengthChanged += Provider_Changed;

            // --- HexBox 設定 ---
            _hexBox = new HexBox
            {
                ByteProvider        = _provider,
                BytesPerLine        = BYTES_PER_LINE,
                UseFixedBytesPerLine= true,
                VScrollBarVisible   = false,
                LineInfoVisible     = true,
                StringViewVisible   = true,
                ColumnInfoVisible   = true,
                GroupSize           = 1,
                Font                = new Font("Courier New", 10f),
                BackColor           = Color.White,
                Dock                = DockStyle.Fill,
            };

            _panelHexBox.Controls.Add(_hexBox);
            UpdateStatus();
        }

        // -------------------------------------------------------
        // バイト数ステータスの更新
        // -------------------------------------------------------
        private void UpdateStatus()
        {
            long current = _provider.Length;
            long max     = _provider.MaxBytes;
            _lblStatus.Text = string.Format(
                "入力バイト数: {0} / {1} バイト　（残り {2} バイト）",
                current, max, max - current);

            // 上限に達したら警告表示
            if (current >= max)
            {
                _lblStatus.ForeColor = Color.Red;
                _lblStatus.Text += "　※上限に達しました";
            }
            else
            {
                _lblStatus.ForeColor = SystemColors.ControlText;
            }
        }

        private void Provider_Changed(object sender, EventArgs e)
        {
            UpdateStatus();
        }

        // -------------------------------------------------------
        // クリアボタン
        // -------------------------------------------------------
        private void BtnClear_Click(object sender, EventArgs e)
        {
            _provider = new LimitedByteProvider(new byte[0], MAX_LINES, BYTES_PER_LINE);
            _provider.Changed       += Provider_Changed;
            _provider.LengthChanged += Provider_Changed;
            _hexBox.ByteProvider     = _provider;
            UpdateStatus();
        }

        // -------------------------------------------------------
        // 現在のバイト列を表示
        // -------------------------------------------------------
        private void BtnShowBytes_Click(object sender, EventArgs e)
        {
            if (_provider.Length == 0)
            {
                MessageBox.Show("データが入力されていません。", "確認",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var sb = new System.Text.StringBuilder();
            sb.AppendLine(string.Format("バイト数: {0}", _provider.Length));
            sb.AppendLine();
            sb.Append("16進数: ");
            for (int i = 0; i < _provider.Length; i++)
            {
                if (i > 0) sb.Append(" ");
                sb.Append(_provider.ReadByte(i).ToString("X2"));
            }
            sb.AppendLine();
            sb.Append("10進数: ");
            for (int i = 0; i < _provider.Length; i++)
            {
                if (i > 0) sb.Append(", ");
                sb.Append(_provider.ReadByte(i).ToString());
            }

            MessageBox.Show(sb.ToString(), "現在のバイトデータ",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
