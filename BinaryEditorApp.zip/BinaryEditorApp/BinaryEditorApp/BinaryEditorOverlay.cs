using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
// ElementHost は WindowsFormsIntegration.dll に含まれる
// csproj に <Reference Include="WindowsFormsIntegration" /> が必要
using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    /// <summary>
    /// DataGridViewのセル上にWPFHexEditorをオーバーレイ表示するコントロール。
    /// テキストセルの上に重ねてバイナリ編集を可能にする。
    /// キー操作:
    ///   F2 / Ctrl+Enter  → 確定
    ///   Esc              → キャンセル
    /// </summary>
    public class BinaryEditorOverlay : UserControl
    {
        // ---- フィールド --------------------------------------------------------

        /// <summary>WPFコントロールをWinFormsに載せるホスト（WindowsFormsIntegration.dll）</summary>
        private ElementHost _elementHost;

        /// <summary>WPFHexaEditorコントロール本体</summary>
        private WpfHexaEditor.HexEditor _hexEditor;

        /// <summary>編集開始時に渡された元バイト（キャンセル用）</summary>
        private byte[] _originalBytes;

        /// <summary>現在エディタが保持しているMemoryStream</summary>
        private MemoryStream _editStream;

        // ---- イベント ----------------------------------------------------------

        /// <summary>F2/Ctrl+Enter/フォーカス喪失で確定されたとき</summary>
        public event EventHandler<BinaryEditCompletedEventArgs> EditCompleted;

        /// <summary>Escキーでキャンセルされたとき</summary>
        public event EventHandler EditCancelled;

        // ---- コンストラクタ ----------------------------------------------------

        public BinaryEditorOverlay()
        {
            InitializeOverlay();
        }

        // ---- 初期化 ------------------------------------------------------------

        private void InitializeOverlay()
        {
            this.SuspendLayout();

            this.BorderStyle = BorderStyle.FixedSingle;
            this.BackColor   = Color.White;
            this.KeyPreview  = true;

            // --- ElementHost ---
            _elementHost      = new ElementHost();
            _elementHost.Dock = DockStyle.Fill;

            // --- WPFHexaEditor ---
            _hexEditor              = new WpfHexaEditor.HexEditor();
            _hexEditor.ReadOnlyMode = false;

            // 外観（コンパイルエラーになるプロパティは最低限に絞る）
            _hexEditor.Background = System.Windows.Media.Brushes.White;
            _hexEditor.Foreground = System.Windows.Media.Brushes.Black;

            _elementHost.Child = _hexEditor;
            this.Controls.Add(_elementHost);

            // --- イベント ---
            this.KeyDown += OnKeyDown;
            this.Leave   += OnLeave;

            this.ResumeLayout(false);
        }

        // ---- 公開メソッド ------------------------------------------------------

        /// <summary>編集対象バイト配列をセットしてエディタを初期化する</summary>
        public void SetBytes(byte[] bytes)
        {
            if (bytes == null) bytes = new byte[0];

            // 元データを保持（キャンセル時に戻せるよう）
            _originalBytes = new byte[bytes.Length];
            Array.Copy(bytes, _originalBytes, bytes.Length);

            // 前回のストリームを破棄
            _editStream?.Dispose();

            // コピーをMemoryStreamに流し込んでHexEditorに渡す
            _editStream        = new MemoryStream(bytes.Length);
            _editStream.Write(bytes, 0, bytes.Length);
            _editStream.Position = 0;
            _hexEditor.Stream  = _editStream;
        }

        /// <summary>現在エディタが保持するバイト配列を取得する</summary>
        public byte[] GetBytes()
        {
            if (_editStream == null)
                return _originalBytes ?? new byte[0];

            return _editStream.ToArray();
        }

        /// <summary>編集を確定してイベントを発火し、オーバーレイを非表示にする</summary>
        public void CommitEdit()
        {
            var result = GetBytes();
            EditCompleted?.Invoke(this, new BinaryEditCompletedEventArgs(result));
            HideOverlay();
        }

        /// <summary>編集をキャンセルしてオーバーレイを非表示にする</summary>
        public void CancelEdit()
        {
            EditCancelled?.Invoke(this, EventArgs.Empty);
            HideOverlay();
        }

        // ---- 内部メソッド ------------------------------------------------------

        private void HideOverlay()
        {
            this.Visible = false;
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                e.Handled = true;
                CancelEdit();
            }
            else if (e.KeyCode == Keys.F2 || (e.Control && e.KeyCode == Keys.Enter))
            {
                e.Handled = true;
                CommitEdit();
            }
        }

        private void OnLeave(object sender, EventArgs e)
        {
            // 子コントロール（HexEditor内部WPF要素）へのフォーカス移動は除外
            if (!this.ContainsFocus)
            {
                CommitEdit();
            }
        }

        // ---- Dispose -----------------------------------------------------------

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _editStream?.Dispose();
                _elementHost?.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // ---------------------------------------------------------------------------

    /// <summary>バイナリ編集完了イベントの引数</summary>
    public class BinaryEditCompletedEventArgs : EventArgs
    {
        public byte[] EditedBytes { get; }

        public BinaryEditCompletedEventArgs(byte[] editedBytes)
        {
            EditedBytes = editedBytes;
        }
    }
}
