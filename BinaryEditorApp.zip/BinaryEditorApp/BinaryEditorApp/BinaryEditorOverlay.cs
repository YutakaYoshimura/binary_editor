using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    /// <summary>
    /// DataGridViewのセル上にWPFHexEditorをオーバーレイ表示するコントロール
    /// テキストコントロールに重ねてバイナリ編集を可能にする
    /// </summary>
    public class BinaryEditorOverlay : UserControl
    {
        // WPF ElementHost (WinFormsにWPFコントロールを埋め込む)
        private ElementHost _elementHost;

        // WPFHexEditorコントロール
        private WpfHexaEditor.HexEditor _hexEditor;

        // 編集完了イベント
        public event EventHandler<BinaryEditCompletedEventArgs> EditCompleted;

        // 編集キャンセルイベント
        public event EventHandler EditCancelled;

        // 現在編集中のバイトデータ
        private byte[] _editingBytes;

        public BinaryEditorOverlay()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // コントロールの基本設定
            this.BorderStyle = BorderStyle.FixedSingle;
            this.BackColor = Color.White;

            // ElementHostの作成（WPFコントロールのホスト）
            _elementHost = new ElementHost();
            _elementHost.Dock = DockStyle.Fill;

            // WPFHexEditorの作成と設定
            _hexEditor = new WpfHexaEditor.HexEditor();
            _hexEditor.ReadOnlyMode = false;
            _hexEditor.AllowDrop = false;
            // HexEditorの外観設定
            _hexEditor.Background = System.Windows.Media.Brushes.White;
            _hexEditor.Foreground = System.Windows.Media.Brushes.Black;
            _hexEditor.HighLightColor = System.Windows.Media.Brushes.LightBlue;
            _hexEditor.ByteModifiedColor = System.Windows.Media.Brushes.Orange;
            _hexEditor.SelectionStartByteColor = System.Windows.Media.Brushes.DodgerBlue;

            // データ変更イベントのハンドリング
            _hexEditor.BytesDeleted += HexEditor_BytesChanged;
            _hexEditor.BytesModified += HexEditor_BytesChanged;

            _elementHost.Child = _hexEditor;
            this.Controls.Add(_elementHost);

            // キーイベントの設定（ESCキーでキャンセル、Enterキーで確定）
            this.KeyDown += BinaryEditorOverlay_KeyDown;
            this.KeyPreview = true;

            // フォーカス喪失時の処理
            this.Leave += BinaryEditorOverlay_Leave;

            this.ResumeLayout(false);
        }

        /// <summary>
        /// 編集対象のバイト配列をセットしてエディタを初期化する
        /// </summary>
        public void SetBytes(byte[] bytes)
        {
            if (bytes == null) bytes = new byte[0];

            _editingBytes = new byte[bytes.Length];
            Array.Copy(bytes, _editingBytes, bytes.Length);

            // HexEditorにデータをセット
            var stream = new System.IO.MemoryStream(_editingBytes);
            _hexEditor.Stream = stream;
        }

        /// <summary>
        /// 現在エディタに表示されているバイト配列を取得する
        /// </summary>
        public byte[] GetBytes()
        {
            if (_hexEditor.Stream == null)
                return _editingBytes ?? new byte[0];

            // HexEditorの変更を反映して取得
            var stream = _hexEditor.Stream as System.IO.MemoryStream;
            if (stream != null)
            {
                return stream.ToArray();
            }
            return _editingBytes ?? new byte[0];
        }

        /// <summary>
        /// 編集を確定して完了イベントを発火
        /// </summary>
        public void CommitEdit()
        {
            var result = GetBytes();
            EditCompleted?.Invoke(this, new BinaryEditCompletedEventArgs(result));
            HideOverlay();
        }

        /// <summary>
        /// 編集をキャンセル
        /// </summary>
        public void CancelEdit()
        {
            EditCancelled?.Invoke(this, EventArgs.Empty);
            HideOverlay();
        }

        private void HideOverlay()
        {
            this.Visible = false;
        }

        private void BinaryEditorOverlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                e.Handled = true;
                CancelEdit();
            }
            else if (e.KeyCode == Keys.F2 || (e.Control && e.KeyCode == Keys.Enter))
            {
                e.Handled = true;
                CommitEdit();
            }
        }

        private void BinaryEditorOverlay_Leave(object sender, EventArgs e)
        {
            // フォーカスが外れた場合は自動的に確定
            // ただし子コントロール（HexEditor内部）へのフォーカス移動は除く
            if (!this.ContainsFocus)
            {
                CommitEdit();
            }
        }

        private void HexEditor_BytesChanged(object sender, EventArgs e)
        {
            // バイト変更時の処理（必要に応じてリアルタイムプレビュー等に使用可能）
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _hexEditor?.Stream?.Dispose();
                _elementHost?.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    /// <summary>
    /// バイナリ編集完了イベントの引数
    /// </summary>
    public class BinaryEditCompletedEventArgs : EventArgs
    {
        public byte[] EditedBytes { get; }

        public BinaryEditCompletedEventArgs(byte[] editedBytes)
        {
            EditedBytes = editedBytes;
        }
    }
}
