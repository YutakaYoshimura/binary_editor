using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    /// <summary>
    /// DataGridView のセルをクリックしたとき、そのセルの枠に合わせて
    /// 直下（または上）にドロップダウン展開するバイナリ編集オーバーレイ。
    ///
    /// ────────────────────────────────────────────────────────
    /// 表示レイアウト（縦積み）:
    ///
    ///  ┌─────────────────────────────────────┐  ← セル枠と左端・幅を揃える
    ///  │  [確定]  [キャンセル]               │  ← ボタン行（固定高さ）
    ///  ├─────────────────────────────────────┤
    ///  │  WPFHexaEditor                      │  ← HexEditor 領域（残り高さ全部）
    ///  │  （ヘッダー・オフセット非表示）     │
    ///  └─────────────────────────────────────┘
    ///
    /// キー操作:
    ///   Enter / F2  → 確定
    ///   Esc         → キャンセル
    /// ────────────────────────────────────────────────────────
    /// </summary>
    public class BinaryEditorOverlay : UserControl
    {
        // ── コントロール ──────────────────────────────────────────
        private Panel               _toolbar;       // 上段ボタンバー
        private Button              _btnOk;
        private Button              _btnCancel;
        private System.Windows.Forms.Label _lblInfo; // 編集中パラメータ名表示

        private ElementHost             _host;       // WPF ホスト
        private WpfHexaEditor.HexEditor _hexEditor;  // WPF HexEditor 本体

        // ── データ ───────────────────────────────────────────────
        private byte[]       _originalBytes;
        private MemoryStream _editStream;

        // ── イベント ─────────────────────────────────────────────
        public event EventHandler<BinaryEditCompletedEventArgs> EditCompleted;
        public event EventHandler                               EditCancelled;

        // ── 定数 ─────────────────────────────────────────────────
        private const int TOOLBAR_H   = 28;   // ボタンバーの高さ
        private const int OVERLAY_H   = 100;  // オーバーレイ全体の高さ
        //   ↑ HexEditor 領域 = OVERLAY_H - TOOLBAR_H = 72px
        //     この高さでヘッダー非表示・1行表示が成立する

        // ════════════════════════════════════════════════════════
        public BinaryEditorOverlay()
        {
            InitOverlay();
        }

        // ════════════════════════════════════════════════════════
        // 初期化
        // ════════════════════════════════════════════════════════
        private void InitOverlay()
        {
            this.SuspendLayout();
            this.BorderStyle = BorderStyle.FixedSingle;
            this.BackColor   = Color.White;

            // ── ①ボタンバー（上段）────────────────────────────
            _toolbar             = new Panel();
            _toolbar.Dock        = DockStyle.Top;
            _toolbar.Height      = TOOLBAR_H;
            _toolbar.BackColor   = Color.FromArgb(40, 80, 140);  // 濃い青
            _toolbar.Padding     = new Padding(2);

            _lblInfo             = new System.Windows.Forms.Label();
            _lblInfo.AutoSize    = false;
            _lblInfo.Dock        = DockStyle.Fill;
            _lblInfo.ForeColor   = Color.White;
            _lblInfo.Font        = new Font("MS UI Gothic", 8.5F);
            _lblInfo.TextAlign   = ContentAlignment.MiddleLeft;
            _lblInfo.Text        = "";

            _btnOk               = new Button();
            _btnOk.Text          = "確定(F2)";
            _btnOk.Width         = 70;
            _btnOk.Dock          = DockStyle.Right;
            _btnOk.FlatStyle     = FlatStyle.Flat;
            _btnOk.BackColor     = Color.SteelBlue;
            _btnOk.ForeColor     = Color.White;
            _btnOk.Font          = new Font("MS UI Gothic", 8F);
            _btnOk.TabStop       = false;
            _btnOk.Click        += (s, e) => CommitEdit();

            _btnCancel           = new Button();
            _btnCancel.Text      = "キャンセル(Esc)";
            _btnCancel.Width     = 100;
            _btnCancel.Dock      = DockStyle.Right;
            _btnCancel.FlatStyle = FlatStyle.Flat;
            _btnCancel.BackColor = Color.FromArgb(160, 60, 60);
            _btnCancel.ForeColor = Color.White;
            _btnCancel.Font      = new Font("MS UI Gothic", 8F);
            _btnCancel.TabStop   = false;
            _btnCancel.Click    += (s, e) => CancelEdit();

            // 追加順（Dock=Right は後から追加したものが右端）
            _toolbar.Controls.Add(_lblInfo);     // Fill（左側）
            _toolbar.Controls.Add(_btnOk);       // Right
            _toolbar.Controls.Add(_btnCancel);   // さらに右

            // ── ② WPFHexaEditor（下段）─────────────────────────
            _hexEditor              = new WpfHexaEditor.HexEditor();
            _hexEditor.ReadOnlyMode = false;

            // ヘッダー・オフセット非表示、1行表示のためのコンパクト設定
            ApplyCompactSettings();

            // ElementHost は Dock=Fill で下段全体を占める
            _host       = new ElementHost();
            _host.Dock  = DockStyle.Fill;   // ← Anchor ではなく Dock=Fill を使用
            _host.Child = _hexEditor;

            // Controls への追加順（Fill は最後に追加）
            this.Controls.Add(_host);       // Fill（下段）
            this.Controls.Add(_toolbar);    // Top（上段）※後追加で Top が正しく機能

            // キーイベント
            this.KeyDown += OnKeyDown;
            this.Leave   += OnLeave;

            this.ResumeLayout(false);
        }

        /// <summary>
        /// HexEditor のヘッダー・オフセット・スクロールバーを非表示にする。
        /// プロパティ名はバージョン差異があるため try-catch で個別に設定する。
        /// </summary>
        private void ApplyCompactSettings()
        {
            // --- オフセット列を非表示 ---
            TrySet("OffsetLabelVisible", System.Windows.Visibility.Collapsed);
            TrySet("OffsetVisible",      false);
            TrySet("ShowOffset",         false);

            // --- ヘッダー行を非表示 ---
            TrySet("HeaderVisibility",   System.Windows.Visibility.Collapsed);
            TrySet("ShowHeader",         false);

            // --- スクロールバー非表示 ---
            TrySet("VerticalScrollBarVisibility",
                   System.Windows.Controls.ScrollBarVisibility.Hidden);

            // --- 1行に全バイトを収める（バイト数が少なければ自然に1行） ---
            TrySet("BytePerLine", 256);

            // --- 余白ゼロ ---
            try { _hexEditor.Margin  = new System.Windows.Thickness(0); } catch { }
            try { _hexEditor.Padding = new System.Windows.Thickness(0); } catch { }

            // --- 背景・前景 ---
            try { _hexEditor.Background = System.Windows.Media.Brushes.LightYellow; } catch { }
            try { _hexEditor.Foreground = System.Windows.Media.Brushes.Black;       } catch { }
        }

        /// <summary>リフレクション経由でプロパティを安全に設定する</summary>
        private void TrySet(string name, object value)
        {
            try
            {
                var prop = _hexEditor.GetType().GetProperty(name);
                if (prop != null && prop.CanWrite)
                    prop.SetValue(_hexEditor, value);
            }
            catch { /* バージョン差異による例外は無視 */ }
        }

        // ════════════════════════════════════════════════════════
        // セル枠への位置合わせ（ドロップダウン展開）
        // ════════════════════════════════════════════════════════

        /// <summary>
        /// クリックされたセルの左端・幅に合わせてオーバーレイを配置する。
        /// セルの直下（画面下端に近い場合はセルの直上）に展開する。
        ///
        /// cellRect  : DataGridView 座標系のセル矩形
        /// dgv       : DataGridView（座標変換用）
        /// container : オーバーレイを載せる Panel（panelGridOuter）
        /// paramName : ボタンバーに表示するパラメータ名
        /// </summary>
        public void FitToCell(Rectangle cellRect,
                              DataGridView dgv,
                              Control container,
                              string paramName = "")
        {
            // DataGridView 座標 → スクリーン座標 → container 座標
            Point screen    = dgv.PointToScreen(cellRect.Location);
            Point local     = container.PointToClient(screen);

            // 幅はセルの幅に合わせる（最低 200px 確保）
            int w = Math.Max(cellRect.Width, 200);
            // container の右端をはみ出す場合は左へずらす
            int x = local.X;
            if (x + w > container.Width)
                x = Math.Max(0, container.Width - w);

            // セル直下に配置。container をはみ出す場合はセル直上
            int yBelow = local.Y + cellRect.Height;
            int yAbove = local.Y - OVERLAY_H;

            int y = (yBelow + OVERLAY_H <= container.Height)
                    ? yBelow
                    : Math.Max(0, yAbove);

            // パラメータ名をツールバーに表示
            _lblInfo.Text = string.IsNullOrEmpty(paramName)
                ? ""
                : $"  編集: {paramName}";

            this.Location = new Point(x, y);
            this.Size     = new Size(w, OVERLAY_H);
        }

        // ════════════════════════════════════════════════════════
        // 公開メソッド
        // ════════════════════════════════════════════════════════

        public void SetBytes(byte[] bytes)
        {
            if (bytes == null) bytes = new byte[0];

            _originalBytes = new byte[bytes.Length];
            Array.Copy(bytes, _originalBytes, bytes.Length);

            _editStream?.Dispose();
            _editStream          = new MemoryStream(bytes.Length + 1);
            _editStream.Write(bytes, 0, bytes.Length);
            _editStream.Position = 0;

            // Stream をセットする前に HexEditor が表示済みであることを保証するため
            // Visible = true の後に Stream を設定するよう呼び出し側で順序を守ること。
            // ここでは Stream 設定のみ行う。
            _hexEditor.Stream = _editStream;
        }

        public byte[] GetBytes()
        {
            if (_editStream == null) return _originalBytes ?? new byte[0];
            return _editStream.ToArray();
        }

        public void CommitEdit()
        {
            EditCompleted?.Invoke(this, new BinaryEditCompletedEventArgs(GetBytes()));
            this.Visible = false;
        }

        public void CancelEdit()
        {
            EditCancelled?.Invoke(this, EventArgs.Empty);
            this.Visible = false;
        }

        // ════════════════════════════════════════════════════════
        // イベントハンドラ
        // ════════════════════════════════════════════════════════

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                e.Handled = true;
                CancelEdit();
            }
            else if (e.KeyCode == Keys.F2 ||
                     (e.KeyCode == Keys.Return && !e.Shift))
            {
                e.Handled = true;
                CommitEdit();
            }
        }

        private void OnLeave(object sender, EventArgs e)
        {
            if (!this.ContainsFocus)
                CommitEdit();
        }

        // ════════════════════════════════════════════════════════
        // Dispose
        // ════════════════════════════════════════════════════════
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _editStream?.Dispose();
                _host?.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // ────────────────────────────────────────────────────────────
    public class BinaryEditCompletedEventArgs : EventArgs
    {
        public byte[] EditedBytes { get; }
        public BinaryEditCompletedEventArgs(byte[] b) { EditedBytes = b; }
    }
}
