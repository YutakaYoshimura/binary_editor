using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    /// <summary>
    /// DataGridView のセル枠にぴったり重なるバイナリ編集オーバーレイ。
    ///
    /// 表示構成（左から右へ横並び）:
    ///   [WPFHexaEditor (ElementHost)] [確定ボタン] [キャンセルボタン]
    ///
    /// WPFHexaEditor はヘッダー・オフセット列を非表示にして
    /// バイト列だけを1行で表示する。
    ///
    /// キー操作:
    ///   Enter / F2      → 確定
    ///   Esc             → キャンセル
    /// </summary>
    public class BinaryEditorOverlay : UserControl
    {
        // ── WPF埋め込み ──────────────────────────────────────────
        private ElementHost            _host;
        private WpfHexaEditor.HexEditor _hexEditor;

        // ── WinForms ボタン（セル右端に並べる）────────────────────
        private Button _btnOk;
        private Button _btnCancel;

        // ── データ ───────────────────────────────────────────────
        private byte[]       _originalBytes;
        private MemoryStream _editStream;

        // ── イベント ─────────────────────────────────────────────
        public event EventHandler<BinaryEditCompletedEventArgs> EditCompleted;
        public event EventHandler                               EditCancelled;

        // ── 定数 ─────────────────────────────────────────────────
        private const int BTN_W = 52;   // 確定/キャンセル ボタン幅
        private const int BTN_H = 22;   // ボタン高さ
        private const int BTN_GAP = 2;  // ボタン間隔

        // ════════════════════════════════════════════════════════
        public BinaryEditorOverlay()
        {
            InitOverlay();
        }

        // ════════════════════════════════════════════════════════
        // 初期化
        // ════════════════════════════════════════════════════════
        private void InitOverlay()
        {
            this.SuspendLayout();

            // UserControl 自体の外枠スタイル
            this.BorderStyle = BorderStyle.FixedSingle;
            this.BackColor   = Color.White;

            // ── WPFHexaEditor ──────────────────────────────────
            _hexEditor              = new WpfHexaEditor.HexEditor();
            _hexEditor.ReadOnlyMode = false;

            // ヘッダー・オフセット列・スクロールバーを非表示にして
            // バイト列だけの1行表示に近づける。
            // プロパティ名はバージョンにより異なるため try-catch で全設定する。
            TrySetHexEditorCompactMode();

            // ── ElementHost ────────────────────────────────────
            _host        = new ElementHost();
            _host.Child  = _hexEditor;
            // 位置・サイズは FitToCell() で動的に設定するため Dock は使わない
            _host.Anchor = AnchorStyles.Left | AnchorStyles.Top
                         | AnchorStyles.Right | AnchorStyles.Bottom;
            this.Controls.Add(_host);

            // ── 確定ボタン ──────────────────────────────────────
            _btnOk             = new Button();
            _btnOk.Text        = "確定";
            _btnOk.Font        = new Font("MS UI Gothic", 8F);
            _btnOk.BackColor   = Color.SteelBlue;
            _btnOk.ForeColor   = Color.White;
            _btnOk.FlatStyle   = FlatStyle.Flat;
            _btnOk.Anchor      = AnchorStyles.Right | AnchorStyles.Top;
            _btnOk.Click      += (s, e) => CommitEdit();
            _btnOk.TabStop     = false;
            this.Controls.Add(_btnOk);

            // ── キャンセルボタン ────────────────────────────────
            _btnCancel           = new Button();
            _btnCancel.Text      = "×";
            _btnCancel.Font      = new Font("MS UI Gothic", 8F);
            _btnCancel.BackColor = Color.IndianRed;
            _btnCancel.ForeColor = Color.White;
            _btnCancel.FlatStyle = FlatStyle.Flat;
            _btnCancel.Anchor    = AnchorStyles.Right | AnchorStyles.Top;
            _btnCancel.Click    += (s, e) => CancelEdit();
            _btnCancel.TabStop   = false;
            this.Controls.Add(_btnCancel);

            // ── キーイベント ────────────────────────────────────
            this.KeyDown += OnKeyDown;
            this.Leave   += OnLeave;

            this.ResumeLayout(false);
        }

        /// <summary>
        /// WPFHexaEditorをコンパクト（ヘッダー・オフセット非表示）に設定する。
        /// プロパティ名はバージョン差異があるため個別に try-catch する。
        /// </summary>
        private void TrySetHexEditorCompactMode()
        {
            // オフセット列非表示
            try { _hexEditor.OffsetLabelVisible = System.Windows.Visibility.Collapsed; } catch { }
            try { SetWpfProperty("OffsetVisible", false); } catch { }
            try { SetWpfProperty("ShowOffset", false); } catch { }

            // ヘッダー非表示
            try { SetWpfProperty("HeaderVisibility", System.Windows.Visibility.Collapsed); } catch { }
            try { SetWpfProperty("ShowHeader", false); } catch { }
            try { _hexEditor.HeaderVisibility = System.Windows.Visibility.Collapsed; } catch { }

            // スクロールバー非表示（1行に収める）
            try { SetWpfProperty("VerticalScrollBarVisibility",
                System.Windows.Controls.ScrollBarVisibility.Hidden); } catch { }

            // 行ごとのバイト数を最大にして1行に収める
            // （バイト数が少なければ自然に1行）
            try { _hexEditor.BytePerLine = 256; } catch { }

            // マージン・パディングをゼロに
            try { _hexEditor.Margin  = new System.Windows.Thickness(0); } catch { }
            try { _hexEditor.Padding = new System.Windows.Thickness(0); } catch { }

            // 背景・前景
            try { _hexEditor.Background = System.Windows.Media.Brushes.LightYellow; } catch { }
            try { _hexEditor.Foreground = System.Windows.Media.Brushes.Black; } catch { }
        }

        /// <summary>リフレクション経由でプロパティを設定（バージョン差異吸収用）</summary>
        private void SetWpfProperty(string propName, object value)
        {
            var prop = _hexEditor.GetType().GetProperty(propName);
            if (prop != null && prop.CanWrite)
                prop.SetValue(_hexEditor, value);
        }

        // ════════════════════════════════════════════════════════
        // セル枠への位置合わせ
        // ════════════════════════════════════════════════════════

        /// <summary>
        /// DataGridView 上のセル矩形にオーバーレイをぴったり合わせる。
        /// cellRect     : DataGridView 座標系のセル矩形
        /// dataGridView : 親の DataGridView（座標変換に使用）
        /// container    : オーバーレイを載せる Panel（panelGridOuter）
        /// </summary>
        public void FitToCell(Rectangle cellRect,
                              DataGridView dataGridView,
                              Control container)
        {
            // ── セル枠を container 座標系に変換 ──────────────────
            Point screenPt    = dataGridView.PointToScreen(cellRect.Location);
            Point containerPt = container.PointToClient(screenPt);

            // ── ボタン2個分の幅を右に確保 ──────────────────────
            int btnsWidth  = BTN_W * 2 + BTN_GAP * 3;
            int totalWidth = cellRect.Width + btnsWidth;

            // container からはみ出す場合は右端で折り返す
            if (containerPt.X + totalWidth > container.Width)
                totalWidth = container.Width - containerPt.X;

            int cellH = cellRect.Height;

            // ── UserControl 自体のサイズ・位置 ──────────────────
            this.Location = new Point(containerPt.X, containerPt.Y);
            this.Size     = new Size(totalWidth, cellH);

            // ── ElementHost（HexEditor）の配置 ───────────────────
            int hexW = totalWidth - btnsWidth;
            _host.Location = new Point(0, 0);
            _host.Size     = new Size(Math.Max(hexW, 50), cellH);

            // ── ボタン配置（右端に縦中央揃え）──────────────────
            int btnY    = (cellH - BTN_H) / 2;
            int okX     = hexW + BTN_GAP;
            int cancelX = okX + BTN_W + BTN_GAP;

            _btnOk.Location = new Point(okX,     btnY);
            _btnOk.Size     = new Size(BTN_W,    BTN_H);

            _btnCancel.Location = new Point(cancelX, btnY);
            _btnCancel.Size     = new Size(BTN_W,    BTN_H);
        }

        // ════════════════════════════════════════════════════════
        // 公開メソッド
        // ════════════════════════════════════════════════════════

        public void SetBytes(byte[] bytes)
        {
            if (bytes == null) bytes = new byte[0];

            _originalBytes = new byte[bytes.Length];
            Array.Copy(bytes, _originalBytes, bytes.Length);

            _editStream?.Dispose();
            _editStream          = new MemoryStream(bytes.Length + 1);
            _editStream.Write(bytes, 0, bytes.Length);
            _editStream.Position = 0;
            _hexEditor.Stream    = _editStream;
        }

        public byte[] GetBytes()
        {
            if (_editStream == null) return _originalBytes ?? new byte[0];
            return _editStream.ToArray();
        }

        public void CommitEdit()
        {
            EditCompleted?.Invoke(this, new BinaryEditCompletedEventArgs(GetBytes()));
            this.Visible = false;
        }

        public void CancelEdit()
        {
            EditCancelled?.Invoke(this, EventArgs.Empty);
            this.Visible = false;
        }

        // ════════════════════════════════════════════════════════
        // イベントハンドラ
        // ════════════════════════════════════════════════════════

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    e.Handled = true;
                    CancelEdit();
                    break;
                case Keys.Return when !e.Shift:
                case Keys.F2:
                    e.Handled = true;
                    CommitEdit();
                    break;
            }
        }

        private void OnLeave(object sender, EventArgs e)
        {
            if (!this.ContainsFocus)
                CommitEdit();
        }

        // ════════════════════════════════════════════════════════
        // Dispose
        // ════════════════════════════════════════════════════════
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _editStream?.Dispose();
                _host?.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // ────────────────────────────────────────────────────────────
    public class BinaryEditCompletedEventArgs : EventArgs
    {
        public byte[] EditedBytes { get; }
        public BinaryEditCompletedEventArgs(byte[] b) { EditedBytes = b; }
    }
}
