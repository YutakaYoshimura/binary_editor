using System;

namespace BinaryEditorApp
{
    /// <summary>
    /// バイナリデータの各パラメータを表すモデルクラス
    /// </summary>
    public class BinaryParameter
    {
        /// <summary>パラメータ名</summary>
        public string Name { get; set; }

        /// <summary>バイナリデータ内のオフセット（バイト）</summary>
        public int Offset { get; set; }

        /// <summary>データ長（バイト）</summary>
        public int Length { get; set; }

        /// <summary>データ型（例: UInt8, UInt16, UInt32, Bytes, String）</summary>
        public string DataType { get; set; }

        /// <summary>生のバイト値（バイナリデータから切り出したもの）</summary>
        public byte[] RawBytes { get; set; }

        /// <summary>表示用16進数文字列</summary>
        public string HexValue
        {
            get
            {
                if (RawBytes == null || RawBytes.Length == 0)
                    return string.Empty;
                return BitConverter.ToString(RawBytes).Replace("-", " ");
            }
        }

        /// <summary>データ型に応じた解釈済み値文字列</summary>
        public string InterpretedValue
        {
            get
            {
                if (RawBytes == null || RawBytes.Length == 0)
                    return string.Empty;

                try
                {
                    switch (DataType)
                    {
                        case "UInt8":
                            return RawBytes[0].ToString();
                        case "Int8":
                            return ((sbyte)RawBytes[0]).ToString();
                        case "UInt16":
                            return (RawBytes.Length >= 2
                                ? BitConverter.ToUInt16(RawBytes, 0).ToString()
                                : RawBytes[0].ToString());
                        case "Int16":
                            return (RawBytes.Length >= 2
                                ? BitConverter.ToInt16(RawBytes, 0).ToString()
                                : ((sbyte)RawBytes[0]).ToString());
                        case "UInt32":
                            return (RawBytes.Length >= 4
                                ? BitConverter.ToUInt32(RawBytes, 0).ToString()
                                : string.Empty);
                        case "Int32":
                            return (RawBytes.Length >= 4
                                ? BitConverter.ToInt32(RawBytes, 0).ToString()
                                : string.Empty);
                        case "Float":
                            return (RawBytes.Length >= 4
                                ? BitConverter.ToSingle(RawBytes, 0).ToString("F4")
                                : string.Empty);
                        case "String":
                            return System.Text.Encoding.ASCII.GetString(RawBytes).TrimEnd('\0');
                        case "Bytes":
                        default:
                            return HexValue;
                    }
                }
                catch
                {
                    return HexValue;
                }
            }
        }

        public BinaryParameter()
        {
            RawBytes = new byte[0];
        }

        public BinaryParameter(string name, int offset, int length, string dataType = "Bytes")
        {
            Name = name;
            Offset = offset;
            Length = length;
            DataType = dataType;
            RawBytes = new byte[length];
        }

        /// <summary>
        /// バイナリデータ全体からこのパラメータに対応するバイトを抽出する
        /// </summary>
        public void ExtractFromData(byte[] sourceData)
        {
            if (sourceData == null || Offset < 0 || Offset + Length > sourceData.Length)
            {
                RawBytes = new byte[Length];
                return;
            }

            RawBytes = new byte[Length];
            Array.Copy(sourceData, Offset, RawBytes, 0, Length);
        }

        /// <summary>
        /// 修正されたバイトをソースデータに書き戻す
        /// </summary>
        public void WriteToData(byte[] targetData)
        {
            if (targetData == null || RawBytes == null)
                return;
            if (Offset < 0 || Offset + Length > targetData.Length)
                return;

            Array.Copy(RawBytes, 0, targetData, Offset, Math.Min(RawBytes.Length, Length));
        }
    }
}
