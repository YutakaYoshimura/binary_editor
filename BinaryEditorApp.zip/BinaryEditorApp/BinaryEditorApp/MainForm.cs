using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace BinaryEditorApp
{
    /// <summary>
    /// メインフォーム
    /// バイナリデータをDataGridViewで表示し、セル編集時にWPFHexEditorオーバーレイを使用する
    /// </summary>
    public partial class MainForm : Form
    {
        // バイナリデータ本体
        private byte[] _binaryData;

        // パラメータリスト
        private List<BinaryParameter> _parameters;

        // WPFHexEditorオーバーレイ
        private BinaryEditorOverlay _hexEditorOverlay;

        // 現在編集中のセル情報
        private int _editingRowIndex = -1;
        private int _editingColIndex = -1;

        // DataGridViewの列インデックス定数
        private const int COL_NAME = 0;
        private const int COL_OFFSET = 1;
        private const int COL_LENGTH = 2;
        private const int COL_DATATYPE = 3;
        private const int COL_HEX = 4;
        private const int COL_VALUE = 5;

        public MainForm()
        {
            InitializeComponent();
            InitializeBinaryEditorOverlay();
            InitializeSampleData();
        }

        /// <summary>
        /// WPFHexEditorオーバーレイの初期化
        /// </summary>
        private void InitializeBinaryEditorOverlay()
        {
            _hexEditorOverlay = new BinaryEditorOverlay();
            _hexEditorOverlay.Visible = false;
            _hexEditorOverlay.Size = new Size(600, 200);

            // 編集完了イベント
            _hexEditorOverlay.EditCompleted += HexEditorOverlay_EditCompleted;
            // キャンセルイベント
            _hexEditorOverlay.EditCancelled += HexEditorOverlay_EditCancelled;

            // DataGridViewの親パネルに追加（重ね表示のため）
            panelGrid.Controls.Add(_hexEditorOverlay);
            _hexEditorOverlay.BringToFront();
        }

        /// <summary>
        /// サンプルバイナリデータとパラメータ定義の初期化
        /// </summary>
        private void InitializeSampleData()
        {
            // サンプルバイナリデータ（64バイト）
            _binaryData = new byte[64];
            // ヘッダーマジックナンバー
            _binaryData[0] = 0x42; // 'B'
            _binaryData[1] = 0x49; // 'I'
            _binaryData[2] = 0x4E; // 'N'
            _binaryData[3] = 0x01; // バージョン
            // UInt16: データサイズ
            _binaryData[4] = 0x40;
            _binaryData[5] = 0x00;
            // UInt32: タイムスタンプ
            _binaryData[6] = 0x60;
            _binaryData[7] = 0x50;
            _binaryData[8] = 0x40;
            _binaryData[9] = 0x30;
            // Float: センサー値
            byte[] floatBytes = BitConverter.GetBytes(3.14f);
            Array.Copy(floatBytes, 0, _binaryData, 10, 4);
            // String: デバイス名（8バイト）
            byte[] nameBytes = Encoding.ASCII.GetBytes("Device01");
            Array.Copy(nameBytes, 0, _binaryData, 14, 8);
            // 残りはランダムデータ
            new Random(42).NextBytes(new byte[42]).CopyTo(_binaryData, 22);
            for (int i = 22; i < 64; i++) _binaryData[i] = (byte)(i * 3 % 256);

            // パラメータ定義
            _parameters = new List<BinaryParameter>
            {
                new BinaryParameter("Magic Number",   0,  3, "Bytes"),
                new BinaryParameter("Version",        3,  1, "UInt8"),
                new BinaryParameter("Data Size",      4,  2, "UInt16"),
                new BinaryParameter("Timestamp",      6,  4, "UInt32"),
                new BinaryParameter("Sensor Value",  10,  4, "Float"),
                new BinaryParameter("Device Name",   14,  8, "String"),
                new BinaryParameter("Param A",       22,  2, "UInt16"),
                new BinaryParameter("Param B",       24,  4, "UInt32"),
                new BinaryParameter("Param C",       28,  1, "UInt8"),
                new BinaryParameter("Reserved",      29, 35, "Bytes"),
            };

            // 各パラメータにバイトを割り当て
            foreach (var param in _parameters)
            {
                param.ExtractFromData(_binaryData);
            }

            // DataGridViewにデータをバインド
            RefreshDataGridView();
            RefreshFullHexView();
        }

        /// <summary>
        /// DataGridViewにパラメータデータを表示する
        /// </summary>
        private void RefreshDataGridView()
        {
            dataGridView.Rows.Clear();

            foreach (var param in _parameters)
            {
                int rowIndex = dataGridView.Rows.Add(
                    param.Name,
                    param.Offset,
                    param.Length,
                    param.DataType,
                    param.HexValue,
                    param.InterpretedValue
                );

                // ヘッダー行は背景色を変更
                dataGridView.Rows[rowIndex].Cells[COL_NAME].Style.BackColor = Color.FromArgb(230, 240, 255);
            }
        }

        /// <summary>
        /// 全体バイナリビューを更新する
        /// </summary>
        private void RefreshFullHexView()
        {
            if (_binaryData == null) return;

            // 全体HexEditorにデータをセット
            var stream = new MemoryStream(_binaryData);
            hexEditorFull.Stream = stream;
        }

        /// <summary>
        /// DataGridViewのセルクリック時にHexEditorオーバーレイを表示する
        /// </summary>
        private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            // HEXカラムまたはVALUEカラムのクリックで編集開始
            if (e.ColumnIndex == COL_HEX || e.ColumnIndex == COL_VALUE)
            {
                StartHexEditing(e.RowIndex, e.ColumnIndex);
            }
        }

        /// <summary>
        /// HexEditorオーバーレイを使った編集開始
        /// テキストセルの上にHexEditorを重ねて表示する
        /// </summary>
        private void StartHexEditing(int rowIndex, int colIndex)
        {
            if (rowIndex < 0 || rowIndex >= _parameters.Count) return;

            _editingRowIndex = rowIndex;
            _editingColIndex = colIndex;

            var param = _parameters[rowIndex];

            // セルの画面上の位置とサイズを取得
            Rectangle cellRect = dataGridView.GetCellDisplayRectangle(colIndex, rowIndex, true);

            // オーバーレイのサイズと位置を設定
            // セルの直上に重ねる（高さはHexEditorに十分な高さを確保）
            int overlayHeight = Math.Max(160, param.Length > 16 ? 200 : 160);
            int overlayWidth = Math.Max(500, dataGridView.Width - cellRect.X);

            // DataGridView上の座標をpanelGrid内の座標に変換
            Point cellPoint = dataGridView.PointToScreen(cellRect.Location);
            Point panelPoint = panelGrid.PointToClient(cellPoint);

            // オーバーレイをセルの下に表示（画面外にはみ出す場合は上に表示）
            int overlayY = panelPoint.Y + cellRect.Height;
            if (overlayY + overlayHeight > panelGrid.Height)
            {
                overlayY = panelPoint.Y - overlayHeight;
            }
            if (overlayY < 0) overlayY = panelPoint.Y;

            _hexEditorOverlay.Location = new Point(panelPoint.X, overlayY);
            _hexEditorOverlay.Size = new Size(overlayWidth, overlayHeight);

            // 編集するバイト配列をオーバーレイにセット
            _hexEditorOverlay.SetBytes(param.RawBytes);
            _hexEditorOverlay.Visible = true;
            _hexEditorOverlay.BringToFront();
            _hexEditorOverlay.Focus();

            // ステータスバーに操作説明を表示
            toolStripStatusLabel.Text =
                $"編集中: {param.Name}  |  F2またはCtrl+Enterで確定  |  Escでキャンセル";
        }

        /// <summary>
        /// HexEditor編集完了時の処理
        /// </summary>
        private void HexEditorOverlay_EditCompleted(object sender, BinaryEditCompletedEventArgs e)
        {
            if (_editingRowIndex < 0 || _editingRowIndex >= _parameters.Count) return;

            var param = _parameters[_editingRowIndex];
            var newBytes = e.EditedBytes;

            // 長さが変わっていない場合のみ反映（固定長パラメータ）
            if (newBytes.Length == param.Length)
            {
                // パラメータのRawBytesを更新
                param.RawBytes = newBytes;

                // バイナリデータ全体にも書き戻し
                param.WriteToData(_binaryData);

                // DataGridViewの該当行を更新
                UpdateGridRow(_editingRowIndex);

                // 全体HexViewを更新
                RefreshFullHexView();

                toolStripStatusLabel.Text = $"更新完了: {param.Name}";
            }
            else
            {
                // 長さが異なる場合は先頭から必要バイト数だけコピー
                byte[] adjusted = new byte[param.Length];
                Array.Copy(newBytes, adjusted, Math.Min(newBytes.Length, param.Length));
                param.RawBytes = adjusted;
                param.WriteToData(_binaryData);
                UpdateGridRow(_editingRowIndex);
                RefreshFullHexView();
                toolStripStatusLabel.Text = $"更新完了（長さ調整）: {param.Name}";
            }

            _editingRowIndex = -1;
            _editingColIndex = -1;
        }

        /// <summary>
        /// HexEditor編集キャンセル時の処理
        /// </summary>
        private void HexEditorOverlay_EditCancelled(object sender, EventArgs e)
        {
            if (_editingRowIndex >= 0 && _editingRowIndex < _parameters.Count)
            {
                toolStripStatusLabel.Text =
                    $"編集キャンセル: {_parameters[_editingRowIndex].Name}";
            }
            _editingRowIndex = -1;
            _editingColIndex = -1;
        }

        /// <summary>
        /// DataGridViewの指定行を更新する
        /// </summary>
        private void UpdateGridRow(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= _parameters.Count) return;
            if (rowIndex >= dataGridView.Rows.Count) return;

            var param = _parameters[rowIndex];
            var row = dataGridView.Rows[rowIndex];

            row.Cells[COL_HEX].Value = param.HexValue;
            row.Cells[COL_VALUE].Value = param.InterpretedValue;
        }

        // ファイルを開くボタン
        private void btnOpen_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "バイナリファイルを開く";
                ofd.Filter = "すべてのファイル (*.*)|*.*|バイナリファイル (*.bin)|*.bin";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        _binaryData = File.ReadAllBytes(ofd.FileName);

                        // ファイルが64バイト以上であれば既存パラメータ定義でデータ抽出
                        if (_binaryData.Length >= 64)
                        {
                            foreach (var param in _parameters)
                            {
                                param.ExtractFromData(_binaryData);
                            }
                        }
                        else
                        {
                            // サイズが小さい場合は収まる範囲だけ
                            foreach (var param in _parameters)
                            {
                                if (param.Offset < _binaryData.Length)
                                {
                                    param.ExtractFromData(_binaryData);
                                }
                            }
                        }

                        RefreshDataGridView();
                        RefreshFullHexView();
                        toolStripStatusLabel.Text = $"ファイル読み込み完了: {ofd.FileName}  ({_binaryData.Length} bytes)";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ファイルの読み込みに失敗しました:\n{ex.Message}",
                            "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // 保存ボタン
        private void btnSave_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Title = "バイナリファイルを保存";
                sfd.Filter = "バイナリファイル (*.bin)|*.bin|すべてのファイル (*.*)|*.*";
                sfd.DefaultExt = "bin";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllBytes(sfd.FileName, _binaryData);
                        toolStripStatusLabel.Text = $"保存完了: {sfd.FileName}";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ファイルの保存に失敗しました:\n{ex.Message}",
                            "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // 全体HexViewに選択範囲を同期するためのセル選択イベント
        private void DataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                int rowIndex = dataGridView.SelectedRows[0].Index;
                if (rowIndex >= 0 && rowIndex < _parameters.Count)
                {
                    var param = _parameters[rowIndex];
                    // 全体HexEditorでも対応するオフセットを選択状態にする
                    hexEditorFull.SelectionStart = param.Offset;
                    hexEditorFull.SelectionStop = param.Offset + param.Length - 1;
                }
            }
        }

        // DataGridViewでDeleteキーが押されたときにオーバーレイを閉じる
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape && _hexEditorOverlay.Visible)
            {
                _hexEditorOverlay.CancelEdit();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
