using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    /// <summary>
    /// メインフォーム
    ///
    /// タブ①「バイナリ全体編集」
    ///   WPFHexaEditor をフル画面で表示し、バイナリデータを直接編集する。
    ///
    /// タブ②「パラメータ編集」
    ///   DataGridView でパラメータ一覧を表示する。
    ///   HEX値列 または 値列をクリックすると、そのセルの矩形にぴったり重なる
    ///   BinaryEditorOverlay（WPFHexaEditor）が出現し、まるでセルを直接
    ///   編集しているかのような操作感を実現する。
    ///   F2 / Ctrl+Enter で確定、Esc でキャンセル。
    /// </summary>
    public partial class MainForm : Form
    {
        // ── フィールド ──────────────────────────────────────────────
        private byte[]                 _binaryData;
        private List<BinaryParameter>  _parameters;
        private BinaryEditorOverlay    _overlay;        // セル上に重なるHexEditorオーバーレイ
        private int                    _editRow = -1;   // 現在編集中の行
        private int                    _editCol = -1;   // 現在編集中の列

        // DataGridView 列インデックス定数
        private const int COL_NAME   = 0;
        private const int COL_OFFSET = 1;
        private const int COL_LEN    = 2;
        private const int COL_TYPE   = 3;
        private const int COL_HEX    = 4;
        private const int COL_VAL    = 5;

        // ── コンストラクタ ──────────────────────────────────────────
        public MainForm()
        {
            InitializeComponent();
            InitOverlay();
            InitSampleData();
        }

        // ═══════════════════════════════════════════════════════════
        // オーバーレイ初期化
        // ═══════════════════════════════════════════════════════════
        private void InitOverlay()
        {
            _overlay = new BinaryEditorOverlay();
            _overlay.Visible = false;

            _overlay.EditCompleted  += Overlay_EditCompleted;
            _overlay.EditCancelled  += Overlay_EditCancelled;

            // panelGridOuter に追加することで DataGridView と同一座標系に重なる
            panelGridOuter.Controls.Add(_overlay);
            _overlay.BringToFront();
        }

        // ═══════════════════════════════════════════════════════════
        // サンプルデータ初期化
        // ═══════════════════════════════════════════════════════════
        private void InitSampleData()
        {
            _binaryData = new byte[64];
            _binaryData[0] = 0x42; _binaryData[1] = 0x49;
            _binaryData[2] = 0x4E; _binaryData[3] = 0x01;
            _binaryData[4] = 0x40; _binaryData[5] = 0x00;
            _binaryData[6] = 0x60; _binaryData[7] = 0x50;
            _binaryData[8] = 0x40; _binaryData[9] = 0x30;
            byte[] fb = BitConverter.GetBytes(3.14f);
            Array.Copy(fb, 0, _binaryData, 10, 4);
            byte[] nb = Encoding.ASCII.GetBytes("Device01");
            Array.Copy(nb, 0, _binaryData, 14, 8);
            var rnd = new byte[42];
            new Random(42).NextBytes(rnd);
            rnd.CopyTo(_binaryData, 22);
            for (int i = 22; i < 64; i++) _binaryData[i] = (byte)(i * 3 % 256);

            _parameters = new List<BinaryParameter>
            {
                new BinaryParameter("Magic Number",  0,  3, "Bytes"),
                new BinaryParameter("Version",       3,  1, "UInt8"),
                new BinaryParameter("Data Size",     4,  2, "UInt16"),
                new BinaryParameter("Timestamp",     6,  4, "UInt32"),
                new BinaryParameter("Sensor Value", 10,  4, "Float"),
                new BinaryParameter("Device Name",  14,  8, "String"),
                new BinaryParameter("Param A",      22,  2, "UInt16"),
                new BinaryParameter("Param B",      24,  4, "UInt32"),
                new BinaryParameter("Param C",      28,  1, "UInt8"),
                new BinaryParameter("Reserved",     29, 35, "Bytes"),
            };
            foreach (var p in _parameters) p.ExtractFromData(_binaryData);

            RefreshGrid();
            RefreshHexFull();
        }

        // ═══════════════════════════════════════════════════════════
        // タブ① ─ バイナリ全体 HexEditor の更新
        // ═══════════════════════════════════════════════════════════
        private void RefreshHexFull()
        {
            if (_binaryData == null) return;
            // MemoryStream のコピーを渡す（書き込み可能）
            hexEditorFull.Stream = new MemoryStream((byte[])_binaryData.Clone());
        }

        // タブ① 編集確定：HexEditorFullからバイナリを読み取ってパラメータに反映
        private void SyncFromHexFull()
        {
            var ms = hexEditorFull.Stream as MemoryStream;
            if (ms == null) return;
            _binaryData = ms.ToArray();
            foreach (var p in _parameters) p.ExtractFromData(_binaryData);
            RefreshGrid();
        }

        // ═══════════════════════════════════════════════════════════
        // タブ② ─ DataGridView 表示制御
        // ═══════════════════════════════════════════════════════════
        private void RefreshGrid()
        {
            dataGridView.Rows.Clear();
            foreach (var p in _parameters)
            {
                int ri = dataGridView.Rows.Add(
                    p.Name, p.Offset, p.Length, p.DataType,
                    p.HexValue, p.InterpretedValue);

                // パラメータ名セルを薄青で色付け
                dataGridView.Rows[ri].Cells[COL_NAME].Style.BackColor
                    = Color.FromArgb(225, 235, 255);
            }
        }

        private void UpdateGridRow(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= _parameters.Count) return;
            if (rowIndex >= dataGridView.Rows.Count) return;
            var p   = _parameters[rowIndex];
            var row = dataGridView.Rows[rowIndex];
            row.Cells[COL_HEX].Value = p.HexValue;
            row.Cells[COL_VAL].Value = p.InterpretedValue;
        }

        // ── セルクリック：HEX値列/値列のみオーバーレイ編集を起動 ──
        private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (e.ColumnIndex == COL_HEX || e.ColumnIndex == COL_VAL)
                StartOverlayEdit(e.RowIndex, e.ColumnIndex);
        }

        // ── マウスホバー：HEX/値列のカーソルを手型に ──────────────
        private void DataGridView_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (e.ColumnIndex == COL_HEX || e.ColumnIndex == COL_VAL)
                dataGridView.Cursor = Cursors.Hand;
        }
        private void DataGridView_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView.Cursor = Cursors.Default;
        }

        // ═══════════════════════════════════════════════════════════
        // オーバーレイ編集（セルにぴったり重ねる）
        // ═══════════════════════════════════════════════════════════
        private void StartOverlayEdit(int rowIndex, int colIndex)
        {
            if (rowIndex < 0 || rowIndex >= _parameters.Count) return;

            _editRow = rowIndex;
            _editCol = colIndex;

            var param = _parameters[rowIndex];

            // ── セル矩形を panelGridOuter 座標系で取得 ──────────────
            // GetCellDisplayRectangle は DataGridView 相対座標を返す
            Rectangle cellRect = dataGridView.GetCellDisplayRectangle(colIndex, rowIndex, true);

            // DataGridView → スクリーン → panelGridOuter の変換
            Point screenPt = dataGridView.PointToScreen(cellRect.Location);
            Point panelPt  = panelGridOuter.PointToClient(screenPt);

            // ── オーバーレイのサイズ ────────────────────────────────
            // 幅  : セルの左端から panelGridOuter の右端まで（列幅に合わせて伸ばす）
            // 高さ : HexEditor に最低限必要な高さ（バイト数に応じて変える）
            int overlayW = panelGridOuter.Width - panelPt.X;
            int overlayH = Math.Max(150, Math.Min(250, param.Length * 20 + 60));

            // ── 表示位置（セルの直下。画面下にはみ出す場合はセルの上）──
            int overlayX = panelPt.X;
            int overlayY = panelPt.Y + cellRect.Height;   // セル直下

            if (overlayY + overlayH > panelGridOuter.Height)
                overlayY = panelPt.Y - overlayH;           // セルの上

            if (overlayY < 0) overlayY = panelPt.Y;

            _overlay.SetBytes(param.RawBytes);
            _overlay.Location = new Point(overlayX, overlayY);
            _overlay.Size     = new Size(Math.Max(overlayW, 400), overlayH);
            _overlay.Visible  = true;
            _overlay.BringToFront();
            _overlay.Focus();

            lblStatus.Text = $"編集中: [{param.Name}]   F2 / Ctrl+Enter = 確定    Esc = キャンセル";
        }

        // ── オーバーレイ確定 ────────────────────────────────────────
        private void Overlay_EditCompleted(object sender, BinaryEditCompletedEventArgs e)
        {
            if (_editRow < 0 || _editRow >= _parameters.Count) return;

            var param    = _parameters[_editRow];
            var newBytes = e.EditedBytes;

            // 固定長に合わせてトリム or ゼロ埋め
            byte[] adjusted = new byte[param.Length];
            Array.Copy(newBytes, adjusted, Math.Min(newBytes.Length, param.Length));

            param.RawBytes = adjusted;
            param.WriteToData(_binaryData);

            UpdateGridRow(_editRow);
            RefreshHexFull();   // タブ①にも即座に反映

            lblStatus.Text = $"更新完了: {param.Name}";
            _editRow = -1;
            _editCol = -1;
        }

        // ── オーバーレイキャンセル ──────────────────────────────────
        private void Overlay_EditCancelled(object sender, EventArgs e)
        {
            lblStatus.Text = _editRow >= 0
                ? $"キャンセル: {_parameters[_editRow].Name}"
                : "キャンセル";
            _editRow = -1;
            _editCol = -1;
        }

        // ═══════════════════════════════════════════════════════════
        // タブ切り替えイベント
        //  タブ①→② : HexEditorFull の内容をパラメータに同期
        //  タブ②→① : 最新バイナリを HexEditorFull に反映
        // ═══════════════════════════════════════════════════════════
        private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 編集中のオーバーレイを閉じる
            if (_overlay.Visible) _overlay.CancelEdit();

            if (tabControl.SelectedIndex == 0)
            {
                // タブ① に切り替わったとき：最新データを反映
                RefreshHexFull();
                lblStatus.Text = "バイナリ全体編集モード  ─  直接バイトを編集できます";
            }
            else
            {
                // タブ② に切り替わったとき：HexEditorFull の変更をパラメータに取り込む
                SyncFromHexFull();
                lblStatus.Text = "パラメータ編集モード  ─  HEX値または値の列をクリックして編集";
            }
        }

        // ═══════════════════════════════════════════════════════════
        // ファイル操作
        // ═══════════════════════════════════════════════════════════
        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (_overlay.Visible) _overlay.CancelEdit();

            using (var ofd = new OpenFileDialog())
            {
                ofd.Title  = "バイナリファイルを開く";
                ofd.Filter = "すべてのファイル (*.*)|*.*|バイナリファイル (*.bin)|*.bin";
                if (ofd.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _binaryData = File.ReadAllBytes(ofd.FileName);
                    foreach (var p in _parameters)
                    {
                        if (p.Offset + p.Length <= _binaryData.Length)
                            p.ExtractFromData(_binaryData);
                    }
                    RefreshGrid();
                    RefreshHexFull();
                    lblStatus.Text = $"読込完了: {ofd.FileName}  ({_binaryData.Length} bytes)";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"読込失敗:\n{ex.Message}", "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_overlay.Visible) _overlay.CommitEdit(); // 未確定があれば先に確定

            // タブ①が表示中なら HexEditorFull から最新データを取得
            if (tabControl.SelectedIndex == 0) SyncFromHexFull();

            using (var sfd = new SaveFileDialog())
            {
                sfd.Title      = "バイナリファイルを保存";
                sfd.Filter     = "バイナリファイル (*.bin)|*.bin|すべてのファイル (*.*)|*.*";
                sfd.DefaultExt = "bin";
                if (sfd.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(sfd.FileName, _binaryData);
                    lblStatus.Text = $"保存完了: {sfd.FileName}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"保存失敗:\n{ex.Message}", "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // ── Esc キーのグローバルキャッチ ──────────────────────────
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape && _overlay != null && _overlay.Visible)
            {
                _overlay.CancelEdit();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
