using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    /// <summary>
    /// メインフォーム
    ///
    /// タブ①「バイナリ全体編集」
    ///   WPFHexaEditor をフル画面で表示し、バイナリデータを直接編集する。
    ///
    /// タブ②「パラメータ編集」
    ///   DataGridView でパラメータ一覧を表示する。
    ///   HEX値列 または 値列をクリックすると、クリックしたセルの枠に
    ///   ぴったり重なる BinaryEditorOverlay が出現し、セルを直接編集
    ///   しているかのような操作感を実現する。
    ///   Enter / F2 で確定、Esc でキャンセル。
    /// </summary>
    public partial class MainForm : Form
    {
        // ── フィールド ──────────────────────────────────────────────
        private byte[]                _binaryData;
        private List<BinaryParameter> _parameters;
        private BinaryEditorOverlay   _overlay;
        private int                   _editRow = -1;
        private int                   _editCol = -1;

        // DataGridView 列インデックス定数
        private const int COL_NAME   = 0;
        private const int COL_OFFSET = 1;
        private const int COL_LEN    = 2;
        private const int COL_TYPE   = 3;
        private const int COL_HEX    = 4;
        private const int COL_VAL    = 5;

        // ════════════════════════════════════════════════════════════
        public MainForm()
        {
            InitializeComponent();
            InitOverlay();
            InitSampleData();
        }

        // ════════════════════════════════════════════════════════════
        // オーバーレイ初期化
        // ════════════════════════════════════════════════════════════
        private void InitOverlay()
        {
            _overlay = new BinaryEditorOverlay();
            _overlay.Visible = false;

            _overlay.EditCompleted += Overlay_EditCompleted;
            _overlay.EditCancelled += Overlay_EditCancelled;

            // panelGridOuter に追加 → DataGridView と同一座標系で重なる
            panelGridOuter.Controls.Add(_overlay);
            _overlay.BringToFront();
        }

        // ════════════════════════════════════════════════════════════
        // サンプルデータ初期化
        // ════════════════════════════════════════════════════════════
        private void InitSampleData()
        {
            _binaryData = new byte[64];
            _binaryData[0] = 0x42; _binaryData[1] = 0x49;
            _binaryData[2] = 0x4E; _binaryData[3] = 0x01;
            _binaryData[4] = 0x40; _binaryData[5] = 0x00;
            _binaryData[6] = 0x60; _binaryData[7] = 0x50;
            _binaryData[8] = 0x40; _binaryData[9] = 0x30;
            byte[] fb = BitConverter.GetBytes(3.14f);
            Array.Copy(fb, 0, _binaryData, 10, 4);
            byte[] nb = Encoding.ASCII.GetBytes("Device01");
            Array.Copy(nb, 0, _binaryData, 14, 8);
            var rnd = new byte[42];
            new Random(42).NextBytes(rnd);
            rnd.CopyTo(_binaryData, 22);
            for (int i = 22; i < 64; i++) _binaryData[i] = (byte)(i * 3 % 256);

            _parameters = new List<BinaryParameter>
            {
                new BinaryParameter("Magic Number",  0,  3, "Bytes"),
                new BinaryParameter("Version",       3,  1, "UInt8"),
                new BinaryParameter("Data Size",     4,  2, "UInt16"),
                new BinaryParameter("Timestamp",     6,  4, "UInt32"),
                new BinaryParameter("Sensor Value", 10,  4, "Float"),
                new BinaryParameter("Device Name",  14,  8, "String"),
                new BinaryParameter("Param A",      22,  2, "UInt16"),
                new BinaryParameter("Param B",      24,  4, "UInt32"),
                new BinaryParameter("Param C",      28,  1, "UInt8"),
                new BinaryParameter("Reserved",     29, 35, "Bytes"),
            };
            foreach (var p in _parameters) p.ExtractFromData(_binaryData);

            RefreshGrid();
            RefreshHexFull();
        }

        // ════════════════════════════════════════════════════════════
        // タブ① ─ バイナリ全体 HexEditor
        // ════════════════════════════════════════════════════════════
        private void RefreshHexFull()
        {
            if (_binaryData == null) return;
            hexEditorFull.Stream = new MemoryStream((byte[])_binaryData.Clone());
        }

        private void SyncFromHexFull()
        {
            var ms = hexEditorFull.Stream as MemoryStream;
            if (ms == null) return;
            _binaryData = ms.ToArray();
            foreach (var p in _parameters) p.ExtractFromData(_binaryData);
            RefreshGrid();
        }

        // ════════════════════════════════════════════════════════════
        // タブ② ─ DataGridView
        // ════════════════════════════════════════════════════════════
        private void RefreshGrid()
        {
            dataGridView.Rows.Clear();
            foreach (var p in _parameters)
            {
                int ri = dataGridView.Rows.Add(
                    p.Name, p.Offset, p.Length, p.DataType,
                    p.HexValue, p.InterpretedValue);
                dataGridView.Rows[ri].Cells[COL_NAME].Style.BackColor
                    = Color.FromArgb(225, 235, 255);
            }
        }

        private void UpdateGridRow(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= _parameters.Count) return;
            if (rowIndex >= dataGridView.Rows.Count) return;
            var p   = _parameters[rowIndex];
            var row = dataGridView.Rows[rowIndex];
            row.Cells[COL_HEX].Value = p.HexValue;
            row.Cells[COL_VAL].Value = p.InterpretedValue;
        }

        // ── セルクリック ───────────────────────────────────────────
        private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (e.ColumnIndex == COL_HEX || e.ColumnIndex == COL_VAL)
                StartOverlayEdit(e.RowIndex, e.ColumnIndex);
        }

        // ── マウスホバー：編集列はカーソルを手型に ────────────────
        private void DataGridView_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (e.ColumnIndex == COL_HEX || e.ColumnIndex == COL_VAL)
                dataGridView.Cursor = Cursors.Hand;
        }
        private void DataGridView_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView.Cursor = Cursors.Default;
        }

        // ════════════════════════════════════════════════════════════
        // オーバーレイ編集 ─ クリックしたセルの枠に完全一致して表示
        // ════════════════════════════════════════════════════════════
        private void StartOverlayEdit(int rowIndex, int colIndex)
        {
            if (rowIndex < 0 || rowIndex >= _parameters.Count) return;

            // 他のセルを編集中なら先に確定
            if (_overlay.Visible) _overlay.CommitEdit();

            _editRow = rowIndex;
            _editCol = colIndex;

            var param = _parameters[rowIndex];

            // DataGridView 座標系でのセル矩形を取得
            Rectangle cellRect = dataGridView.GetCellDisplayRectangle(colIndex, rowIndex, true);
            if (cellRect.IsEmpty) return; // スクロールで非表示のセルは無視

            // ① 先に位置・サイズを決定
            _overlay.FitToCell(cellRect, dataGridView, panelGridOuter, param.Name);

            // ② Visible = true にして WPF が描画準備を完了させる
            _overlay.Visible = true;
            _overlay.BringToFront();

            // ③ 表示状態になってから Stream をセット（WPFHexaEditor は非表示時に
            //    Stream を設定しても描画されないケースがあるため順序が重要）
            _overlay.SetBytes(param.RawBytes);

            _overlay.Focus();

            lblStatus.Text =
                $"編集中: [{param.Name}]  ─  Enter / F2 = 確定    Esc = キャンセル";
        }

        // ── 確定 ───────────────────────────────────────────────────
        private void Overlay_EditCompleted(object sender, BinaryEditCompletedEventArgs e)
        {
            if (_editRow < 0 || _editRow >= _parameters.Count) return;

            var param = _parameters[_editRow];
            byte[] adjusted = new byte[param.Length];
            Array.Copy(e.EditedBytes, adjusted,
                       Math.Min(e.EditedBytes.Length, param.Length));

            param.RawBytes = adjusted;
            param.WriteToData(_binaryData);
            UpdateGridRow(_editRow);
            RefreshHexFull();

            lblStatus.Text = $"更新完了: {param.Name}";
            _editRow = -1;
            _editCol = -1;
        }

        // ── キャンセル ─────────────────────────────────────────────
        private void Overlay_EditCancelled(object sender, EventArgs e)
        {
            lblStatus.Text = _editRow >= 0
                ? $"キャンセル: {_parameters[_editRow].Name}"
                : "キャンセル";
            _editRow = -1;
            _editCol = -1;
        }

        // ════════════════════════════════════════════════════════════
        // タブ切り替え
        // ════════════════════════════════════════════════════════════
        private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_overlay.Visible) _overlay.CancelEdit();

            if (tabControl.SelectedIndex == 0)
            {
                RefreshHexFull();
                lblStatus.Text = "バイナリ全体編集モード  ─  直接バイトを編集できます";
            }
            else
            {
                SyncFromHexFull();
                lblStatus.Text = "パラメータ編集モード  ─  HEX値または値の列をクリックして編集";
            }
        }

        // ════════════════════════════════════════════════════════════
        // ファイル操作
        // ════════════════════════════════════════════════════════════
        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (_overlay.Visible) _overlay.CancelEdit();

            using (var ofd = new OpenFileDialog())
            {
                ofd.Title  = "バイナリファイルを開く";
                ofd.Filter = "すべてのファイル (*.*)|*.*|バイナリファイル (*.bin)|*.bin";
                if (ofd.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _binaryData = File.ReadAllBytes(ofd.FileName);
                    foreach (var p in _parameters)
                        if (p.Offset + p.Length <= _binaryData.Length)
                            p.ExtractFromData(_binaryData);
                    RefreshGrid();
                    RefreshHexFull();
                    lblStatus.Text = $"読込完了: {ofd.FileName}  ({_binaryData.Length} bytes)";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"読込失敗:\n{ex.Message}", "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_overlay.Visible) _overlay.CommitEdit();
            if (tabControl.SelectedIndex == 0) SyncFromHexFull();

            using (var sfd = new SaveFileDialog())
            {
                sfd.Title      = "バイナリファイルを保存";
                sfd.Filter     = "バイナリファイル (*.bin)|*.bin|すべてのファイル (*.*)|*.*";
                sfd.DefaultExt = "bin";
                if (sfd.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(sfd.FileName, _binaryData);
                    lblStatus.Text = $"保存完了: {sfd.FileName}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"保存失敗:\n{ex.Message}", "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // ── Esc キーのグローバルキャッチ ──────────────────────────
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape && _overlay != null && _overlay.Visible)
            {
                _overlay.CancelEdit();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
