using System.Windows.Forms.Integration; // ElementHost（WindowsFormsIntegration.dll）

namespace BinaryEditorApp
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // コントロール宣言
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton btnOpen;
        private System.Windows.Forms.ToolStripButton btnSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel toolStripLabelHint;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Panel panelGrid;
        private System.Windows.Forms.Label labelGrid;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Panel panelFullHex;
        private System.Windows.Forms.Label labelFullHex;
        // ElementHost は WindowsFormsIntegration.dll（System.Windows.Forms.Integration名前空間）
        private ElementHost elementHostFull;
        private WpfHexaEditor.HexEditor hexEditorFull;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。
        /// このメソッドの内容をコード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // ToolStrip
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.btnOpen = new System.Windows.Forms.ToolStripButton();
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabelHint = new System.Windows.Forms.ToolStripLabel();

            // SplitContainer
            this.splitContainer = new System.Windows.Forms.SplitContainer();

            // panelGrid（上部パネル：DataGridView + オーバーレイエリア）
            this.panelGrid = new System.Windows.Forms.Panel();
            this.labelGrid = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();

            // panelFullHex（下部パネル：全体HexView）
            this.panelFullHex = new System.Windows.Forms.Panel();
            this.labelFullHex = new System.Windows.Forms.Label();
            // elementHostFull は hexEditorFull と合わせて後で初期化する

            // StatusStrip
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();

            // --- ToolStrip設定 ---
            this.toolStrip.SuspendLayout();
            this.btnOpen.Text = "📂 開く";
            this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            this.btnSave.Text = "💾 保存";
            this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            this.toolStripLabelHint.Text = "  ※ HEX列またはValue列をクリックすると編集モードになります";
            this.toolStripLabelHint.ForeColor = System.Drawing.Color.DimGray;
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.btnOpen,
                this.btnSave,
                this.toolStripSeparator1,
                this.toolStripLabelHint
            });
            this.toolStrip.ResumeLayout(false);

            // --- SplitContainer設定 ---
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.SuspendLayout();
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.splitContainer.SplitterDistance = 320;
            this.splitContainer.SplitterWidth = 6;

            // --- DataGridView設定 ---
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AllowUserToResizeRows = false;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.MultiSelect = false;
            this.dataGridView.ReadOnly = true;  // 通常は読み取り専用（編集はオーバーレイで行う）
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.RowHeadersVisible = true;
            this.dataGridView.RowHeadersWidth = 30;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView.GridColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.AliceBlue;

            // 列の追加
            var colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colName.HeaderText = "パラメータ名";
            colName.Name = "ColName";
            colName.FillWeight = 20;
            colName.ReadOnly = true;

            var colOffset = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colOffset.HeaderText = "オフセット";
            colOffset.Name = "ColOffset";
            colOffset.FillWeight = 10;
            colOffset.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            colOffset.ReadOnly = true;

            var colLength = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colLength.HeaderText = "長さ(Bytes)";
            colLength.Name = "ColLength";
            colLength.FillWeight = 10;
            colLength.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            colLength.ReadOnly = true;

            var colDataType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colDataType.HeaderText = "データ型";
            colDataType.Name = "ColDataType";
            colDataType.FillWeight = 10;
            colDataType.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            colDataType.ReadOnly = true;

            var colHex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colHex.HeaderText = "HEX値（クリックで編集）";
            colHex.Name = "ColHex";
            colHex.FillWeight = 30;
            colHex.DefaultCellStyle.Font = new System.Drawing.Font("Courier New", 9F);
            colHex.DefaultCellStyle.BackColor = System.Drawing.Color.LightYellow;
            colHex.ReadOnly = true;

            var colValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colValue.HeaderText = "値（クリックで編集）";
            colValue.Name = "ColValue";
            colValue.FillWeight = 20;
            colValue.DefaultCellStyle.BackColor = System.Drawing.Color.LightYellow;
            colValue.ReadOnly = true;

            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                colName, colOffset, colLength, colDataType, colHex, colValue
            });

            // DataGridViewイベント
            this.dataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_CellClick);
            this.dataGridView.SelectionChanged += new System.EventHandler(this.DataGridView_SelectionChanged);

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();

            // --- labelGrid設定 ---
            this.labelGrid.Text = "　パラメータ一覧　（HEX値 / 値 の列をクリックするとバイナリエディタで編集できます）";
            this.labelGrid.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelGrid.Height = 24;
            this.labelGrid.BackColor = System.Drawing.Color.SteelBlue;
            this.labelGrid.ForeColor = System.Drawing.Color.White;
            this.labelGrid.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.labelGrid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // --- panelGrid設定（DataGridView + オーバーレイコンテナ）---
            this.panelGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGrid.Controls.Add(this.dataGridView);
            this.panelGrid.Controls.Add(this.labelGrid);

            // --- WPFHexEditor全体表示用 ---
            // ※ WPFHexaEditorのプロパティ名はバージョンにより異なる場合があるため
            //   確実に存在する最低限のプロパティのみ設定する
            this.hexEditorFull = new WpfHexaEditor.HexEditor();
            this.hexEditorFull.ReadOnlyMode = true;

            this.elementHostFull = new ElementHost();
            this.elementHostFull.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elementHostFull.Child = this.hexEditorFull;

            // --- labelFullHex設定 ---
            this.labelFullHex.Text = "　バイナリ全体ビュー（読み取り専用：パラメータ選択時に対応箇所をハイライト表示）";
            this.labelFullHex.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelFullHex.Height = 24;
            this.labelFullHex.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.labelFullHex.ForeColor = System.Drawing.Color.White;
            this.labelFullHex.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.labelFullHex.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // --- panelFullHex設定 ---
            this.panelFullHex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFullHex.Controls.Add(this.elementHostFull);
            this.panelFullHex.Controls.Add(this.labelFullHex);

            // SplitContainerにパネルを追加
            this.splitContainer.Panel1.Controls.Add(this.panelGrid);
            this.splitContainer.Panel2.Controls.Add(this.panelFullHex);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);

            // --- StatusStrip設定 ---
            this.statusStrip.SuspendLayout();
            this.toolStripStatusLabel.Text = "準備完了　｜　HEX値または値の列をクリックして編集を開始してください";
            this.toolStripStatusLabel.Spring = true;
            this.toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.statusStrip.Items.Add(this.toolStripStatusLabel);
            this.statusStrip.ResumeLayout(false);

            // --- MainForm設定 ---
            this.SuspendLayout();
            this.Text = "バイナリエディタ - WPFHexaEditor (.NET Framework 4.8)";
            this.ClientSize = new System.Drawing.Size(1024, 720);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Font = new System.Drawing.Font("MS UI Gothic", 9F);

            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.statusStrip);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
