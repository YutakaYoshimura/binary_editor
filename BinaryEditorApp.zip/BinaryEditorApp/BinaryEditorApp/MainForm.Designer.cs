using System.Windows.Forms.Integration;

namespace BinaryEditorApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        // ── 共通 ────────────────────────────────────────────
        private System.Windows.Forms.ToolStrip           toolStrip;
        private System.Windows.Forms.ToolStripButton     btnOpen;
        private System.Windows.Forms.ToolStripButton     btnSave;
        private System.Windows.Forms.ToolStripSeparator  toolStripSep;
        private System.Windows.Forms.ToolStripLabel      lblHint;
        private System.Windows.Forms.StatusStrip         statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel lblStatus;
        private System.Windows.Forms.TabControl          tabControl;

        // ── タブ① バイナリ全体編集 ────────────────────────
        private System.Windows.Forms.TabPage   tabPageHex;
        private System.Windows.Forms.Panel     panelHexFull;
        private ElementHost                    elementHostFull;
        private WpfHexaEditor.HexEditor        hexEditorFull;

        // ── タブ② パラメータ編集（DataGridView）──────────
        private System.Windows.Forms.TabPage       tabPageGrid;
        private System.Windows.Forms.Panel         panelGridOuter;
        private System.Windows.Forms.DataGridView  dataGridView;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        private void InitializeComponent()
        {
            this.components      = new System.ComponentModel.Container();
            this.toolStrip       = new System.Windows.Forms.ToolStrip();
            this.btnOpen         = new System.Windows.Forms.ToolStripButton();
            this.btnSave         = new System.Windows.Forms.ToolStripButton();
            this.toolStripSep    = new System.Windows.Forms.ToolStripSeparator();
            this.lblHint         = new System.Windows.Forms.ToolStripLabel();
            this.statusStrip     = new System.Windows.Forms.StatusStrip();
            this.lblStatus       = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControl      = new System.Windows.Forms.TabControl();
            this.tabPageHex      = new System.Windows.Forms.TabPage();
            this.tabPageGrid     = new System.Windows.Forms.TabPage();
            this.panelHexFull    = new System.Windows.Forms.Panel();
            this.panelGridOuter  = new System.Windows.Forms.Panel();
            this.dataGridView    = new System.Windows.Forms.DataGridView();
            this.hexEditorFull   = new WpfHexaEditor.HexEditor();
            this.elementHostFull = new ElementHost();

            // ToolStrip
            this.btnOpen.Text         = "開く";
            this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnOpen.Click       += new System.EventHandler(this.btnOpen_Click);
            this.btnSave.Text         = "保存";
            this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnSave.Click       += new System.EventHandler(this.btnSave_Click);
            this.lblHint.Text         = "  タブ1：バイナリ全体を直接編集  ／  タブ2：パラメータ行のHEX値/値列クリックでセル編集";
            this.lblHint.ForeColor    = System.Drawing.Color.DimGray;
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[]
            {
                this.btnOpen, this.btnSave, this.toolStripSep, this.lblHint
            });

            // StatusStrip
            this.lblStatus.Spring    = true;
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStatus.Text      = "準備完了";
            this.statusStrip.Items.Add(this.lblStatus);

            // ═══════════════════════════════
            // タブ① バイナリ全体編集
            // ═══════════════════════════════
            this.hexEditorFull.ReadOnlyMode = false;
            this.elementHostFull.Dock       = System.Windows.Forms.DockStyle.Fill;
            this.elementHostFull.Child      = this.hexEditorFull;
            this.panelHexFull.Dock          = System.Windows.Forms.DockStyle.Fill;
            this.panelHexFull.Controls.Add(this.elementHostFull);
            this.tabPageHex.Text = "バイナリ全体編集";
            this.tabPageHex.Controls.Add(this.panelHexFull);

            // ═══════════════════════════════
            // タブ② パラメータ編集
            // ═══════════════════════════════
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();

            this.dataGridView.Dock                        = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.AllowUserToAddRows          = false;
            this.dataGridView.AllowUserToDeleteRows       = false;
            this.dataGridView.AllowUserToResizeRows       = false;
            this.dataGridView.ReadOnly                    = true;
            this.dataGridView.SelectionMode               = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.MultiSelect                 = false;
            this.dataGridView.AutoSizeColumnsMode         = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.RowHeadersVisible           = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.BackgroundColor             = System.Drawing.Color.White;
            this.dataGridView.BorderStyle                 = System.Windows.Forms.BorderStyle.None;
            this.dataGridView.GridColor                   = System.Drawing.Color.LightSteelBlue;
            this.dataGridView.Font                        = new System.Drawing.Font("MS UI Gothic", 10F);
            this.dataGridView.RowTemplate.Height          = 28;
            this.dataGridView.AlternatingRowsDefaultCellStyle.BackColor            = System.Drawing.Color.AliceBlue;
            this.dataGridView.ColumnHeadersDefaultCellStyle.BackColor              = System.Drawing.Color.SteelBlue;
            this.dataGridView.ColumnHeadersDefaultCellStyle.ForeColor              = System.Drawing.Color.White;
            this.dataGridView.ColumnHeadersDefaultCellStyle.Font                   = new System.Drawing.Font("MS UI Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.dataGridView.EnableHeadersVisualStyles                             = false;

            // 列定義
            var colName   = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colName.HeaderText   = "パラメータ名";
            colName.Name         = "ColName";
            colName.FillWeight   = 18;
            colName.ReadOnly     = true;

            var colOffset = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colOffset.HeaderText = "Offset";
            colOffset.Name       = "ColOffset";
            colOffset.FillWeight = 8;
            colOffset.ReadOnly   = true;
            colOffset.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            var colLen    = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colLen.HeaderText    = "Len";
            colLen.Name          = "ColLen";
            colLen.FillWeight    = 6;
            colLen.ReadOnly      = true;
            colLen.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            var colType   = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colType.HeaderText   = "型";
            colType.Name         = "ColType";
            colType.FillWeight   = 8;
            colType.ReadOnly     = true;
            colType.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            // HEX値列（黄色背景 = 編集可能の合図）
            var colHex    = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colHex.HeaderText    = "HEX値  [クリックで編集]";
            colHex.Name          = "ColHex";
            colHex.FillWeight    = 35;
            colHex.ReadOnly      = true;
            colHex.DefaultCellStyle.Font      = new System.Drawing.Font("Courier New", 9F);
            colHex.DefaultCellStyle.BackColor = System.Drawing.Color.LightYellow;

            // 値列（黄色背景 = 編集可能の合図）
            var colVal    = new System.Windows.Forms.DataGridViewTextBoxColumn();
            colVal.HeaderText    = "値  [クリックで編集]";
            colVal.Name          = "ColVal";
            colVal.FillWeight    = 25;
            colVal.ReadOnly      = true;
            colVal.DefaultCellStyle.BackColor = System.Drawing.Color.LightYellow;

            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]
            {
                colName, colOffset, colLen, colType, colHex, colVal
            });

            this.dataGridView.CellClick      += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_CellClick);
            this.dataGridView.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_CellMouseEnter);
            this.dataGridView.CellMouseLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_CellMouseLeave);

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();

            // panelGridOuter（オーバーレイとDataGridViewを同一座標系に載せる）
            this.panelGridOuter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGridOuter.Controls.Add(this.dataGridView);

            this.tabPageGrid.Text = "パラメータ編集";
            this.tabPageGrid.Controls.Add(this.panelGridOuter);

            // TabControl
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font = new System.Drawing.Font("MS UI Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.tabControl.TabPages.Add(this.tabPageHex);
            this.tabControl.TabPages.Add(this.tabPageGrid);
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.TabControl_SelectedIndexChanged);

            // MainForm
            this.SuspendLayout();
            this.Text          = "バイナリエディタ  (.NET Framework 4.8 / WPFHexaEditor)";
            this.ClientSize    = new System.Drawing.Size(1100, 740);
            this.MinimumSize   = new System.Drawing.Size(800, 600);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Font          = new System.Drawing.Font("MS UI Gothic", 9F);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.statusStrip);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
