# BinaryEditorApp - バイナリエディタ

## 概要

WinForms (.NET Framework 4.8) + WPFHexaEditor を使用したバイナリエディタアプリケーションです。

## 開発環境

- Visual Studio 2019
- .NET Framework 4.8
- WinForms
- WPFHexaEditor (NuGet)

## 要件対応内容

### ① バイナリデータ全体を表示して修正
- 下部パネルに **WPFHexaEditor** を使った全体バイナリビュー（読み取り専用）
- パラメータ選択時に対応するオフセットをハイライト表示

### ② DataGridView で各パラメータ毎に入力
- 上部パネルの **DataGridView** でパラメータ一覧表示
  - パラメータ名 / オフセット / 長さ / データ型 / HEX値 / 値
- **表示時**: テキストセル（DataGridView のテキストコントロール）
- **編集時**: HEX値列 または 値列をクリック → **BinaryEditorOverlay（WPFHexaEditor）** がテキストセルの上に重なって表示
  - F2 または Ctrl+Enter で確定
  - Esc でキャンセル
  - フォーカス移動時に自動確定

## セットアップ手順

### 1. WPFHexaEditor NuGet パッケージの取得

Visual Studio 2019 でプロジェクトを開いた後、NuGet パッケージマネージャーから取得します。

**方法A: NuGet パッケージマネージャー GUI**
1. ソリューションエクスプローラーで `BinaryEditorApp` プロジェクトを右クリック
2. 「NuGet パッケージの管理」を選択
3. 検索欄に `WPFHexaEditor` と入力
4. バージョン `3.0.0` をインストール

**方法B: パッケージマネージャーコンソール**
```
PM> Install-Package WPFHexaEditor -Version 3.0.0
```

### 2. ビルドと実行

```
1. BinaryEditorApp.sln を Visual Studio 2019 で開く
2. NuGet パッケージを復元（ビルド → NuGet パッケージの復元）
3. F5 で実行
```

## プロジェクト構成

```
BinaryEditorApp/
├── BinaryEditorApp.sln          # ソリューションファイル
└── BinaryEditorApp/
    ├── BinaryEditorApp.csproj   # プロジェクトファイル
    ├── Program.cs               # エントリーポイント
    ├── MainForm.cs              # メインフォーム（ロジック）
    ├── MainForm.Designer.cs     # メインフォーム（デザイナー定義）
    ├── MainForm.resx            # リソースファイル
    ├── BinaryParameter.cs       # バイナリパラメータモデル
    ├── BinaryEditorOverlay.cs   # HexEditorオーバーレイコントロール
    ├── packages.config          # NuGet設定
    └── Properties/
        └── AssemblyInfo.cs      # アセンブリ情報
```

## 主要クラス説明

### `BinaryParameter.cs`
- バイナリデータ内の各パラメータを表すモデルクラス
- オフセット・長さ・データ型を保持
- `ExtractFromData()` でバイナリデータからバイトを切り出し
- `WriteToData()` で編集後のバイトをバイナリデータに書き戻し
- 対応データ型: `UInt8`, `Int8`, `UInt16`, `Int16`, `UInt32`, `Int32`, `Float`, `String`, `Bytes`

### `BinaryEditorOverlay.cs`
- **WPFHexaEditor を WinForms の ElementHost で包んだオーバーレイコントロール**
- DataGridView のセルの上に重ねて表示（Z-Order制御）
- `SetBytes()` / `GetBytes()` でバイト配列のやり取り
- `EditCompleted` イベント（F2 / Ctrl+Enter / フォーカス喪失）
- `EditCancelled` イベント（Esc キー）

### `MainForm.cs`
- DataGridView にパラメータを表示
- セルクリック時に `BinaryEditorOverlay` を該当セルの位置に表示
- 編集完了時にパラメータ・全体バイナリデータを更新
- ファイルの読み込み / 保存機能

## 操作方法

| 操作 | 動作 |
|------|------|
| HEX値 列をクリック | バイナリエディタオーバーレイが表示される |
| 値 列をクリック | バイナリエディタオーバーレイが表示される |
| F2 または Ctrl+Enter | 編集内容を確定して反映 |
| Esc キー | 編集をキャンセル |
| フォーカス移動 | 自動的に編集確定 |
| 📂 開く ボタン | バイナリファイルを読み込む |
| 💾 保存 ボタン | 現在のデータをバイナリファイルに保存 |

## 注意事項

- WPFHexaEditor は WinForms の `ElementHost` 経由で組み込みます
- `System.Windows.Forms.Integration` は .NET Framework 標準で利用可能です
- プロジェクトファイルに `PresentationCore`, `PresentationFramework`, `WindowsBase` の参照が含まれています
