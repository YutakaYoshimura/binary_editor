namespace TreeViewIconMethodsSample;

/// <summary>
/// 「1ノードに複数アイコン/状態を表示する」代表的な5つの方法を、
/// タブごとに実際に動かして比較できるサンプル。
/// </summary>
public partial class MainForm : Form
{
    public MainForm()
    {
        Text = "TreeNode 複数アイコン表示 - 方法比較サンプル";
        Width = 620;
        Height = 620;
        StartPosition = FormStartPosition.CenterScreen;

        var tabs = new TabControl { Dock = DockStyle.Fill };
        tabs.TabPages.Add(BuildStateImageListTab());
        tabs.TabPages.Add(BuildOwnerDrawBadgeTab());
        tabs.TabPages.Add(BuildPreCompositedTab());
        tabs.TabPages.Add(BuildCheckBoxTab());
        tabs.TabPages.Add(BuildColorFontTab());
        Controls.Add(tabs);
    }

    // ------------------------------------------------------------
    // 方法1: StateImageList (メインアイコンの左に状態アイコンを表示)
    // ------------------------------------------------------------
    private TabPage BuildStateImageListTab()
    {
        var page = new TabPage("① StateImageList");

        var mainImages = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        mainImages.Images.Add(IconFactory.FolderClosed()); // 0
        mainImages.Images.Add(IconFactory.File());          // 1

        // StateImageList は index=0 が「状態なし」として扱われる点に注意。
        // 実際に状態を表す画像は index=1 以降を使う。
        var stateImages = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        stateImages.Images.Add(new Bitmap(16, 16));       // 0: 状態なし(透明)
        stateImages.Images.Add(IconFactory.CheckCircle()); // 1: OK
        stateImages.Images.Add(IconFactory.WarningTriangle()); // 2: 警告
        stateImages.Images.Add(IconFactory.ErrorCircle());     // 3: エラー

        var tree = new TreeView
        {
            Dock = DockStyle.Fill,
            ImageList = mainImages,
            StateImageList = stateImages
        };

        var root = new TreeNode("プロジェクト") { ImageIndex = 0, SelectedImageIndex = 0, StateImageIndex = 0 };
        root.Nodes.Add(new TreeNode("Program.cs") { ImageIndex = 1, SelectedImageIndex = 1, StateImageIndex = 1 });
        root.Nodes.Add(new TreeNode("Form1.cs") { ImageIndex = 1, SelectedImageIndex = 1, StateImageIndex = 2 });
        root.Nodes.Add(new TreeNode("Broken.cs") { ImageIndex = 1, SelectedImageIndex = 1, StateImageIndex = 3 });
        tree.Nodes.Add(root);
        tree.ExpandAll();

        page.Controls.Add(tree);
        page.Controls.Add(Note(
            "メインアイコンの左側に「状態アイコン」がもう1つ並びます。\n" +
            "node.StateImageIndex を切り替えるだけで実装できて手軽ですが、\n" +
            "表示位置は固定(左側)でカスタマイズ性は低めです。"));
        return page;
    }

    // ------------------------------------------------------------
    // 方法2: オーナードローでバッジ(小アイコン)を重ねて表示
    // ------------------------------------------------------------
    private TabPage BuildOwnerDrawBadgeTab()
    {
        var page = new TabPage("② オーナードロー(バッジ重ね)");

        var images = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        images.Images.Add(IconFactory.FolderClosed()); // 0
        images.Images.Add(IconFactory.File());          // 1

        var badgeOk = IconFactory.CheckCircle(10);
        var badgeWarn = IconFactory.WarningTriangle(10);
        var badgeError = IconFactory.ErrorCircle(10);
        var badgeSync = IconFactory.SyncArrows(10);

        var tree = new TreeView { Dock = DockStyle.Fill, ImageList = images, DrawMode = TreeViewDrawMode.OwnerDrawText };

        var root = new TreeNode("同期フォルダー") { ImageIndex = 0, SelectedImageIndex = 0, Tag = "sync" };
        root.Nodes.Add(new TreeNode("完了.txt") { ImageIndex = 1, SelectedImageIndex = 1, Tag = "ok" });
        root.Nodes.Add(new TreeNode("競合あり.txt") { ImageIndex = 1, SelectedImageIndex = 1, Tag = "warning" });
        root.Nodes.Add(new TreeNode("送信失敗.txt") { ImageIndex = 1, SelectedImageIndex = 1, Tag = "error" });
        tree.Nodes.Add(root);
        tree.ExpandAll();

        tree.DrawNode += (s, e) =>
        {
            e.DrawDefault = true; // アイコン・テキストは標準描画に任せる

            Image? badge = (e.Node?.Tag as string) switch
            {
                "ok" => badgeOk,
                "warning" => badgeWarn,
                "error" => badgeError,
                "sync" => badgeSync,
                _ => null
            };
            if (badge != null)
            {
                // メインアイコンはテキスト領域(e.Bounds)の左側、幅16px+余白で描画されている
                int iconLeft = e.Bounds.Left - 18;
                int x = iconLeft + 16 - badge.Width + 2;
                int y = e.Bounds.Top + 16 - badge.Height + 2;
                e.Graphics.DrawImage(badge, x, y, badge.Width, badge.Height);
            }
        };

        page.Controls.Add(tree);
        page.Controls.Add(Note(
            "DrawMode = OwnerDrawText にして DrawNode イベント内で標準描画の上から\n" +
            "小さいバッジ画像を重ねています。位置・個数を自由に決められるため\n" +
            "最も柔軟ですが、描画コードは自分で書く必要があります。"));
        return page;
    }

    // ------------------------------------------------------------
    // 方法3: 事前に合成した1枚絵をImageListに登録
    // ------------------------------------------------------------
    private TabPage BuildPreCompositedTab()
    {
        var page = new TabPage("③ 事前合成アイコン");

        var images = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        var folder = IconFactory.FolderClosed();
        var file = IconFactory.File();
        images.Images.Add(folder);                                              // 0: フォルダーのみ
        images.Images.Add(file);                                                 // 1: ファイルのみ
        images.Images.Add(IconFactory.Overlay(file, IconFactory.Star(10)));      // 2: ファイル+お気に入り
        images.Images.Add(IconFactory.Overlay(file, IconFactory.WarningTriangle(10))); // 3: ファイル+警告
        images.Images.Add(IconFactory.Overlay(folder, IconFactory.ErrorCircle(10)));  // 4: フォルダー+エラー

        var tree = new TreeView { Dock = DockStyle.Fill, ImageList = images };
        var root = new TreeNode("バックアップ") { ImageIndex = 4, SelectedImageIndex = 4 };
        root.Nodes.Add(new TreeNode("重要レポート.docx") { ImageIndex = 2, SelectedImageIndex = 2 });
        root.Nodes.Add(new TreeNode("破損データ.bin") { ImageIndex = 3, SelectedImageIndex = 3 });
        root.Nodes.Add(new TreeNode("通常ファイル.txt") { ImageIndex = 1, SelectedImageIndex = 1 });
        tree.Nodes.Add(root);
        tree.ExpandAll();

        page.Controls.Add(tree);
        page.Controls.Add(Note(
            "「フォルダー+エラー」「ファイル+星」のように組み合わせ済みの\n" +
            "1枚絵をあらかじめ作って ImageList に登録する方法です。実装は単純ですが、\n" +
            "組み合わせパターンが増えると画像の数が掛け算式に増えるのが欠点です。"));
        return page;
    }

    // ------------------------------------------------------------
    // 方法4: CheckBoxes (オン/オフの二値状態)
    // ------------------------------------------------------------
    private TabPage BuildCheckBoxTab()
    {
        var page = new TabPage("④ CheckBoxes");

        var images = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        images.Images.Add(IconFactory.FolderClosed()); // 0
        images.Images.Add(IconFactory.File());          // 1

        var tree = new TreeView { Dock = DockStyle.Fill, ImageList = images, CheckBoxes = true };
        var root = new TreeNode("タスク一覧") { ImageIndex = 0, SelectedImageIndex = 0 };
        root.Nodes.Add(new TreeNode("設計書を作成") { ImageIndex = 1, SelectedImageIndex = 1, Checked = true });
        root.Nodes.Add(new TreeNode("レビュー依頼") { ImageIndex = 1, SelectedImageIndex = 1 });
        root.Nodes.Add(new TreeNode("リリース") { ImageIndex = 1, SelectedImageIndex = 1 });
        tree.Nodes.Add(root);
        tree.ExpandAll();

        page.Controls.Add(tree);
        page.Controls.Add(Note(
            "TreeView.CheckBoxes = true を設定するだけで、アイコンの左に\n" +
            "チェックボックスが表示されます。「完了/未完了」のような二値の状態に\n" +
            "限定されますが、実装コストは最小です。"));
        return page;
    }

    // ------------------------------------------------------------
    // 方法5: 色分け・フォント装飾・記号プレフィックスで状態を表現
    // ------------------------------------------------------------
    private TabPage BuildColorFontTab()
    {
        var page = new TabPage("⑤ 色・フォント・記号");

        var images = new ImageList { ImageSize = new Size(16, 16), ColorDepth = ColorDepth.Depth32Bit };
        images.Images.Add(IconFactory.FolderClosed()); // 0
        images.Images.Add(IconFactory.File());          // 1

        var tree = new TreeView { Dock = DockStyle.Fill, ImageList = images, DrawMode = TreeViewDrawMode.OwnerDrawText };
        var root = new TreeNode("受信トレイ") { ImageIndex = 0, SelectedImageIndex = 0 };
        root.Nodes.Add(new TreeNode("未読メール") { ImageIndex = 1, SelectedImageIndex = 1, Tag = "unread" });
        root.Nodes.Add(new TreeNode("既読メール") { ImageIndex = 1, SelectedImageIndex = 1, Tag = "read" });
        root.Nodes.Add(new TreeNode("削除予定") { ImageIndex = 1, SelectedImageIndex = 1, Tag = "deleted" });
        tree.Nodes.Add(root);
        tree.ExpandAll();

        // 注意: tree.Font はコントロールが実際に使用しているフォントの参照であり、
        // クローンではない。using で包んで Dispose すると TreeView 自体の描画が
        // 壊れて "パラメーターが無効です。" (GDI+ の Parameter is not valid) が発生する。
        // そのため通常のフォントはそのまま参照し、新規に作った派生フォントだけを
        // FormClosed 時にまとめて破棄する。
        var normalFont = tree.Font;
        var boldFont = new Font(tree.Font, FontStyle.Bold);
        var italicStrike = new Font(tree.Font, FontStyle.Italic | FontStyle.Strikeout);
        FormClosed += (_, _) =>
        {
            boldFont.Dispose();
            italicStrike.Dispose();
        };

        tree.DrawNode += (s, e) =>
        {
            e.DrawDefault = false; // テキストは完全に自前で描く(アイコンは標準描画のまま)

            string tag = e.Node?.Tag as string ?? "";
            (Font font, Color color, string prefix) = tag switch
            {
                "unread" => (boldFont, Color.Black, "● "),
                "deleted" => (italicStrike, Color.Gray, ""),
                _ => (normalFont, Color.DimGray, "")
            };

            bool selected = e.State.HasFlag(TreeNodeStates.Selected);
            using var bg = new SolidBrush(selected ? SystemColors.Highlight : tree.BackColor);
            e.Graphics.FillRectangle(bg, e.Bounds);

            var textColor = selected ? SystemColors.HighlightText : color;
            TextRenderer.DrawText(e.Graphics, prefix + e.Node!.Text, font, e.Bounds, textColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
        };

        page.Controls.Add(tree);
        page.Controls.Add(Note(
            "アイコンは標準描画のまま、テキスト部分だけを DrawNode で自前描画。\n" +
            "太字=未読、グレー+取り消し線=削除予定、先頭に「●」を付ける、\n" +
            "などテキストの見た目だけで状態を表せます。追加画像が不要なのが利点です。"));
        return page;
    }

    private static Label Note(string text) => new()
    {
        Dock = DockStyle.Bottom,
        Height = 70,
        Text = text,
        ForeColor = Color.DimGray,
        Padding = new Padding(6)
    };
}
