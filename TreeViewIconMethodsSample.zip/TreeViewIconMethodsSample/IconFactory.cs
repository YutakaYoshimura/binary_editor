namespace TreeViewIconMethodsSample;

/// <summary>
/// 外部の画像ファイルを使わず、コードだけで16x16のサンプルアイコンを生成するヘルパー。
/// 実際のプロジェクトでは png/ico ファイルを Image.FromFile 等で読み込んでも同じ仕組みで使えます。
/// </summary>
internal static class IconFactory
{
    public static Bitmap FolderClosed() => DrawFolder(open: false);
    public static Bitmap FolderOpen() => DrawFolder(open: true);

    public static Bitmap File()
    {
        var bmp = New();
        using var g = Gfx(bmp);
        var body = new Rectangle(3, 1, 10, 14);
        g.FillRectangle(Brushes.WhiteSmoke, body);
        g.DrawRectangle(Pens.Gray, body);
        using var linePen = new Pen(Color.LightSlateGray);
        for (int y = 4; y <= 11; y += 3)
            g.DrawLine(linePen, 5, y, 11, y);
        return bmp;
    }

    public static Bitmap Star(int size = 16)
    {
        var bmp = new Bitmap(size, size);
        using var g = Gfx(bmp);
        float c = size / 2f;
        var pts = StarPoints(new PointF(c, c), c - 1, (c - 1) / 2.2f);
        g.FillPolygon(Brushes.Gold, pts);
        g.DrawPolygon(Pens.DarkGoldenrod, pts);
        return bmp;
    }

    public static Bitmap WarningTriangle(int size = 16)
    {
        var bmp = new Bitmap(size, size);
        using var g = Gfx(bmp);
        PointF[] tri = { new(size / 2f, 1), new(size - 1, size - 2), new(1, size - 2) };
        g.FillPolygon(Brushes.Gold, tri);
        g.DrawPolygon(Pens.DarkOrange, tri);
        if (size >= 14)
        {
            using var font = new Font("Arial", size * 0.5f, FontStyle.Bold);
            g.DrawString("!", font, Brushes.Black, size * 0.34f, size * 0.28f);
        }
        return bmp;
    }

    public static Bitmap CheckCircle(int size = 16)
    {
        var bmp = new Bitmap(size, size);
        using var g = Gfx(bmp);
        g.FillEllipse(Brushes.MediumSeaGreen, 0, 0, size - 1, size - 1);
        using var pen = new Pen(Color.White, 2f);
        g.DrawLines(pen, new PointF[]
        {
            new(size * 0.25f, size * 0.52f),
            new(size * 0.42f, size * 0.72f),
            new(size * 0.78f, size * 0.28f)
        });
        return bmp;
    }

    public static Bitmap ErrorCircle(int size = 16)
    {
        var bmp = new Bitmap(size, size);
        using var g = Gfx(bmp);
        g.FillEllipse(Brushes.IndianRed, 0, 0, size - 1, size - 1);
        using var pen = new Pen(Color.White, 2f);
        g.DrawLine(pen, size * 0.28f, size * 0.28f, size * 0.72f, size * 0.72f);
        g.DrawLine(pen, size * 0.72f, size * 0.28f, size * 0.28f, size * 0.72f);
        return bmp;
    }

    public static Bitmap SyncArrows(int size = 16)
    {
        var bmp = new Bitmap(size, size);
        using var g = Gfx(bmp);
        using var pen = new Pen(Color.SteelBlue, 2f) { EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor };
        g.DrawArc(pen, 1, 1, size - 3, size - 3, -30, 200);
        g.DrawArc(pen, 1, 1, size - 3, size - 3, 150, 200);
        return bmp;
    }

    /// <summary>
    /// ベースアイコンの右下(または指定コーナー)に小さいバッジ画像を重ねて1枚に合成する。
    /// 「事前合成アイコン」方式と、オーナードローでのリアルタイム合成の両方で利用できる。
    /// </summary>
    public static Bitmap Overlay(Image baseIcon, Image badge, int badgeSize = 9)
    {
        var bmp = new Bitmap(baseIcon.Width, baseIcon.Height);
        using var g = Gfx(bmp);
        g.DrawImage(baseIcon, 0, 0);
        int x = baseIcon.Width - badgeSize;
        int y = baseIcon.Height - badgeSize;
        g.DrawImage(badge, x, y, badgeSize, badgeSize);
        return bmp;
    }

    // ---- 内部ヘルパー ----

    private static Bitmap New() => new(16, 16);

    private static Graphics Gfx(Bitmap bmp)
    {
        var g = Graphics.FromImage(bmp);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        return g;
    }

    private static Bitmap DrawFolder(bool open)
    {
        var bmp = New();
        using var g = Gfx(bmp);
        Color body = Color.FromArgb(255, 222, 170, 60);
        Color tab = Color.FromArgb(255, 200, 145, 40);
        g.FillRectangle(new SolidBrush(tab), 1, 3, 6, 3);
        if (open)
        {
            g.FillPolygon(new SolidBrush(body), new PointF[] { new(1, 6), new(15, 6), new(13, 14), new(0, 14) });
            g.FillPolygon(new SolidBrush(Color.FromArgb(255, 245, 200, 100)),
                new PointF[] { new(2, 5), new(14, 5), new(12, 11), new(2, 11) });
        }
        else
        {
            g.FillRectangle(new SolidBrush(body), 1, 6, 14, 8);
        }
        g.DrawRectangle(Pens.SaddleBrown, 0, 5, 15, 9);
        return bmp;
    }

    private static PointF[] StarPoints(PointF center, float outerR, float innerR)
    {
        var pts = new PointF[10];
        for (int i = 0; i < 10; i++)
        {
            double angle = Math.PI / 2 * 3 + i * Math.PI / 5;
            float r = (i % 2 == 0) ? outerR : innerR;
            pts[i] = new PointF(center.X + r * (float)Math.Cos(angle), center.Y + r * (float)Math.Sin(angle));
        }
        return pts;
    }
}
