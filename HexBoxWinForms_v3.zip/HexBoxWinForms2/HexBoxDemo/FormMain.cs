using System;
using System.Drawing;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace HexBoxDemo
{
    /// <summary>
    /// LimitedByteProvider を使用した HexBox 入力制限デモフォーム。
    /// 1行8バイト × 1行 = 最大8バイトまで入力を受け付ける。
    /// </summary>
    public partial class FormMain : Form
    {
        // ── 定数 ──────────────────────────────────────────
        private const int BYTES_PER_LINE = 8;   // 1行あたりのバイト数
        private const int MAX_LINES      = 1;   // 最大行数

        // ── フィールド ────────────────────────────────────
        private HexBox              _hexBox;
        private LimitedByteProvider _provider;

        // ── コンストラクタ ────────────────────────────────
        public FormMain()
        {
            InitializeComponent();
            InitHexBox();
        }

        // ─────────────────────────────────────────────────
        // HexBox 初期化
        // ─────────────────────────────────────────────────
        private void InitHexBox()
        {
            _provider = CreateProvider(new byte[0]);

            _hexBox = new HexBox
            {
                ByteProvider         = _provider,
                BytesPerLine         = BYTES_PER_LINE,
                UseFixedBytesPerLine = true,
                VScrollBarVisible    = false,
                LineInfoVisible      = true,
                StringViewVisible    = true,
                ColumnInfoVisible    = true,
                GroupSize            = 1,
                Font                 = new Font("Courier New", 10.5f),
                BackColor            = Color.White,
                BorderStyle          = BorderStyle.Fixed3D,
                Dock                 = DockStyle.None,   // AutoScroll のために Fill を外す
                Anchor               = AnchorStyles.Left | AnchorStyles.Top,
            };

            // ── 横幅超え対応：_panelHex を AutoScroll パネルに設定 ──
            _panelHex.AutoScroll = true;

            // RequiredWidth が変わったら HexBox の Width を追従させる
            _hexBox.RequiredWidthChanged += (s, e) => AdjustHexBoxSize();

            // カーソル移動のたびにスクロール位置を追従させる
            _hexBox.SelectionStartChanged += (s, e) => ScrollCaretIntoView();

            _panelHex.Controls.Add(_hexBox);

            // 初回サイズ合わせ（フォント確定後に必要）
            _hexBox.SizeChanged += (s, e) => AdjustHexBoxSize();

            RefreshStatus();
        }

        /// <summary>
        /// HexBox の高さをパネルに合わせ、幅を RequiredWidth に合わせる。
        /// </summary>
        private void AdjustHexBoxSize()
        {
            int w = Math.Max(_hexBox.RequiredWidth, _panelHex.ClientSize.Width);
            int h = _panelHex.ClientSize.Height;
            if (_hexBox.Width != w || _hexBox.Height != h)
                _hexBox.Size = new Size(w, h);
        }

        /// <summary>
        /// カーソル（SelectionStart）が常に表示されるようパネルを水平スクロールする。
        /// </summary>
        private void ScrollCaretIntoView()
        {
            if (_hexBox.RequiredWidth <= _panelHex.ClientSize.Width)
            {
                // 横幅が収まる場合はスクロール不要
                _panelHex.AutoScrollPosition = new Point(0, 0);
                return;
            }

            // カレットの X 座標を取得して表示範囲内に収める
            int caretX = _hexBox.Location.X + (int)(_hexBox.SelectionStart
                         % Math.Max(1, _hexBox.BytesPerLine)
                         * (_hexBox.RequiredWidth / (double)Math.Max(1, _hexBox.BytesPerLine)));

            int panelW    = _panelHex.ClientSize.Width;
            int scrollX   = -_panelHex.AutoScrollPosition.X;
            int rightEdge = scrollX + panelW;

            if (caretX < scrollX)
                _panelHex.AutoScrollPosition = new Point(caretX, 0);
            else if (caretX + 20 > rightEdge)
                _panelHex.AutoScrollPosition = new Point(caretX + 20 - panelW, 0);
        }

        private LimitedByteProvider CreateProvider(byte[] data)
        {
            var p = new LimitedByteProvider(data, MAX_LINES, BYTES_PER_LINE);
            p.Changed       += (s, e) => RefreshStatus();
            p.LengthChanged += (s, e) => RefreshStatus();
            return p;
        }

        // ─────────────────────────────────────────────────
        // ステータス更新
        // ─────────────────────────────────────────────────
        private void RefreshStatus()
        {
            long cur = _provider.Length;
            long max = _provider.MaxBytes;

            // プログレスバー
            _progressBytes.Maximum = (int)max;
            _progressBytes.Value   = (int)Math.Min(cur, max);

            // ラベル
            _lblByteCount.Text = string.Format("{0} / {1} バイト", cur, max);

            if (cur >= max)
            {
                _lblByteCount.ForeColor  = Color.Red;
                _lblLimit.Text           = "上限に達しました（これ以上入力できません）";
                _lblLimit.ForeColor      = Color.Red;
                _progressBytes.ForeColor = Color.Red;
            }
            else
            {
                _lblByteCount.ForeColor  = SystemColors.ControlText;
                _lblLimit.Text           = string.Format("残り {0} バイト入力できます", max - cur);
                _lblLimit.ForeColor      = Color.DarkGreen;
                _progressBytes.ForeColor = Color.DodgerBlue;
            }

            // HexViewer（現在のバイト列を16進で表示）
            _txtHexView.Text = BuildHexView();
        }

        private string BuildHexView()
        {
            if (_provider.Length == 0) return "（未入力）";
            var sb = new System.Text.StringBuilder();
            for (long i = 0; i < _provider.Length; i++)
            {
                if (i > 0) sb.Append(" ");
                sb.Append(_provider.ReadByte(i).ToString("X2"));
            }
            return sb.ToString();
        }

        // ─────────────────────────────────────────────────
        // イベント
        // ─────────────────────────────────────────────────
        private void BtnClear_Click(object sender, EventArgs e)
        {
            _provider = CreateProvider(new byte[0]);
            _hexBox.ByteProvider = _provider;
            RefreshStatus();
            _hexBox.Focus();
        }

        private void BtnFill_Click(object sender, EventArgs e)
        {
            // サンプルデータ（8バイト）をセット
            byte[] sample = { 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF };
            _provider = CreateProvider(sample);
            _hexBox.ByteProvider = _provider;
            RefreshStatus();
            _hexBox.Focus();
        }

        private void BtnCopy_Click(object sender, EventArgs e)
        {
            if (_provider.Length == 0)
            {
                MessageBox.Show("データが入力されていません。", "コピー",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            Clipboard.SetText(BuildHexView());
            MessageBox.Show("16進数文字列をクリップボードにコピーしました。\n\n" + BuildHexView(),
                "コピー完了", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDetail_Click(object sender, EventArgs e)
        {
            if (_provider.Length == 0)
            {
                MessageBox.Show("データが入力されていません。", "データ確認",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var sb = new System.Text.StringBuilder();
            sb.AppendLine(string.Format("バイト数: {0} / {1}", _provider.Length, _provider.MaxBytes));
            sb.AppendLine();
            sb.AppendLine("── 16進数 ──────────────");
            sb.AppendLine(BuildHexView());
            sb.AppendLine();
            sb.AppendLine("── 10進数 ──────────────");
            for (long i = 0; i < _provider.Length; i++)
            {
                sb.AppendLine(string.Format("  [{0}] = {1,3} (0x{2})",
                    i, _provider.ReadByte(i), _provider.ReadByte(i).ToString("X2")));
            }

            MessageBox.Show(sb.ToString(), "バイトデータ詳細",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
