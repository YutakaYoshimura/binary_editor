using System.Collections.Generic;

namespace BinaryEditor.Models
{
    /// <summary>
    /// バイナリパラメータの定義
    /// </summary>
    public class BinaryParameter
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Offset { get; set; }      // バイトオフセット
        public int Length { get; set; }      // バイト長
        public string Unit { get; set; }     // 単位（表示用）
        public string Format { get; set; }   // "HEX" / "UINT8" / "UINT16BE" / "UINT16LE" / "ASCII"

        /// <summary>
        /// サンプルパラメータ定義（ECU風データ構造）
        /// </summary>
        public static List<BinaryParameter> GetSampleParameters()
        {
            return new List<BinaryParameter>
            {
                new BinaryParameter { Name = "Header",         Description = "ファイルヘッダ識別子",      Offset =  0, Length = 2, Unit = "",     Format = "HEX"     },
                new BinaryParameter { Name = "Version",        Description = "バージョン番号",            Offset =  2, Length = 1, Unit = "",     Format = "UINT8"   },
                new BinaryParameter { Name = "SubVersion",     Description = "サブバージョン番号",        Offset =  3, Length = 1, Unit = "",     Format = "UINT8"   },
                new BinaryParameter { Name = "DataLength",     Description = "データ長（Big Endian）",   Offset =  4, Length = 2, Unit = "byte", Format = "UINT16BE"},
                new BinaryParameter { Name = "DeviceID",       Description = "デバイスID",               Offset =  6, Length = 2, Unit = "",     Format = "UINT16LE"},
                new BinaryParameter { Name = "MaxRPM",         Description = "最大回転数",               Offset =  8, Length = 2, Unit = "rpm",  Format = "UINT16BE"},
                new BinaryParameter { Name = "IdleRPM",        Description = "アイドル回転数",           Offset = 10, Length = 2, Unit = "rpm",  Format = "UINT16BE"},
                new BinaryParameter { Name = "ThrottleMin",    Description = "スロットル最小値",         Offset = 12, Length = 1, Unit = "%",    Format = "UINT8"   },
                new BinaryParameter { Name = "ThrottleMax",    Description = "スロットル最大値",         Offset = 13, Length = 1, Unit = "%",    Format = "UINT8"   },
                new BinaryParameter { Name = "FuelBase",       Description = "基本燃料噴射量",           Offset = 14, Length = 2, Unit = "ms",   Format = "UINT16BE"},
                new BinaryParameter { Name = "IgnitionAdv",   Description = "点火進角",                 Offset = 16, Length = 1, Unit = "deg",  Format = "UINT8"   },
                new BinaryParameter { Name = "CoolantTemp",   Description = "冷却水温補正",             Offset = 17, Length = 1, Unit = "°C",  Format = "UINT8"   },
                new BinaryParameter { Name = "AirTemp",        Description = "吸気温補正",               Offset = 18, Length = 1, Unit = "°C",  Format = "UINT8"   },
                new BinaryParameter { Name = "BattVoltage",   Description = "バッテリ電圧補正",         Offset = 19, Length = 1, Unit = "V",    Format = "UINT8"   },
                new BinaryParameter { Name = "O2Sensor",      Description = "O2センサ補正値",           Offset = 20, Length = 2, Unit = "mV",   Format = "UINT16BE"},
                new BinaryParameter { Name = "MapSensorGain", Description = "MAPセンサゲイン",          Offset = 22, Length = 1, Unit = "",     Format = "UINT8"   },
                new BinaryParameter { Name = "Reserved1",     Description = "予約領域1",                Offset = 23, Length = 1, Unit = "",     Format = "HEX"     },
                new BinaryParameter { Name = "SerialNo",      Description = "シリアル番号(ASCII)",      Offset = 24, Length = 8, Unit = "",     Format = "ASCII"   },
                new BinaryParameter { Name = "Checksum",      Description = "チェックサム",             Offset = 32, Length = 2, Unit = "",     Format = "HEX"     },
                new BinaryParameter { Name = "Reserved2",     Description = "予約領域2",                Offset = 34, Length = 2, Unit = "",     Format = "HEX"     },
            };
        }

        /// <summary>
        /// サンプルバイナリデータ（上記パラメータ定義に対応）
        /// </summary>
        public static byte[] GetSampleData()
        {
            var data = new byte[64];
            // Header: 0xAB 0xCD
            data[0] = 0xAB; data[1] = 0xCD;
            // Version: 1, SubVersion: 3
            data[2] = 0x01; data[3] = 0x03;
            // DataLength: 64 (BE)
            data[4] = 0x00; data[5] = 0x40;
            // DeviceID: 0x1234 (LE)
            data[6] = 0x34; data[7] = 0x12;
            // MaxRPM: 8000 (BE)
            data[8] = 0x1F; data[9] = 0x40;
            // IdleRPM: 750 (BE)
            data[10] = 0x02; data[11] = 0xEE;
            // ThrottleMin: 0, ThrottleMax: 100
            data[12] = 0x00; data[13] = 0x64;
            // FuelBase: 3200 (BE)
            data[14] = 0x0C; data[15] = 0x80;
            // IgnitionAdv: 12
            data[16] = 0x0C;
            // CoolantTemp: 80
            data[17] = 0x50;
            // AirTemp: 25
            data[18] = 0x19;
            // BattVoltage: 14
            data[19] = 0x0E;
            // O2Sensor: 450mV (BE)
            data[20] = 0x01; data[21] = 0xC2;
            // MapSensorGain: 128
            data[22] = 0x80;
            // Reserved1
            data[23] = 0x00;
            // SerialNo: "ECU12345" (ASCII)
            byte[] serial = System.Text.Encoding.ASCII.GetBytes("ECU12345");
            for (int i = 0; i < serial.Length && i < 8; i++)
                data[24 + i] = serial[i];
            // Checksum
            data[32] = 0xF1; data[33] = 0x2A;
            // Reserved2
            data[34] = 0x00; data[35] = 0x00;
            // 残りは連番
            for (int i = 36; i < data.Length; i++)
                data[i] = (byte)(i & 0xFF);
            return data;
        }
    }
}
