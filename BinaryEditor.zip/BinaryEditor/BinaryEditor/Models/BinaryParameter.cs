using System.Collections.Generic;
using System.Text;

namespace BinaryEditor.Models
{
    /// <summary>
    /// バイナリパラメータ定義
    /// </summary>
    public class BinaryParameter
    {
        public string Name        { get; set; }
        public string Description { get; set; }
        public int    Offset      { get; set; }
        public int    Length      { get; set; }
        public string Unit        { get; set; }
        public string Format      { get; set; } // "HEX" / "UINT8" / "UINT16BE" / "UINT16LE" / "ASCII"

        /// <summary>サンプルパラメータ定義（ECU風）</summary>
        public static List<BinaryParameter> GetSampleParameters()
        {
            return new List<BinaryParameter>
            {
                new BinaryParameter { Name="Header",        Description="ファイルヘッダ識別子",    Offset= 0, Length=2, Unit="",    Format="HEX"      },
                new BinaryParameter { Name="Version",       Description="バージョン番号",          Offset= 2, Length=1, Unit="",    Format="UINT8"    },
                new BinaryParameter { Name="SubVersion",    Description="サブバージョン番号",      Offset= 3, Length=1, Unit="",    Format="UINT8"    },
                new BinaryParameter { Name="DataLength",    Description="データ長(BigEndian)",    Offset= 4, Length=2, Unit="byte",Format="UINT16BE" },
                new BinaryParameter { Name="DeviceID",      Description="デバイスID(LittleEnd)", Offset= 6, Length=2, Unit="",    Format="UINT16LE" },
                new BinaryParameter { Name="MaxRPM",        Description="最大回転数",             Offset= 8, Length=2, Unit="rpm", Format="UINT16BE" },
                new BinaryParameter { Name="IdleRPM",       Description="アイドル回転数",         Offset=10, Length=2, Unit="rpm", Format="UINT16BE" },
                new BinaryParameter { Name="ThrottleMin",   Description="スロットル最小値",       Offset=12, Length=1, Unit="%",   Format="UINT8"    },
                new BinaryParameter { Name="ThrottleMax",   Description="スロットル最大値",       Offset=13, Length=1, Unit="%",   Format="UINT8"    },
                new BinaryParameter { Name="FuelBase",      Description="基本燃料噴射量",         Offset=14, Length=2, Unit="ms",  Format="UINT16BE" },
                new BinaryParameter { Name="IgnitionAdv",   Description="点火進角",               Offset=16, Length=1, Unit="deg", Format="UINT8"    },
                new BinaryParameter { Name="CoolantTemp",   Description="冷却水温補正",           Offset=17, Length=1, Unit="°C", Format="UINT8"    },
                new BinaryParameter { Name="AirTemp",       Description="吸気温補正",             Offset=18, Length=1, Unit="°C", Format="UINT8"    },
                new BinaryParameter { Name="BattVoltage",   Description="バッテリ電圧補正",       Offset=19, Length=1, Unit="V",   Format="UINT8"    },
                new BinaryParameter { Name="O2Sensor",      Description="O2センサ補正値",         Offset=20, Length=2, Unit="mV",  Format="UINT16BE" },
                new BinaryParameter { Name="MapSensorGain", Description="MAPセンサゲイン",        Offset=22, Length=1, Unit="",    Format="UINT8"    },
                new BinaryParameter { Name="Reserved1",     Description="予約領域1",              Offset=23, Length=1, Unit="",    Format="HEX"      },
                new BinaryParameter { Name="SerialNo",      Description="シリアル番号(ASCII)",    Offset=24, Length=8, Unit="",    Format="ASCII"    },
                new BinaryParameter { Name="Checksum",      Description="チェックサム",           Offset=32, Length=2, Unit="",    Format="HEX"      },
                new BinaryParameter { Name="Reserved2",     Description="予約領域2",              Offset=34, Length=2, Unit="",    Format="HEX"      },
            };
        }

        /// <summary>サンプルバイナリデータ</summary>
        public static byte[] GetSampleData()
        {
            var data = new byte[64];
            data[0]=0xAB; data[1]=0xCD;
            data[2]=0x01; data[3]=0x03;
            data[4]=0x00; data[5]=0x40;
            data[6]=0x34; data[7]=0x12;
            data[8]=0x1F; data[9]=0x40;
            data[10]=0x02; data[11]=0xEE;
            data[12]=0x00; data[13]=0x64;
            data[14]=0x0C; data[15]=0x80;
            data[16]=0x0C;
            data[17]=0x50;
            data[18]=0x19;
            data[19]=0x0E;
            data[20]=0x01; data[21]=0xC2;
            data[22]=0x80;
            data[23]=0x00;
            byte[] serial = Encoding.ASCII.GetBytes("ECU12345");
            for (int i = 0; i < serial.Length && i < 8; i++)
                data[24+i] = serial[i];
            data[32]=0xF1; data[33]=0x2A;
            data[34]=0x00; data[35]=0x00;
            for (int i = 36; i < data.Length; i++)
                data[i] = (byte)(i & 0xFF);
            return data;
        }

        /// <summary>バイト配列から解析値文字列を生成</summary>
        public string ParseValue(byte[] data)
        {
            if (data == null || Offset >= data.Length) return "-";
            try
            {
                switch (Format)
                {
                    case "UINT8":
                        return data[Offset].ToString();
                    case "UINT16BE":
                        if (Offset + 1 < data.Length)
                            return ((data[Offset] << 8) | data[Offset+1]).ToString();
                        break;
                    case "UINT16LE":
                        if (Offset + 1 < data.Length)
                            return (data[Offset] | (data[Offset+1] << 8)).ToString();
                        break;
                    case "ASCII":
                        int len = System.Math.Min(Length, data.Length - Offset);
                        if (len > 0)
                            return "\"" + Encoding.ASCII.GetString(data, Offset, len).TrimEnd('\0') + "\"";
                        break;
                    case "HEX":
                    default:
                        return "-";
                }
            }
            catch { }
            return "-";
        }

        /// <summary>HEX文字列を生成（スペース区切り）</summary>
        public string BuildHexStr(byte[] data)
        {
            if (data == null) return "";
            var sb = new StringBuilder();
            for (int i = 0; i < Length; i++)
            {
                int idx = Offset + i;
                if (idx < data.Length)
                    sb.AppendFormat("{0:X2} ", data[idx]);
            }
            return sb.ToString().TrimEnd();
        }

        /// <summary>パラメータのバイト長からMaskedTextBox用マスクを生成</summary>
        public string BuildMask()
        {
            // 1バイト = "CC" (16進2文字)、バイト間はスペース（リテラル）
            var sb = new StringBuilder();
            for (int i = 0; i < Length; i++)
            {
                if (i > 0) sb.Append(" ");
                sb.Append("CC");
            }
            return sb.ToString();
        }
    }
}
