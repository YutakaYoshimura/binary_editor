using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BinaryEditor.Controls;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// DataGridViewを使用したバイナリエディタ画面
    /// 各セル編集時にHexEditControlオーバーレイを表示
    /// </summary>
    public partial class GridBinaryForm : Form
    {
        private byte[] _data;
        private const int BYTES_PER_ROW = 16;

        // オーバーレイ用HexEditControl
        private HexEditControl _hexEditOverlay;
        private int _editingRow = -1;
        private int _editingCol = -1;

        public GridBinaryForm()
        {
            InitializeComponent();
            InitializeGrid();
            InitializeHexEditOverlay();
            LoadSampleData();
        }

        // ---- グリッド初期化 ----

        private void InitializeGrid()
        {
            dataGridView.SuspendLayout();

            // オフセット列
            var colOffset = new DataGridViewTextBoxColumn
            {
                Name = "colOffset",
                HeaderText = "Offset",
                Width = 75,
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Courier New", 9f, FontStyle.Bold),
                    ForeColor = Color.DimGray,
                    BackColor = Color.FromArgb(230, 235, 245),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                }
            };
            dataGridView.Columns.Add(colOffset);

            // 16バイト分の列
            for (int i = 0; i < BYTES_PER_ROW; i++)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    Name = $"col{i:X}",
                    HeaderText = i.ToString("X2"),
                    Width = 36,
                    ReadOnly = true, // 直接編集を無効 → オーバーレイで行う
                    DefaultCellStyle = new DataGridViewCellStyle
                    {
                        Font = new Font("Courier New", 9f),
                        ForeColor = Color.FromArgb(0, 80, 160),
                        BackColor = Color.White,
                        Alignment = DataGridViewContentAlignment.MiddleCenter
                    }
                };
                dataGridView.Columns.Add(col);
            }

            // ASCII列
            var colAscii = new DataGridViewTextBoxColumn
            {
                Name = "colAscii",
                HeaderText = "ASCII",
                Width = 140,
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Courier New", 9f),
                    ForeColor = Color.DarkGreen,
                    BackColor = Color.FromArgb(240, 255, 240),
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            };
            dataGridView.Columns.Add(colAscii);

            dataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Courier New", 9f, FontStyle.Bold);
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(50, 80, 140);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersHeight = 28;
            dataGridView.RowHeadersWidth = 5;
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.AllowUserToResizeRows = false;
            dataGridView.MultiSelect = false;
            dataGridView.SelectionMode = DataGridViewSelectionMode.CellSelect;
            dataGridView.GridColor = Color.FromArgb(200, 210, 230);
            dataGridView.BackgroundColor = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 210, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick += dataGridView_CellClick;
            dataGridView.Scroll += (s, e) => HideHexEditOverlay();

            dataGridView.ResumeLayout();
        }

        private void InitializeHexEditOverlay()
        {
            _hexEditOverlay = new HexEditControl();
            _hexEditOverlay.Visible = false;
            _hexEditOverlay.Size = new Size(34, 22);
            _hexEditOverlay.KeyDown += HexEditOverlay_KeyDown;
            _hexEditOverlay.LostFocus += HexEditOverlay_LostFocus;
            dataGridView.Controls.Add(_hexEditOverlay);
        }

        // ---- データ ----

        private void LoadSampleData()
        {
            _data = new byte[128];
            for (int i = 0; i < _data.Length; i++)
                _data[i] = (byte)(i * 2 + 0x20);
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            for (int row = 0; row * BYTES_PER_ROW < _data.Length; row++)
            {
                int offset = row * BYTES_PER_ROW;
                var rowValues = new object[BYTES_PER_ROW + 2];
                rowValues[0] = $"{offset:X8}";

                var ascii = new System.Text.StringBuilder();
                for (int col = 0; col < BYTES_PER_ROW; col++)
                {
                    int idx = offset + col;
                    if (idx < _data.Length)
                    {
                        rowValues[col + 1] = _data[idx].ToString("X2");
                        char c = (char)_data[idx];
                        ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                    }
                    else
                    {
                        rowValues[col + 1] = "";
                        ascii.Append(' ');
                    }
                }
                rowValues[BYTES_PER_ROW + 1] = ascii.ToString();

                int rowIdx = dataGridView.Rows.Add(rowValues);
                dataGridView.Rows[rowIdx].Height = 22;
            }

            ColorizeGrid();
            dataGridView.ResumeLayout();
        }

        private void ColorizeGrid()
        {
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                for (int col = 1; col <= BYTES_PER_ROW; col++)
                {
                    if (row.Cells[col].Value == null || row.Cells[col].Value.ToString() == "") continue;
                    string hex = row.Cells[col].Value.ToString();
                    if (hex == "00")
                    {
                        row.Cells[col].Style.ForeColor = Color.LightGray;
                    }
                    else if (hex == "FF")
                    {
                        row.Cells[col].Style.ForeColor = Color.Red;
                        row.Cells[col].Style.BackColor = Color.FromArgb(255, 240, 240);
                    }
                }
            }
        }

        // ---- セル編集(オーバーレイ) ----

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // ヘッダ行・オフセット列・ASCII列は無視
            if (e.RowIndex < 0 || e.ColumnIndex <= 0 || e.ColumnIndex > BYTES_PER_ROW)
            {
                HideHexEditOverlay();
                return;
            }

            int offset = e.RowIndex * BYTES_PER_ROW + (e.ColumnIndex - 1);
            if (offset >= _data.Length)
            {
                HideHexEditOverlay();
                return;
            }

            _editingRow = e.RowIndex;
            _editingCol = e.ColumnIndex;

            // セルの矩形を取得してオーバーレイを重ねる
            Rectangle cellRect = dataGridView.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
            _hexEditOverlay.Location = new Point(cellRect.Left + 1, cellRect.Top + 1);
            _hexEditOverlay.Size = new Size(cellRect.Width - 2, cellRect.Height - 2);
            _hexEditOverlay.SetByteValue(_data[offset]);
            _hexEditOverlay.Visible = true;
            _hexEditOverlay.Focus();
            _hexEditOverlay.SelectAll();

            lblStatus.Text = $"編集中 - Offset: 0x{offset:X4} ({offset}), 現在値: 0x{_data[offset]:X2} | Enter/Tab: 確定  Esc: キャンセル";
        }

        private void CommitHexEdit()
        {
            if (_editingRow < 0 || _editingCol <= 0 || !_hexEditOverlay.Visible) return;

            int offset = _editingRow * BYTES_PER_ROW + (_editingCol - 1);
            if (offset >= _data.Length)
            {
                HideHexEditOverlay();
                return;
            }

            if (_hexEditOverlay.IsValidHex)
            {
                byte? val = _hexEditOverlay.GetByteValue();
                if (val.HasValue)
                {
                    _data[offset] = val.Value;
                    // セルを直接更新(全描画なし)
                    dataGridView.Rows[_editingRow].Cells[_editingCol].Value = val.Value.ToString("X2");
                    UpdateAsciiCell(_editingRow);
                    RecolorCell(_editingRow, _editingCol, val.Value);

                    lblStatus.Text = $"更新完了 - Offset: 0x{offset:X4} ({offset}), 新しい値: 0x{val.Value:X2}";
                }
            }
            else
            {
                lblStatus.Text = $"無効な値 - 16進数(00〜FF)を入力してください";
            }

            HideHexEditOverlay();
        }

        private void HideHexEditOverlay()
        {
            _hexEditOverlay.Visible = false;
            _editingRow = -1;
            _editingCol = -1;
        }

        private void UpdateAsciiCell(int rowIndex)
        {
            int offset = rowIndex * BYTES_PER_ROW;
            var ascii = new System.Text.StringBuilder();
            for (int col = 0; col < BYTES_PER_ROW; col++)
            {
                int idx = offset + col;
                if (idx < _data.Length)
                {
                    char c = (char)_data[idx];
                    ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                }
                else
                    ascii.Append(' ');
            }
            dataGridView.Rows[rowIndex].Cells[BYTES_PER_ROW + 1].Value = ascii.ToString();
        }

        private void RecolorCell(int rowIndex, int colIndex, byte value)
        {
            var cell = dataGridView.Rows[rowIndex].Cells[colIndex];
            if (value == 0x00)
            {
                cell.Style.ForeColor = Color.LightGray;
                cell.Style.BackColor = Color.White;
            }
            else if (value == 0xFF)
            {
                cell.Style.ForeColor = Color.Red;
                cell.Style.BackColor = Color.FromArgb(255, 240, 240);
            }
            else
            {
                cell.Style.ForeColor = Color.FromArgb(0, 80, 160);
                cell.Style.BackColor = Color.White;
            }
        }

        private void HexEditOverlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                CommitHexEdit();
                // 次のセルへ移動
                MoveToNextCell();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Tab)
            {
                CommitHexEdit();
                MoveToNextCell();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HideHexEditOverlay();
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void HexEditOverlay_LostFocus(object sender, EventArgs e)
        {
            if (_hexEditOverlay.Visible)
                CommitHexEdit();
        }

        private void MoveToNextCell()
        {
            if (_editingRow < 0) return;
            int nextCol = _editingCol + 1;
            int nextRow = _editingRow;
            if (nextCol > BYTES_PER_ROW)
            {
                nextCol = 1;
                nextRow++;
            }
            if (nextRow < dataGridView.Rows.Count && nextCol <= BYTES_PER_ROW)
            {
                dataGridView.CurrentCell = dataGridView.Rows[nextRow].Cells[nextCol];
                dataGridView_CellClick(this, new DataGridViewCellEventArgs(nextCol, nextRow));
            }
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideHexEditOverlay();
            using (var dlg = new OpenFileDialog())
            {
                dlg.Filter = "すべてのファイル (*.*)|*.*|バイナリファイル (*.bin)|*.bin";
                dlg.Title = "バイナリファイルを開く";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        _data = File.ReadAllBytes(dlg.FileName);
                        RefreshGrid();
                        lblStatus.Text = $"ファイル読み込み完了: {Path.GetFileName(dlg.FileName)} ({_data.Length} bytes)";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ファイルの読み込みに失敗しました。\n{ex.Message}", "エラー",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideHexEditOverlay();
            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "バイナリファイル (*.bin)|*.bin|すべてのファイル (*.*)|*.*";
                dlg.Title = "バイナリファイルを保存";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllBytes(dlg.FileName, _data);
                        lblStatus.Text = $"保存完了: {Path.GetFileName(dlg.FileName)}";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"保存に失敗しました。\n{ex.Message}", "エラー",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            HideHexEditOverlay();
            using (var dlg = new SizeInputDialog())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _data = new byte[dlg.DataSize];
                    RefreshGrid();
                    lblStatus.Text = $"新規データ作成: {_data.Length} bytes";
                }
            }
        }
    }
}
