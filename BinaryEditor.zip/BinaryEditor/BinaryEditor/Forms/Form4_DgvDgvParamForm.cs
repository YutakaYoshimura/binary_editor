using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面④ DataGridView ― パラメータ毎表示・編集
    /// 表示: DataGridView（パラメータ一覧）
    /// 編集: HEX列クリック時、DataGridViewオーバーレイをセル上に重ねる。
    ///       バイト数分の列を持ち、2文字入力で次セルへ自動移動。
    /// </summary>
    public partial class Form4_DgvDgvParamForm : Form
    {
        private byte[]                _data;
        private List<BinaryParameter> _params;

        // オーバーレイ用DataGridView
        private DataGridView _dgvOverlay;
        private int          _editRow      = -1;

        // TextChangedで立てるフラグ。CellValidatedで参照して移動処理を行う。
        private bool _pendingMoveNext   = false;
        // イベント処理中の誤発火を防ぐフラグ
        private bool _setting           = false;

        private const int BYTE_CELL_W = 28;
        private const int BYTE_CELL_H = 22;

        private const int COL_HEX    = 2;
        private const int COL_PARSED = 3;

        public Form4_DgvDgvParamForm()
        {
            InitializeComponent();
            _params = BinaryParameter.GetSampleParameters();
            _data   = BinaryParameter.GetSampleData();
            SetupGrid();
            InitDgvOverlay();
            RefreshGrid();
        }

        // ---- メイングリッド定義 ----

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            dataGridView.Columns.Add(MakeCol("colName",   "パラメータ名", 110, Color.FromArgb(232,234,248), Color.FromArgb(30,40,120),  true));
            dataGridView.Columns.Add(MakeCol("colDesc",   "説明",         185, Color.White,                Color.FromArgb(40,40,80),    false));
            dataGridView.Columns.Add(MakeCol("colHex",    "HEX値",         130, Color.FromArgb(255,252,220),Color.FromArgb(0,100,180),   false));
            dataGridView.Columns.Add(MakeCol("colParsed", "解析値",         90, Color.White,                Color.FromArgb(0,120,60),    false));
            dataGridView.Columns.Add(MakeCol("colUnit",   "単位",           55, Color.White,                Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colOffset", "Offset",         70, Color.FromArgb(242,242,250),Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colLen",    "Len",            38, Color.FromArgb(242,242,250),Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colFmt",    "形式",           70, Color.FromArgb(242,242,250),Color.DimGray,               false));

            var hdr = dataGridView.ColumnHeadersDefaultCellStyle;
            hdr.Font      = new Font("Meiryo UI", 9f, FontStyle.Bold);
            hdr.BackColor = Color.FromArgb(45, 75, 145);
            hdr.ForeColor = Color.White;
            hdr.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dataGridView.EnableHeadersVisualStyles  = false;
            dataGridView.ColumnHeadersHeight        = 26;
            dataGridView.RowHeadersWidth            = 4;
            dataGridView.AllowUserToAddRows         = false;
            dataGridView.AllowUserToDeleteRows      = false;
            dataGridView.AllowUserToResizeRows      = false;
            dataGridView.AllowUserToResizeColumns   = false;
            dataGridView.AutoSizeColumnsMode        = DataGridViewAutoSizeColumnsMode.None;
            dataGridView.MultiSelect                = false;
            dataGridView.SelectionMode              = DataGridViewSelectionMode.FullRowSelect;
            dataGridView.CellBorderStyle            = DataGridViewCellBorderStyle.None;
            dataGridView.RowHeadersBorderStyle      = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersBorderStyle   = DataGridViewHeaderBorderStyle.None;
            dataGridView.BackgroundColor            = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 215, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick += Grid_CellClick;
            dataGridView.Scroll    += (s, e) => CloseOverlay(true);
            dataGridView.ResumeLayout();
        }

        private DataGridViewTextBoxColumn MakeCol(string name, string header, int width,
            Color back, Color fore, bool bold)
        {
            return new DataGridViewTextBoxColumn
            {
                Name = name, HeaderText = header, Width = width, ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font      = new Font("Courier New", 9f, bold ? FontStyle.Bold : FontStyle.Regular),
                    BackColor = back, ForeColor = fore,
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            };
        }

        // ---- オーバーレイDataGridView 初期化 ----

        private void InitDgvOverlay()
        {
            _dgvOverlay = new DataGridView();
            _dgvOverlay.Visible                  = false;
            _dgvOverlay.Font                     = new Font("Courier New", 9.5f, FontStyle.Bold);
            _dgvOverlay.BackgroundColor          = Color.FromArgb(255, 252, 180);
            _dgvOverlay.BorderStyle              = BorderStyle.FixedSingle;
            _dgvOverlay.AllowUserToAddRows       = false;
            _dgvOverlay.AllowUserToDeleteRows    = false;
            _dgvOverlay.AllowUserToResizeRows    = false;
            _dgvOverlay.AllowUserToResizeColumns = false;
            _dgvOverlay.AutoSizeColumnsMode      = DataGridViewAutoSizeColumnsMode.None;
            _dgvOverlay.ColumnHeadersVisible     = false;
            _dgvOverlay.RowHeadersVisible        = false;
            _dgvOverlay.MultiSelect              = false;
            _dgvOverlay.ScrollBars               = ScrollBars.None;
            _dgvOverlay.SelectionMode            = DataGridViewSelectionMode.CellSelect;
            _dgvOverlay.CellBorderStyle          = DataGridViewCellBorderStyle.None;
            _dgvOverlay.EditMode                 = DataGridViewEditMode.EditOnKeystrokeOrF2;

            _dgvOverlay.EditingControlShowing += DgvOverlay_EditingControlShowing;
            _dgvOverlay.CellValidated         += DgvOverlay_CellValidated;
            _dgvOverlay.KeyDown               += DgvOverlay_KeyDown;
            _dgvOverlay.LostFocus             += DgvOverlay_LostFocus;

            dataGridView.Controls.Add(_dgvOverlay);
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            foreach (var p in _params)
            {
                int ri = dataGridView.Rows.Add(
                    p.Name, p.Description, p.BuildHexStr(_data),
                    p.ParseValue(_data), p.Unit,
                    string.Format("0x{0:X4}", p.Offset),
                    p.Length.ToString(), p.Format);
                dataGridView.Rows[ri].Height = 22;

                if (p.Name.StartsWith("Reserved"))
                    for (int c = 0; c < dataGridView.Columns.Count; c++)
                        dataGridView.Rows[ri].Cells[c].Style.ForeColor = Color.LightGray;
            }
            dataGridView.ResumeLayout();
        }

        // ---- メイングリッド：セルクリック ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != COL_HEX)
            {
                CloseOverlay(true);
                return;
            }
            OpenOverlay(e.RowIndex);
        }

        // ---- オーバーレイを開く ----

        private void OpenOverlay(int rowIdx)
        {
            if (_dgvOverlay.Visible)
                CloseOverlay(true);

            _editRow         = rowIdx;
            _pendingMoveNext = false;

            var p    = _params[rowIdx];
            Rectangle rect = dataGridView.GetCellDisplayRectangle(COL_HEX, rowIdx, false);

            // ---- 列をバイト数分だけ生成 ----
            _setting = true;
            _dgvOverlay.Columns.Clear();
            _dgvOverlay.Rows.Clear();

            for (int b = 0; b < p.Length; b++)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    Name         = "b" + b,
                    Width        = BYTE_CELL_W,
                    MinimumWidth = BYTE_CELL_W,
                    SortMode     = DataGridViewColumnSortMode.NotSortable,
                };
                col.DefaultCellStyle.Font               = new Font("Courier New", 9.5f, FontStyle.Bold);
                col.DefaultCellStyle.BackColor          = Color.FromArgb(255, 252, 180);
                col.DefaultCellStyle.ForeColor          = Color.DarkRed;
                col.DefaultCellStyle.Alignment          = DataGridViewContentAlignment.MiddleCenter;
                col.DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 230, 100);
                col.DefaultCellStyle.SelectionForeColor = Color.DarkRed;
                _dgvOverlay.Columns.Add(col);
            }

            _dgvOverlay.Rows.Add();
            _dgvOverlay.Rows[0].Height = BYTE_CELL_H - 2;

            // 初期値セット
            for (int b = 0; b < p.Length; b++)
            {
                int idx = p.Offset + b;
                _dgvOverlay.Rows[0].Cells[b].Value =
                    idx < _data.Length ? _data[idx].ToString("X2") : "00";
            }
            _setting = false;

            // 配置
            _dgvOverlay.Location = new Point(rect.Left, rect.Top);
            _dgvOverlay.Size     = new Size(p.Length * BYTE_CELL_W + 2, BYTE_CELL_H);
            _dgvOverlay.Visible  = true;

            // 0列目を選択して編集開始
            _dgvOverlay.CurrentCell = _dgvOverlay.Rows[0].Cells[0];
            _dgvOverlay.BeginEdit(true);

            lblStatus.Text = string.Format(
                "編集中(DataGridView)  [{0}] {1}  Offset:0x{2:X4}  Length:{3}byte  " +
                "[Enter/Tab]:次バイト or 確定  [Esc]:キャンセル",
                p.Name, p.Description, p.Offset, p.Length);
        }

        // ---- オーバーレイ：EditingControlShowing ----
        // TextBoxを取得してKeyPress(HEX制限)とTextChanged(2文字検知)を登録

        private void DgvOverlay_EditingControlShowing(object sender,
            DataGridViewEditingControlShowingEventArgs e)
        {
            if (_setting) return;
            var tb = e.Control as TextBox;
            if (tb == null) return;

            tb.MaxLength       = 2;
            tb.CharacterCasing = CharacterCasing.Upper;

            // 二重登録防止
            tb.KeyPress    -= Tb_KeyPress;
            tb.TextChanged -= Tb_TextChanged;
            tb.KeyPress    += Tb_KeyPress;
            tb.TextChanged += Tb_TextChanged;
        }

        // ---- TextBox：HEX文字のみ受け付ける ----

        private void Tb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar)) return;
            char c = char.ToUpper(e.KeyChar);
            if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F')))
            {
                e.Handled = true;
                System.Media.SystemSounds.Beep.Play();
            }
        }

        // ---- TextBox：2文字入力でフラグを立てるだけ ----
        // 実際の移動はCellValidated（EndEdit完了後）で行う

        private void Tb_TextChanged(object sender, EventArgs e)
        {
            if (_setting) return;
            var tb = sender as TextBox;
            if (tb != null && tb.Text.Length >= 2)
                _pendingMoveNext = true;
        }

        // ---- CellValidated：EndEdit完了後に呼ばれる → ここで安全に移動 ----

        private void DgvOverlay_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            if (_setting) return;
            if (!_pendingMoveNext) return;
            _pendingMoveNext = false;

            MoveToNextCell(e.ColumnIndex);
        }

        // ---- KeyDown：Enter/Tab/Esc ----

        private void DgvOverlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                // 現在列を取得してからEndEdit → CellValidatedで移動
                _pendingMoveNext = true;
                e.Handled        = true;
                e.SuppressKeyPress = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                CloseOverlay(false);
                lblStatus.Text     = "編集キャンセル";
                e.Handled          = true;
                e.SuppressKeyPress = true;
            }
        }

        // ---- 次セルへ移動（CellValidated から呼ばれる） ----

        private void MoveToNextCell(int currentCol)
        {
            if (_editRow < 0 || !_dgvOverlay.Visible) return;

            int next = currentCol + 1;

            if (next < _dgvOverlay.Columns.Count)
            {
                // 次のバイトセルへ
                _setting = true;
                _dgvOverlay.CurrentCell = _dgvOverlay.Rows[0].Cells[next];
                _setting = false;
                _dgvOverlay.BeginEdit(true);
            }
            else
            {
                // 全バイト入力完了 → 保存・閉じる・次パラメータへ
                int nextRow = _editRow + 1;
                CloseOverlay(true);
                if (nextRow < _params.Count)
                    OpenOverlay(nextRow);
            }
        }

        // ---- LostFocus：オーバーレイ外へ出たら保存して閉じる ----

        private void DgvOverlay_LostFocus(object sender, EventArgs e)
        {
            if (_setting) return;
            if (_dgvOverlay.IsCurrentCellInEditMode) return;
            if (_dgvOverlay.Visible)
                CloseOverlay(true);
        }

        // ---- オーバーレイを閉じる ----

        private void CloseOverlay(bool save)
        {
            if (!_dgvOverlay.Visible) return;

            if (save) SaveOverlay();

            _setting = true;
            try   { _dgvOverlay.EndEdit(); } catch { }
            _dgvOverlay.Visible = false;
            _setting = false;

            _editRow         = -1;
            _pendingMoveNext = false;
        }

        // ---- 保存 ----

        private void SaveOverlay()
        {
            if (_editRow < 0) return;

            // 編集中の値を確定してからセル値を読む
            _setting = true;
            try   { _dgvOverlay.EndEdit(); } catch { }
            _setting = false;

            var p        = _params[_editRow];
            var newBytes = new byte[p.Length];
            bool valid   = true;

            for (int b = 0; b < p.Length; b++)
            {
                string val = _dgvOverlay.Rows[0].Cells[b].Value?.ToString()?.Trim() ?? "";
                try   { newBytes[b] = Convert.ToByte(val, 16); }
                catch { valid = false; break; }
            }

            if (!valid)
            {
                lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
                return;
            }

            for (int b = 0; b < p.Length; b++)
            {
                int idx = p.Offset + b;
                if (idx < _data.Length) _data[idx] = newBytes[b];
            }

            dataGridView.Rows[_editRow].Cells[COL_HEX].Value    = p.BuildHexStr(_data);
            dataGridView.Rows[_editRow].Cells[COL_PARSED].Value  = p.ParseValue(_data);
            lblStatus.Text = string.Format("更新完了  [{0}]  {1}", p.Name, p.BuildHexStr(_data));
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            CloseOverlay(true);
            using (var dlg = new OpenFileDialog
                   { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshGrid();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)",
                        Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            CloseOverlay(true);
            using (var dlg = new SaveFileDialog
                   { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("保存失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
