using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面④ DataGridView ― パラメータ毎表示・編集
    /// 表示: DataGridView
    /// 編集: DataGridView をセル上に重ねて使用
    /// </summary>
    public partial class Form4_DgvDgvParamForm : Form
    {
        private byte[]                _data;
        private List<BinaryParameter> _params;

        // オーバーレイ用DataGridView（編集時にセル上に重ねる）
        private DataGridView _dgvOverlay;
        private int          _editRow = -1;
        private bool         _isCommitting = false; // 再帰呼び出し防止フラグ

        // 列インデックス
        private const int COL_NAME   = 0;
        private const int COL_DESC   = 1;
        private const int COL_HEX    = 2;
        private const int COL_PARSED = 3;
        private const int COL_UNIT   = 4;
        private const int COL_OFFSET = 5;
        private const int COL_LEN    = 6;
        private const int COL_FMT    = 7;

        public Form4_DgvDgvParamForm()
        {
            InitializeComponent();
            _params = BinaryParameter.GetSampleParameters();
            _data   = BinaryParameter.GetSampleData();
            SetupGrid();
            InitDgvOverlay();
            RefreshGrid();
        }

        // ---- グリッド定義 ----

        // バイトセル固定幅（オーバーレイDataGridViewのセル用）
        private const int BYTE_CELL_WIDTH  = 28;
        private const int BYTE_CELL_HEIGHT = 22;

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            dataGridView.Columns.Add(MakeCol("colName",   "パラメータ名", 110, Color.FromArgb(232,234,248), Color.FromArgb(30,40,120),  true));
            dataGridView.Columns.Add(MakeCol("colDesc",   "説明",         185, Color.White,                Color.FromArgb(40,40,80),    false));
            dataGridView.Columns.Add(MakeCol("colHex",    "HEX値",         130, Color.FromArgb(255,252,220),Color.FromArgb(0,100,180),   false));
            dataGridView.Columns.Add(MakeCol("colParsed", "解析値",         90, Color.White,                Color.FromArgb(0,120,60),    false));
            dataGridView.Columns.Add(MakeCol("colUnit",   "単位",           55, Color.White,                Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colOffset", "Offset",         70, Color.FromArgb(242,242,250),Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colLen",    "Len",            38, Color.FromArgb(242,242,250),Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colFmt",    "形式",           70, Color.FromArgb(242,242,250),Color.DimGray,               false));

            var hdr = dataGridView.ColumnHeadersDefaultCellStyle;
            hdr.Font      = new Font("Meiryo UI", 9f, FontStyle.Bold);
            hdr.BackColor = Color.FromArgb(45, 75, 145);
            hdr.ForeColor = Color.White;
            hdr.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView.EnableHeadersVisualStyles        = false;
            dataGridView.ColumnHeadersHeight              = 26;
            dataGridView.RowHeadersWidth                  = 4;
            dataGridView.AllowUserToAddRows               = false;
            dataGridView.AllowUserToDeleteRows            = false;
            dataGridView.AllowUserToResizeRows            = false;
            dataGridView.AllowUserToResizeColumns         = false;   // 列幅変更不可
            dataGridView.AutoSizeColumnsMode              = DataGridViewAutoSizeColumnsMode.None;
            dataGridView.MultiSelect                      = false;
            dataGridView.SelectionMode                    = DataGridViewSelectionMode.FullRowSelect;
            dataGridView.CellBorderStyle                  = DataGridViewCellBorderStyle.None;  // 境界線なし
            dataGridView.RowHeadersBorderStyle            = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersBorderStyle         = DataGridViewHeaderBorderStyle.None;
            dataGridView.BackgroundColor                  = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 215, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick += Grid_CellClick;
            dataGridView.Scroll    += (s, e) => HideOverlay();
            dataGridView.ResumeLayout();
        }

        private DataGridViewTextBoxColumn MakeCol(string name, string header,
            int width, Color back, Color fore, bool bold)
        {
            return new DataGridViewTextBoxColumn
            {
                Name      = name,
                HeaderText = header,
                Width     = width,
                ReadOnly  = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font      = new Font("Courier New", 9f, bold ? FontStyle.Bold : FontStyle.Regular),
                    BackColor = back,
                    ForeColor = fore,
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            };
        }

        // ---- DataGridViewオーバーレイ初期化 ----

        private void InitDgvOverlay()
        {
            _dgvOverlay = new DataGridView();
            _dgvOverlay.Visible                    = false;
            _dgvOverlay.Font                       = new Font("Courier New", 9.5f, FontStyle.Bold);
            _dgvOverlay.BackgroundColor            = Color.FromArgb(255, 252, 180);
            _dgvOverlay.BorderStyle                = BorderStyle.FixedSingle;
            _dgvOverlay.AllowUserToAddRows         = false;
            _dgvOverlay.AllowUserToDeleteRows      = false;
            _dgvOverlay.AllowUserToResizeRows      = false;
            _dgvOverlay.AllowUserToResizeColumns   = false;
            _dgvOverlay.AutoSizeColumnsMode        = DataGridViewAutoSizeColumnsMode.None;
            _dgvOverlay.ColumnHeadersVisible       = false;
            _dgvOverlay.RowHeadersVisible          = false;
            _dgvOverlay.MultiSelect                = false;
            _dgvOverlay.ScrollBars                 = ScrollBars.None;
            _dgvOverlay.SelectionMode              = DataGridViewSelectionMode.CellSelect;
            _dgvOverlay.CellBorderStyle            = DataGridViewCellBorderStyle.None; // 境界線なし

            _dgvOverlay.KeyDown               += DgvOverlay_KeyDown;
            _dgvOverlay.CellEndEdit           += DgvOverlay_CellEndEdit;
            _dgvOverlay.LostFocus             += DgvOverlay_LostFocus;
            _dgvOverlay.EditingControlShowing += DgvOverlay_EditingControlShowing;

            dataGridView.Controls.Add(_dgvOverlay);
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            foreach (var p in _params)
            {
                int ri = dataGridView.Rows.Add(
                    p.Name,
                    p.Description,
                    p.BuildHexStr(_data),
                    p.ParseValue(_data),
                    p.Unit,
                    string.Format("0x{0:X4}", p.Offset),
                    p.Length.ToString(),
                    p.Format
                );
                dataGridView.Rows[ri].Height = 22;

                if (p.Name.StartsWith("Reserved"))
                    for (int c = 0; c < dataGridView.Columns.Count; c++)
                        dataGridView.Rows[ri].Cells[c].Style.ForeColor = Color.LightGray;
            }

            dataGridView.ResumeLayout();
        }

        // ---- セルクリック → DataGridViewオーバーレイ表示 ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) { HideOverlay(); return; }
            if (e.ColumnIndex != COL_HEX) { HideOverlay(); return; }
            ShowOverlay(e.RowIndex);
        }

        private void ShowOverlay(int rowIdx)
        {
            HideOverlay();
            _editRow = rowIdx;

            var p = _params[rowIdx];

            // HEXセル矩形を取得
            Rectangle rect = dataGridView.GetCellDisplayRectangle(COL_HEX, rowIdx, false);

            // オーバーレイDataGridViewにバイト数分の列を動的に作成
            _dgvOverlay.Columns.Clear();
            _dgvOverlay.Rows.Clear();

            for (int b = 0; b < p.Length; b++)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    Name         = "byte" + b,
                    HeaderText   = b.ToString(),
                    Width        = BYTE_CELL_WIDTH,        // バイトセル固定幅
                    MinimumWidth = BYTE_CELL_WIDTH,
                    SortMode     = DataGridViewColumnSortMode.NotSortable
                };
                col.DefaultCellStyle.Font               = new Font("Courier New", 9.5f, FontStyle.Bold);
                col.DefaultCellStyle.BackColor          = Color.FromArgb(255, 252, 180);
                col.DefaultCellStyle.ForeColor          = Color.DarkRed;
                col.DefaultCellStyle.Alignment          = DataGridViewContentAlignment.MiddleCenter;
                col.DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 230, 100);
                col.DefaultCellStyle.SelectionForeColor = Color.DarkRed;
                _dgvOverlay.Columns.Add(col);
            }

            // バイトデータをセットして表示
            _dgvOverlay.Rows.Add();
            _dgvOverlay.Rows[0].Height = BYTE_CELL_HEIGHT - 2; // 固定高さ
            for (int b = 0; b < p.Length; b++)
            {
                int idx = p.Offset + b;
                _dgvOverlay.Rows[0].Cells[b].Value = idx < _data.Length ? _data[idx].ToString("X2") : "00";
            }

            // オーバーレイサイズ = バイト数 × 固定幅
            int overlayWidth = p.Length * BYTE_CELL_WIDTH + 2;
            _dgvOverlay.Location = new Point(rect.Left + 1, rect.Top + 1);
            _dgvOverlay.Size     = new Size(overlayWidth, BYTE_CELL_HEIGHT);
            _dgvOverlay.Visible  = true;

            // 1バイト目を編集開始
            _dgvOverlay.CurrentCell = _dgvOverlay.Rows[0].Cells[0];
            _dgvOverlay.BeginEdit(true);
            _dgvOverlay.Focus();

            lblStatus.Text = string.Format(
                "編集中(DataGridView)  [{0}] {1}  Offset:0x{2:X4}  Length:{3}byte  形式:{4}  [Enter/Tab]:次バイト or 確定  [Esc]:キャンセル",
                p.Name, p.Description, p.Offset, p.Length, p.Format);
        }

        private void CommitOverlay()
        {
            if (_isCommitting) return;
            if (_editRow < 0 || !_dgvOverlay.Visible) return;
            _isCommitting = true;
            try
            {
                _dgvOverlay.EndEdit();

                var p = _params[_editRow];
                bool valid = true;
                var newBytes = new byte[p.Length];

                for (int b = 0; b < p.Length; b++)
                {
                    string val = _dgvOverlay.Rows[0].Cells[b].Value?.ToString() ?? "";
                    val = val.Trim();
                    try { newBytes[b] = Convert.ToByte(val, 16); }
                    catch { valid = false; break; }
                }

                if (!valid)
                {
                    lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
                    HideOverlay();
                    return;
                }

                for (int b = 0; b < p.Length; b++)
                {
                    int idx = p.Offset + b;
                    if (idx < _data.Length) _data[idx] = newBytes[b];
                }

                dataGridView.Rows[_editRow].Cells[COL_HEX].Value    = p.BuildHexStr(_data);
                dataGridView.Rows[_editRow].Cells[COL_PARSED].Value  = p.ParseValue(_data);
                lblStatus.Text = string.Format("更新完了  [{0}]  {1}", p.Name, p.BuildHexStr(_data));

                HideOverlay();
            }
            finally
            {
                _isCommitting = false;
            }
        }

        private void HideOverlay()
        {
            if (_dgvOverlay.Visible)
            {
                _dgvOverlay.EndEdit();
                _dgvOverlay.Visible = false;
            }
            _editRow = -1;
        }

        // ---- オーバーレイイベント ----

        private void DgvOverlay_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            var tb = e.Control as TextBox;
            if (tb == null) return;
            tb.MaxLength       = 2;
            tb.CharacterCasing = CharacterCasing.Upper;
            tb.KeyPress    -= TbOverlay_KeyPress;   // 二重登録防止
            tb.KeyPress    += TbOverlay_KeyPress;
            tb.TextChanged -= TbOverlay_TextChanged; // 二重登録防止
            tb.TextChanged += TbOverlay_TextChanged;
        }

        private void TbOverlay_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar)) return;
            char c = char.ToUpper(e.KeyChar);
            if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F')))
            {
                e.Handled = true;
                System.Media.SystemSounds.Beep.Play();
            }
        }

        /// <summary>2文字入力されたら自動で次セルへ移動（最終セルなら確定）</summary>
        private void TbOverlay_TextChanged(object sender, EventArgs e)
        {
            if (_isCommitting) return;
            var tb = sender as TextBox;
            if (tb == null || tb.Text.Length < 2) return;

            int curCol = _dgvOverlay.CurrentCell?.ColumnIndex ?? 0;
            int nextCol = curCol + 1;

            if (nextCol < _dgvOverlay.Columns.Count)
            {
                // 次のバイトへ自動移動
                _dgvOverlay.EndEdit();
                _dgvOverlay.CurrentCell = _dgvOverlay.Rows[0].Cells[nextCol];
                _dgvOverlay.BeginEdit(true);
            }
            else
            {
                // 全バイト入力完了 → 確定
                int nextRow = _editRow + 1;
                CommitOverlay();
                if (nextRow >= 0 && nextRow < _params.Count)
                    ShowOverlay(nextRow);
            }
        }

        private void DgvOverlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                if (!_isCommitting)
                {
                    int curCol  = _dgvOverlay.CurrentCell?.ColumnIndex ?? 0;
                    int nextCol = curCol + 1;
                    _dgvOverlay.EndEdit();
                    if (nextCol < _dgvOverlay.Columns.Count)
                    {
                        _dgvOverlay.CurrentCell = _dgvOverlay.Rows[0].Cells[nextCol];
                        _dgvOverlay.BeginEdit(true);
                    }
                    else
                    {
                        int nextRow = _editRow + 1;
                        CommitOverlay();
                        if (nextRow >= 0 && nextRow < _params.Count)
                            ShowOverlay(nextRow);
                    }
                }
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HideOverlay();
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void DgvOverlay_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // セル確定時に自動で2文字チェック（任意）
        }

        private void DgvOverlay_LostFocus(object sender, EventArgs e)
        {
            if (_isCommitting) return;
            if (_dgvOverlay.IsCurrentCellInEditMode) return;
            if (_dgvOverlay.Visible) CommitOverlay();
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshGrid();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)", Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                { MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                { MessageBox.Show("保存失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }
    }
}
