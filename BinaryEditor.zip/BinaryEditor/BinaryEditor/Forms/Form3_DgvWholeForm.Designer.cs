namespace BinaryEditor.Forms
{
    partial class Form3_DgvWholeForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        private void InitializeComponent()
        {
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.panelTop     = new System.Windows.Forms.Panel();
            this.lblTitle     = new System.Windows.Forms.Label();
            this.lblInfo      = new System.Windows.Forms.Label();
            this.btnOpen      = new System.Windows.Forms.Button();
            this.btnSave      = new System.Windows.Forms.Button();
            this.lblStatus    = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();

            this.panelTop.Dock      = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Height    = 76;
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(228, 242, 232);
            this.panelTop.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblTitle, this.lblInfo, this.btnOpen, this.btnSave });

            this.lblTitle.Location  = new System.Drawing.Point(10, 6);
            this.lblTitle.Size      = new System.Drawing.Size(700, 22);
            this.lblTitle.AutoSize  = false;
            this.lblTitle.Font      = new System.Drawing.Font("Meiryo UI", 10f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(20, 90, 40);
            this.lblTitle.Text      = "画面③ DataGridView ― バイナリ全体表示・編集";

            this.lblInfo.Location  = new System.Drawing.Point(10, 30);
            this.lblInfo.Size      = new System.Drawing.Size(750, 16);
            this.lblInfo.AutoSize  = false;
            this.lblInfo.Font      = new System.Drawing.Font("Meiryo UI", 8f);
            this.lblInfo.ForeColor = System.Drawing.Color.DimGray;
            this.lblInfo.Text      = "操作: バイトセルをクリック → HexEditControlがセル上に重なる → HEX入力 → Enter/Tab:確定・次へ  Esc:キャンセル";

            this.btnOpen.Location  = new System.Drawing.Point(10, 50);
            this.btnOpen.Size      = new System.Drawing.Size(72, 22);
            this.btnOpen.Text      = "開く";
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpen.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnOpen.Click    += new System.EventHandler(this.btnOpen_Click);

            this.btnSave.Location  = new System.Drawing.Point(88, 50);
            this.btnSave.Size      = new System.Drawing.Size(72, 22);
            this.btnSave.Text      = "保存";
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.Click    += new System.EventHandler(this.btnSave_Click);

            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;

            this.lblStatus.Dock      = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.Height    = 22;
            this.lblStatus.BackColor = System.Drawing.Color.FromArgb(210, 235, 215);
            this.lblStatus.Font      = new System.Drawing.Font("Meiryo UI", 8.5f);
            this.lblStatus.Text      = "バイトセルをクリックしてHexEditControlで編集します";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStatus.Padding   = new System.Windows.Forms.Padding(6, 0, 0, 0);

            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(920, 560);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblStatus);
            this.Font                = new System.Drawing.Font("Meiryo UI", 9f);
            this.Name                = "Form3_DgvWholeForm";
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "画面③ DataGridView ― 全体表示・編集";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Panel        panelTop;
        private System.Windows.Forms.Label        lblTitle;
        private System.Windows.Forms.Label        lblInfo;
        private System.Windows.Forms.Button       btnOpen;
        private System.Windows.Forms.Button       btnSave;
        private System.Windows.Forms.Label        lblStatus;
    }
}
