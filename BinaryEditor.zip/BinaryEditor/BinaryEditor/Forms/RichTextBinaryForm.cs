using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// RichTextBoxを使用したバイナリエディタ画面
    /// </summary>
    public partial class RichTextBinaryForm : Form
    {
        private byte[] _data;
        private const int BYTES_PER_ROW = 16;

        // インラインHexEditControlオーバーレイ
        private HexEditControl _hexEditOverlay;
        private int _editingOffset = -1;

        public RichTextBinaryForm()
        {
            InitializeComponent();
            InitializeHexEditOverlay();
            LoadSampleData();
        }

        // ---- 初期化 ----

        private void InitializeHexEditOverlay()
        {
            _hexEditOverlay = new HexEditControl();
            _hexEditOverlay.Visible = false;
            _hexEditOverlay.Size = new Size(28, 20);
            _hexEditOverlay.KeyDown += HexEditOverlay_KeyDown;
            _hexEditOverlay.LostFocus += HexEditOverlay_LostFocus;
            richTextBox.Controls.Add(_hexEditOverlay);
        }

        private void LoadSampleData()
        {
            // サンプルバイナリデータ(64バイト)
            _data = new byte[64];
            for (int i = 0; i < _data.Length; i++)
                _data[i] = (byte)(i * 3 + 0x10);
            RefreshDisplay();
        }

        // ---- 表示 ----

        private void RefreshDisplay()
        {
            richTextBox.SuspendLayout();
            richTextBox.Clear();

            var sb = new StringBuilder();
            // ヘッダ行
            sb.Append("Offset  ");
            for (int i = 0; i < BYTES_PER_ROW; i++)
                sb.AppendFormat("{0:X2} ", i);
            sb.Append("  ASCII\r\n");
            sb.Append(new string('-', 75) + "\r\n");

            // データ行
            for (int row = 0; row * BYTES_PER_ROW < _data.Length; row++)
            {
                int offset = row * BYTES_PER_ROW;
                sb.AppendFormat("{0:X8}  ", offset);

                var ascii = new StringBuilder();
                for (int col = 0; col < BYTES_PER_ROW; col++)
                {
                    int idx = offset + col;
                    if (idx < _data.Length)
                    {
                        sb.AppendFormat("{0:X2} ", _data[idx]);
                        char c = (char)_data[idx];
                        ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                    }
                    else
                    {
                        sb.Append("   ");
                        ascii.Append(' ');
                    }
                }
                sb.Append("  ");
                sb.Append(ascii.ToString());
                sb.Append("\r\n");
            }

            richTextBox.Text = sb.ToString();
            ApplySyntaxColoring();
            richTextBox.ResumeLayout();
        }

        private void ApplySyntaxColoring()
        {
            // ヘッダ部分を色付け
            richTextBox.SelectionStart = 0;
            int headerLen = richTextBox.Text.IndexOf("\r\n", richTextBox.Text.IndexOf("--")) + 2;
            if (headerLen > 0)
            {
                richTextBox.Select(0, headerLen);
                richTextBox.SelectionColor = Color.Gray;
                richTextBox.SelectionFont = new Font("Courier New", 9f, FontStyle.Bold);
            }

            // ゼロバイト強調
            string text = richTextBox.Text;
            int start = headerLen;
            for (int i = start; i < text.Length - 2; i++)
            {
                if (i + 1 < text.Length && text[i] == '0' && text[i + 1] == '0' && text[i + 2] == ' ')
                {
                    richTextBox.Select(i, 2);
                    richTextBox.SelectionColor = Color.Gray;
                }
            }

            richTextBox.SelectionStart = 0;
            richTextBox.SelectionLength = 0;
        }

        // ---- クリック編集 ----

        private void richTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (_data == null) return;

            int charIndex = richTextBox.GetCharIndexFromPosition(e.Location);
            int line = richTextBox.GetLineFromCharIndex(charIndex);
            int lineStart = richTextBox.GetFirstCharIndexFromLine(line);
            int col = charIndex - lineStart;

            // ヘッダ行2行をスキップ
            if (line < 2) return;

            int dataRow = line - 2;
            // オフセット部分(10文字)をスキップ、各バイトは3文字
            int dataColStart = 10;
            int relCol = col - dataColStart;
            if (relCol < 0) return;

            int byteCol = relCol / 3;
            if (byteCol >= BYTES_PER_ROW) return;

            int offset = dataRow * BYTES_PER_ROW + byteCol;
            if (offset >= _data.Length) return;

            ShowHexEditOverlay(offset, charIndex, line, byteCol);
        }

        private void ShowHexEditOverlay(int offset, int charIndex, int line, int byteCol)
        {
            _editingOffset = offset;

            // キャレット位置を取得してオーバーレイを配置
            int lineStart = richTextBox.GetFirstCharIndexFromLine(line);
            int byteCharIdx = lineStart + 10 + byteCol * 3;
            Point bytePos = richTextBox.GetPositionFromCharIndex(byteCharIdx);

            _hexEditOverlay.Location = new Point(bytePos.X, bytePos.Y);
            _hexEditOverlay.SetByteValue(_data[offset]);
            _hexEditOverlay.Visible = true;
            _hexEditOverlay.Focus();
            _hexEditOverlay.SelectAll();

            // ステータス更新
            lblStatus.Text = $"編集中 - Offset: 0x{offset:X4} ({offset}), 現在値: 0x{_data[offset]:X2}";
        }

        private void CommitHexEdit()
        {
            if (_editingOffset < 0 || !_hexEditOverlay.Visible) return;

            if (_hexEditOverlay.IsValidHex)
            {
                byte? val = _hexEditOverlay.GetByteValue();
                if (val.HasValue)
                {
                    _data[_editingOffset] = val.Value;
                    lblStatus.Text = $"更新完了 - Offset: 0x{_editingOffset:X4}, 新しい値: 0x{val.Value:X2}";
                }
            }
            _hexEditOverlay.Visible = false;
            _editingOffset = -1;
            RefreshDisplay();
        }

        private void HexEditOverlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                CommitHexEdit();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                _hexEditOverlay.Visible = false;
                _editingOffset = -1;
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void HexEditOverlay_LostFocus(object sender, EventArgs e)
        {
            if (_hexEditOverlay.Visible)
                CommitHexEdit();
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Filter = "すべてのファイル (*.*)|*.*|バイナリファイル (*.bin)|*.bin";
                dlg.Title = "バイナリファイルを開く";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        _data = File.ReadAllBytes(dlg.FileName);
                        RefreshDisplay();
                        lblStatus.Text = $"ファイル読み込み完了: {Path.GetFileName(dlg.FileName)} ({_data.Length} bytes)";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ファイルの読み込みに失敗しました。\n{ex.Message}", "エラー",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "バイナリファイル (*.bin)|*.bin|すべてのファイル (*.*)|*.*";
                dlg.Title = "バイナリファイルを保存";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllBytes(dlg.FileName, _data);
                        lblStatus.Text = $"保存完了: {Path.GetFileName(dlg.FileName)}";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"保存に失敗しました。\n{ex.Message}", "エラー",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            using (var dlg = new SizeInputDialog())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _data = new byte[dlg.DataSize];
                    RefreshDisplay();
                    lblStatus.Text = $"新規データ作成: {_data.Length} bytes";
                }
            }
        }
    }

    // ---- サイズ入力ダイアログ ----
    internal class SizeInputDialog : Form
    {
        private NumericUpDown numSize;
        private Button btnOK;
        private Button btnCancel;
        public int DataSize { get; private set; } = 256;

        public SizeInputDialog()
        {
            this.Text = "データサイズを入力";
            this.Size = new Size(280, 140);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;

            var lbl = new Label { Text = "バイト数:", Location = new Point(15, 20), AutoSize = true };
            numSize = new NumericUpDown
            {
                Location = new Point(15, 40),
                Size = new Size(120, 23),
                Minimum = 1,
                Maximum = 65536,
                Value = 256
            };
            btnOK = new Button
            {
                Text = "OK",
                Location = new Point(60, 75),
                Size = new Size(70, 28),
                DialogResult = DialogResult.OK
            };
            btnCancel = new Button
            {
                Text = "キャンセル",
                Location = new Point(140, 75),
                Size = new Size(90, 28),
                DialogResult = DialogResult.Cancel
            };
            btnOK.Click += (s, e) => { DataSize = (int)numSize.Value; };

            this.Controls.AddRange(new Control[] { lbl, numSize, btnOK, btnCancel });
            this.AcceptButton = btnOK;
            this.CancelButton = btnCancel;
        }
    }
}
