using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面③ DataGridView ― バイナリ全体表示・編集
    /// 表示・編集ともにDataGridViewを使用。
    /// バイトセルをクリックするとHexEditControlがセル上に重なって表示される。
    /// </summary>
    public partial class Form3_DgvWholeForm : Form
    {
        private byte[]         _data;
        private const int      BYTES_PER_ROW = 16;
        private HexEditControl _overlay;
        private int            _editRow = -1;
        private int            _editCol = -1;  // 1-based (col1〜16=data)
        private bool           _isCommitting = false; // 再帰呼び出し防止フラグ

        public Form3_DgvWholeForm()
        {
            InitializeComponent();
            SetupGrid();
            InitOverlay();
            _data = BinaryParameter.GetSampleData();
            RefreshGrid();
        }

        // ---- グリッド定義 ----

        // バイトセル固定幅（px）
        private const int BYTE_CELL_WIDTH  = 28;
        private const int BYTE_CELL_HEIGHT = 22;

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            // Offset列（固定幅）
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name      = "colOfs",
                HeaderText = "Offset",
                Width     = 80,
                MinimumWidth = 80,
                ReadOnly  = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font      = new Font("Courier New", 9f, FontStyle.Bold),
                    BackColor = Color.FromArgb(228, 232, 245),
                    ForeColor = Color.DimGray,
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                }
            });

            // バイト列 × 16（固定幅 BYTE_CELL_WIDTH）
            for (int i = 0; i < BYTES_PER_ROW; i++)
            {
                dataGridView.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name         = "col" + i,
                    HeaderText   = i.ToString("X"),
                    Width        = BYTE_CELL_WIDTH,
                    MinimumWidth = BYTE_CELL_WIDTH,
                    ReadOnly     = true,
                    DefaultCellStyle = new DataGridViewCellStyle
                    {
                        Font      = new Font("Courier New", 9f),
                        BackColor = Color.White,
                        ForeColor = Color.FromArgb(0, 80, 160),
                        Alignment = DataGridViewContentAlignment.MiddleCenter
                    }
                });
            }

            // ASCII列（固定幅）
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name         = "colAscii",
                HeaderText   = "ASCII",
                Width        = 140,
                MinimumWidth = 140,
                ReadOnly     = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font      = new Font("Courier New", 9f),
                    BackColor = Color.FromArgb(240, 255, 240),
                    ForeColor = Color.DarkGreen,
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            });

            var hdr = dataGridView.ColumnHeadersDefaultCellStyle;
            hdr.Font      = new Font("Courier New", 9f, FontStyle.Bold);
            hdr.BackColor = Color.FromArgb(45, 75, 145);
            hdr.ForeColor = Color.White;
            hdr.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView.EnableHeadersVisualStyles    = false;
            dataGridView.ColumnHeadersHeight          = 26;
            dataGridView.RowHeadersWidth              = 4;
            dataGridView.AllowUserToAddRows           = false;
            dataGridView.AllowUserToDeleteRows        = false;
            dataGridView.AllowUserToResizeRows        = false;
            dataGridView.AllowUserToResizeColumns     = false;   // 列幅変更不可
            dataGridView.AutoSizeColumnsMode          = DataGridViewAutoSizeColumnsMode.None; // 自動サイズ無効
            dataGridView.MultiSelect                  = false;
            dataGridView.SelectionMode                = DataGridViewSelectionMode.CellSelect;
            dataGridView.CellBorderStyle              = DataGridViewCellBorderStyle.None;     // 境界線なし
            dataGridView.RowHeadersBorderStyle        = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersBorderStyle     = DataGridViewHeaderBorderStyle.None;
            dataGridView.BackgroundColor              = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 210, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick += Grid_CellClick;
            dataGridView.Scroll    += (s, e) => HideOverlay();
            dataGridView.ResumeLayout();
        }

        private void InitOverlay()
        {
            _overlay = new HexEditControl();
            _overlay.Visible    = false;
            _overlay.Size       = new Size(BYTE_CELL_WIDTH - 2, BYTE_CELL_HEIGHT - 2); // セルに合わせた固定サイズ
            _overlay.KeyDown   += Overlay_KeyDown;
            _overlay.LostFocus += Overlay_LostFocus;
            _overlay.TextChanged += Overlay_TextChanged; // 2文字入力で自動次セル移動
            dataGridView.Controls.Add(_overlay);
        }

        /// <summary>2文字入力されたら自動で確定→次セルへ移動</summary>
        private void Overlay_TextChanged(object sender, EventArgs e)
        {
            if (_isCommitting) return;
            if (_overlay.Text.Length == 2 && _overlay.IsValidHex)
            {
                // 次移動先を先に記憶
                int nextCol = _editCol + 1;
                int nextRow = _editRow;
                if (nextCol > BYTES_PER_ROW) { nextCol = 1; nextRow++; }

                CommitOverlay();

                // 次のセルへ移動
                if (nextRow < dataGridView.Rows.Count)
                    Grid_CellClick(this, new DataGridViewCellEventArgs(nextCol, nextRow));
            }
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            for (int row = 0; row * BYTES_PER_ROW < _data.Length; row++)
            {
                int baseOfs = row * BYTES_PER_ROW;
                var vals    = new object[BYTES_PER_ROW + 2];
                vals[0]     = baseOfs.ToString("X8");

                var ascii = new StringBuilder();
                for (int col = 0; col < BYTES_PER_ROW; col++)
                {
                    int idx = baseOfs + col;
                    if (idx < _data.Length)
                    {
                        vals[col + 1] = _data[idx].ToString("X2");
                        char c = (char)_data[idx];
                        ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                    }
                    else
                    {
                        vals[col + 1] = "";
                        ascii.Append(' ');
                    }
                }
                vals[BYTES_PER_ROW + 1] = ascii.ToString();

                int ri = dataGridView.Rows.Add(vals);
                dataGridView.Rows[ri].Height = BYTE_CELL_HEIGHT;
            }

            ColorizeCells();
            dataGridView.ResumeLayout();
        }

        private void ColorizeCells()
        {
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                for (int c = 1; c <= BYTES_PER_ROW; c++)
                {
                    string v = row.Cells[c].Value?.ToString() ?? "";
                    if (v == "00")      row.Cells[c].Style.ForeColor = Color.LightGray;
                    else if (v == "FF") { row.Cells[c].Style.ForeColor = Color.OrangeRed; row.Cells[c].Style.BackColor = Color.FromArgb(255, 242, 240); }
                }
            }
        }

        // ---- セルクリック → HexEditControlオーバーレイ ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 1 || e.ColumnIndex > BYTES_PER_ROW)
            { HideOverlay(); return; }

            int offset = e.RowIndex * BYTES_PER_ROW + (e.ColumnIndex - 1);
            if (offset >= _data.Length) { HideOverlay(); return; }

            _editRow = e.RowIndex;
            _editCol = e.ColumnIndex;

            Rectangle rect = dataGridView.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
            // セル固定サイズでオーバーレイを配置
            _overlay.Location = new Point(rect.Left + 1, rect.Top + 1);
            _overlay.Size     = new Size(BYTE_CELL_WIDTH - 2, BYTE_CELL_HEIGHT - 2);
            _overlay.SetByteValue(_data[offset]);
            _overlay.Visible  = true;
            _overlay.Focus();
            _overlay.SelectAll();

            lblStatus.Text = string.Format(
                "編集中(HexEditControl)  Offset:0x{0:X4} ({0})  現在値:0x{1:X2}  [Enter/Tab]:確定・次へ  [Esc]:キャンセル",
                offset, _data[offset]);
        }

        private void CommitOverlay()
        {
            if (_isCommitting) return;
            if (_editRow < 0 || !_overlay.Visible) return;
            _isCommitting = true;
            try
            {
                int offset = _editRow * BYTES_PER_ROW + (_editCol - 1);
                if (offset >= _data.Length) { HideOverlay(); return; }

                if (_overlay.IsValidHex)
                {
                    byte? v = _overlay.GetByteValue();
                    if (v.HasValue)
                    {
                        _data[offset] = v.Value;
                        dataGridView.Rows[_editRow].Cells[_editCol].Value = v.Value.ToString("X2");
                        UpdateAsciiCell(_editRow);
                        RefreshCellColor(_editRow, _editCol, v.Value);
                        lblStatus.Text = string.Format(
                            "更新完了  Offset:0x{0:X4} ({0})  新値:0x{1:X2}", offset, v.Value);
                    }
                }
                else
                {
                    lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
                }
                HideOverlay();
            }
            finally
            {
                _isCommitting = false;
            }
        }

        private void HideOverlay()
        {
            _overlay.Visible = false;
            _editRow = -1;
            _editCol = -1;
        }

        private void UpdateAsciiCell(int rowIdx)
        {
            int baseOfs = rowIdx * BYTES_PER_ROW;
            var sb = new StringBuilder();
            for (int c = 0; c < BYTES_PER_ROW; c++)
            {
                int idx = baseOfs + c;
                if (idx < _data.Length) { char ch = (char)_data[idx]; sb.Append(ch >= 0x20 && ch < 0x7F ? ch : '.'); }
                else sb.Append(' ');
            }
            dataGridView.Rows[rowIdx].Cells[BYTES_PER_ROW + 1].Value = sb.ToString();
        }

        private void RefreshCellColor(int rowIdx, int colIdx, byte val)
        {
            var cell = dataGridView.Rows[rowIdx].Cells[colIdx];
            if (val == 0x00)      { cell.Style.ForeColor = Color.LightGray; cell.Style.BackColor = Color.White; }
            else if (val == 0xFF) { cell.Style.ForeColor = Color.OrangeRed; cell.Style.BackColor = Color.FromArgb(255, 242, 240); }
            else                  { cell.Style.ForeColor = Color.FromArgb(0, 80, 160); cell.Style.BackColor = Color.White; }
        }

        private void Overlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                if (!_isCommitting)
                {
                    int nextCol = _editCol + 1;
                    int nextRow = _editRow;
                    if (nextCol > BYTES_PER_ROW) { nextCol = 1; nextRow++; }
                    CommitOverlay();
                    if (nextRow < dataGridView.Rows.Count)
                        Grid_CellClick(this, new DataGridViewCellEventArgs(nextCol, nextRow));
                }
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            { HideOverlay(); lblStatus.Text = "編集キャンセル"; e.Handled = true; }
        }

        private void Overlay_LostFocus(object sender, EventArgs e)
        {
            if (_isCommitting) return;
            if (_overlay.Visible) CommitOverlay();
        }

        private void MoveToNext()
        {
            if (_editRow < 0) return;
            int nc = _editCol + 1;
            int nr = _editRow;
            if (nc > BYTES_PER_ROW) { nc = 1; nr++; }
            if (nr < dataGridView.Rows.Count)
                Grid_CellClick(this, new DataGridViewCellEventArgs(nc, nr));
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshGrid();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)", Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                { MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                { MessageBox.Show("保存失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }
    }
}
