using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    public partial class Form3_DgvWholeForm : Form
    {
        private byte[]         _data;
        private const int      BYTES_PER_ROW    = 16;
        private const int      BYTE_CELL_WIDTH  = 28;
        private const int      BYTE_CELL_HEIGHT = 22;

        private HexEditControl _overlay;
        private int            _editRow         = -1;
        private int            _editCol         = -1;
        private bool           _suppressEvents  = false;

        public Form3_DgvWholeForm()
        {
            InitializeComponent();
            SetupGrid();
            InitOverlay();
            _data = BinaryParameter.GetSampleData();
            RefreshGrid();
        }

        // ---- グリッド定義 ----

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            dataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colOfs", HeaderText = "Offset", Width = 80, MinimumWidth = 80, ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Courier New", 9f, FontStyle.Bold),
                    BackColor = Color.FromArgb(228, 232, 245), ForeColor = Color.DimGray,
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                }
            });

            for (int i = 0; i < BYTES_PER_ROW; i++)
            {
                dataGridView.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "col" + i, HeaderText = i.ToString("X"),
                    Width = BYTE_CELL_WIDTH, MinimumWidth = BYTE_CELL_WIDTH, ReadOnly = true,
                    DefaultCellStyle = new DataGridViewCellStyle
                    {
                        Font = new Font("Courier New", 9f),
                        BackColor = Color.White, ForeColor = Color.FromArgb(0, 80, 160),
                        Alignment = DataGridViewContentAlignment.MiddleCenter
                    }
                });
            }

            dataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colAscii", HeaderText = "ASCII", Width = 140, MinimumWidth = 140, ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Courier New", 9f),
                    BackColor = Color.FromArgb(240, 255, 240), ForeColor = Color.DarkGreen,
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            });

            var hdr = dataGridView.ColumnHeadersDefaultCellStyle;
            hdr.Font = new Font("Courier New", 9f, FontStyle.Bold);
            hdr.BackColor = Color.FromArgb(45, 75, 145);
            hdr.ForeColor = Color.White;
            hdr.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dataGridView.EnableHeadersVisualStyles  = false;
            dataGridView.ColumnHeadersHeight        = 26;
            dataGridView.RowHeadersWidth            = 4;
            dataGridView.AllowUserToAddRows         = false;
            dataGridView.AllowUserToDeleteRows      = false;
            dataGridView.AllowUserToResizeRows      = false;
            dataGridView.AllowUserToResizeColumns   = false;
            dataGridView.AutoSizeColumnsMode        = DataGridViewAutoSizeColumnsMode.None;
            dataGridView.MultiSelect                = false;
            dataGridView.SelectionMode              = DataGridViewSelectionMode.CellSelect;
            dataGridView.CellBorderStyle            = DataGridViewCellBorderStyle.None;
            dataGridView.RowHeadersBorderStyle      = DataGridViewHeaderBorderStyle.None;
            dataGridView.ColumnHeadersBorderStyle   = DataGridViewHeaderBorderStyle.None;
            dataGridView.BackgroundColor            = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 210, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick += Grid_CellClick;
            dataGridView.Scroll    += (s, e) => HideOverlayAndSave();
            dataGridView.ResumeLayout();
        }

        // ---- オーバーレイ初期化 ----

        private void InitOverlay()
        {
            _overlay = new HexEditControl();
            _overlay.Visible      = false;
            _overlay.Size         = new Size(BYTE_CELL_WIDTH - 2, BYTE_CELL_HEIGHT - 2);
            _overlay.KeyDown     += Overlay_KeyDown;
            _overlay.LostFocus   += Overlay_LostFocus;
            _overlay.TextChanged += Overlay_TextChanged;
            dataGridView.Controls.Add(_overlay);
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            for (int row = 0; row * BYTES_PER_ROW < _data.Length; row++)
            {
                int baseOfs = row * BYTES_PER_ROW;
                var vals    = new object[BYTES_PER_ROW + 2];
                vals[0]     = baseOfs.ToString("X8");
                var ascii   = new StringBuilder();

                for (int col = 0; col < BYTES_PER_ROW; col++)
                {
                    int idx = baseOfs + col;
                    if (idx < _data.Length)
                    {
                        vals[col + 1] = _data[idx].ToString("X2");
                        char c = (char)_data[idx];
                        ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                    }
                    else { vals[col + 1] = ""; ascii.Append(' '); }
                }
                vals[BYTES_PER_ROW + 1] = ascii.ToString();

                int ri = dataGridView.Rows.Add(vals);
                dataGridView.Rows[ri].Height = BYTE_CELL_HEIGHT;
            }

            ColorizeCells();
            dataGridView.ResumeLayout();
        }

        private void ColorizeCells()
        {
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                for (int c = 1; c <= BYTES_PER_ROW; c++)
                {
                    string v = row.Cells[c].Value?.ToString() ?? "";
                    if (v == "00") row.Cells[c].Style.ForeColor = Color.LightGray;
                    else if (v == "FF")
                    {
                        row.Cells[c].Style.ForeColor = Color.OrangeRed;
                        row.Cells[c].Style.BackColor = Color.FromArgb(255, 242, 240);
                    }
                }
            }
        }

        // ---- セルクリック ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 1 || e.ColumnIndex > BYTES_PER_ROW)
            { HideOverlayAndSave(); return; }

            int offset = e.RowIndex * BYTES_PER_ROW + (e.ColumnIndex - 1);
            if (offset >= _data.Length) { HideOverlayAndSave(); return; }

            ShowOverlay(e.RowIndex, e.ColumnIndex);
        }

        // ---- オーバーレイ表示 ----

        private void ShowOverlay(int row, int col)
        {
            _editRow = row;
            _editCol = col;
            int offset = row * BYTES_PER_ROW + (col - 1);

            Rectangle rect = dataGridView.GetCellDisplayRectangle(col, row, false);

            // SetByteValue が TextChanged を発火させないよう抑制
            _suppressEvents  = true;
            _overlay.Location = new Point(rect.Left + 1, rect.Top + 1);
            _overlay.Size     = new Size(BYTE_CELL_WIDTH - 2, BYTE_CELL_HEIGHT - 2);
            _overlay.SetByteValue(_data[offset]);
            _overlay.Visible  = true;
            _suppressEvents  = false;

            _overlay.Focus();
            _overlay.SelectAll();

            lblStatus.Text = string.Format(
                "編集中  Offset:0x{0:X4} ({0})  現在値:0x{1:X2}  [Enter/Tab]:確定・次へ  [Esc]:キャンセル",
                offset, _data[offset]);
        }

        // ---- オーバーレイイベント ----

        /// <summary>
        /// 2文字入力で自動的に次セルへ。
        /// TextChanged はまだ編集コントロール処理中なので
        /// BeginInvoke で次のメッセージループに遅延させて再入を防ぐ。
        /// </summary>
        private void Overlay_TextChanged(object sender, EventArgs e)
        {
            if (_suppressEvents) return;
            if (_overlay.Text.Length == 2 && _overlay.IsValidHex)
            {
                // 移動先を先に計算してからBeginInvokeで遅延実行
                int nextCol = _editCol + 1;
                int nextRow = _editRow;
                if (nextCol > BYTES_PER_ROW) { nextCol = 1; nextRow++; }

                BeginInvoke(new Action(() =>
                {
                    if (_suppressEvents) return;
                    SaveCurrentByte();
                    if (nextRow < dataGridView.Rows.Count)
                    {
                        int nextOffset = nextRow * BYTES_PER_ROW + (nextCol - 1);
                        if (nextOffset < _data.Length)
                            ShowOverlay(nextRow, nextCol);
                    }
                }));
            }
        }

        private void Overlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                int nextCol = _editCol + 1;
                int nextRow = _editRow;
                if (nextCol > BYTES_PER_ROW) { nextCol = 1; nextRow++; }

                BeginInvoke(new Action(() =>
                {
                    if (_suppressEvents) return;
                    SaveCurrentByte();
                    if (nextRow < dataGridView.Rows.Count)
                    {
                        int nextOffset = nextRow * BYTES_PER_ROW + (nextCol - 1);
                        if (nextOffset < _data.Length)
                            ShowOverlay(nextRow, nextCol);
                    }
                }));
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HideOverlay();
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void Overlay_LostFocus(object sender, EventArgs e)
        {
            if (_suppressEvents) return;
            if (_overlay.Visible)
                BeginInvoke(new Action(() =>
                {
                    if (_overlay.Visible && !_suppressEvents) SaveCurrentByte();
                }));
        }

        // ---- 保存・非表示 ----

        private void SaveCurrentByte()
        {
            if (_editRow < 0 || !_overlay.Visible) return;

            int offset = _editRow * BYTES_PER_ROW + (_editCol - 1);
            if (offset < _data.Length && _overlay.IsValidHex)
            {
                byte? v = _overlay.GetByteValue();
                if (v.HasValue)
                {
                    _data[offset] = v.Value;
                    dataGridView.Rows[_editRow].Cells[_editCol].Value = v.Value.ToString("X2");
                    UpdateAsciiCell(_editRow);
                    RefreshCellColor(_editRow, _editCol, v.Value);
                    lblStatus.Text = string.Format(
                        "更新完了  Offset:0x{0:X4} ({0})  新値:0x{1:X2}", offset, v.Value);
                }
            }
            HideOverlay();
        }

        private void HideOverlay()
        {
            _suppressEvents  = true;
            _overlay.Visible = false;
            _suppressEvents  = false;
            _editRow = -1;
            _editCol = -1;
        }

        private void HideOverlayAndSave()
        {
            if (_overlay.Visible) SaveCurrentByte();
            else HideOverlay();
        }

        // ---- セル更新 ----

        private void UpdateAsciiCell(int rowIdx)
        {
            int baseOfs = rowIdx * BYTES_PER_ROW;
            var sb = new StringBuilder();
            for (int c = 0; c < BYTES_PER_ROW; c++)
            {
                int idx = baseOfs + c;
                if (idx < _data.Length) { char ch = (char)_data[idx]; sb.Append(ch >= 0x20 && ch < 0x7F ? ch : '.'); }
                else sb.Append(' ');
            }
            dataGridView.Rows[rowIdx].Cells[BYTES_PER_ROW + 1].Value = sb.ToString();
        }

        private void RefreshCellColor(int rowIdx, int colIdx, byte val)
        {
            var cell = dataGridView.Rows[rowIdx].Cells[colIdx];
            if (val == 0x00)      { cell.Style.ForeColor = Color.LightGray;  cell.Style.BackColor = Color.White; }
            else if (val == 0xFF) { cell.Style.ForeColor = Color.OrangeRed;  cell.Style.BackColor = Color.FromArgb(255, 242, 240); }
            else                  { cell.Style.ForeColor = Color.FromArgb(0, 80, 160); cell.Style.BackColor = Color.White; }
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideOverlayAndSave();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try { _data = File.ReadAllBytes(dlg.FileName); RefreshGrid(); lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)", Path.GetFileName(dlg.FileName), _data.Length); }
                catch (Exception ex) { MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideOverlayAndSave();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try { File.WriteAllBytes(dlg.FileName, _data); lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName); }
                catch (Exception ex) { MessageBox.Show("保存失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }
    }
}
