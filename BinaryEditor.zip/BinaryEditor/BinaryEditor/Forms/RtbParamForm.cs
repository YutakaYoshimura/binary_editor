using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面② RichTextBox ― パラメータ毎表示・編集
    /// ・各パラメータをテキスト形式で一覧表示
    /// ・HEX列クリック時、テキスト上にHexEditControlを重ねて編集
    /// </summary>
    public partial class RtbParamForm : Form
    {
        // ---- フィールド ----
        private byte[]                   _data;
        private List<BinaryParameter>    _params;

        // 各パラメータ行の開始文字インデックス（クリック判定用）
        private List<int>   _rowCharStart = new List<int>();
        // 各パラメータ行の「HEX値」列の文字インデックス
        private List<int>   _hexCharStart = new List<int>();
        // HEX値1文字幅（固定幅フォント）
        private int _charW = 11;
        private int _lineH = 18;

        // オーバーレイ（最大4バイト分 = 最大4つ並べる）
        private HexEditControl[] _overlays;
        private int _editParamIdx = -1;

        private const int HEX_BYTES_PER_OVERLAY = 1; // 1バイトずつ

        // ---- 初期化 ----

        public RtbParamForm()
        {
            InitializeComponent();
            _params = BinaryParameter.GetSampleParameters();
            _data   = BinaryParameter.GetSampleData();

            MeasureFont();
            InitOverlays();
            RefreshDisplay();
        }

        private void MeasureFont()
        {
            using (var g = richTextBox.CreateGraphics())
            {
                var sz = g.MeasureString("W", richTextBox.Font);
                _charW = (int)Math.Ceiling(sz.Width);
                _lineH = (int)Math.Ceiling(sz.Height) + 2;
            }
        }

        private void InitOverlays()
        {
            // 最大4バイト対応オーバーレイ
            _overlays = new HexEditControl[4];
            for (int i = 0; i < _overlays.Length; i++)
            {
                _overlays[i] = new HexEditControl();
                _overlays[i].Visible  = false;
                _overlays[i].Size     = new Size(_charW * 2 + 6, _lineH + 2);
                int idx = i;
                _overlays[i].KeyDown   += (s, e) => Overlay_KeyDown(s, e, idx);
                _overlays[i].LostFocus += Overlay_LostFocus;
                richTextBox.Controls.Add(_overlays[i]);
            }
        }

        // ---- 表示 ----

        private void RefreshDisplay()
        {
            _rowCharStart.Clear();
            _hexCharStart.Clear();

            richTextBox.SuspendLayout();
            richTextBox.Clear();

            var sb = new StringBuilder();

            // ヘッダ
            sb.AppendFormat("{0,-14}{1,-20}{2,-20}{3,-10}{4,-6}{5}\r\n",
                "パラメータ名", "説明", "HEX値", "解析値", "単位", "Offset");
            sb.Append(new string('─', 82) + "\r\n");

            foreach (var p in _params)
            {
                // 各行の文字インデックスを記録（ヘッダ2行後）
                // この値はrtbへAppend後に計算する
                _rowCharStart.Add(sb.Length);

                // HEX値文字列
                string hexStr = BuildHexStr(p);
                // 解析値
                string parsed = ParseValue(p);

                string line = string.Format("{0,-14}{1,-20}{2,-20}{3,-12}{4,-6}0x{5:X4}\r\n",
                    p.Name, p.Description, hexStr, parsed, p.Unit, p.Offset);

                // HEX列の文字位置 = 行先頭 + 14 + 20
                _hexCharStart.Add(sb.Length + 14 + 20);

                sb.Append(line);
            }

            richTextBox.Text = sb.ToString();
            ApplyParamColoring();
            richTextBox.ResumeLayout();
        }

        private string BuildHexStr(BinaryParameter p)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < p.Length; i++)
            {
                int idx = p.Offset + i;
                if (idx < _data.Length)
                    sb.AppendFormat("{0:X2} ", _data[idx]);
            }
            return sb.ToString().TrimEnd();
        }

        private string ParseValue(BinaryParameter p)
        {
            try
            {
                switch (p.Format)
                {
                    case "UINT8":
                        if (p.Offset < _data.Length)
                            return _data[p.Offset].ToString();
                        break;
                    case "UINT16BE":
                        if (p.Offset + 1 < _data.Length)
                            return ((_data[p.Offset] << 8) | _data[p.Offset + 1]).ToString();
                        break;
                    case "UINT16LE":
                        if (p.Offset + 1 < _data.Length)
                            return (_data[p.Offset] | (_data[p.Offset + 1] << 8)).ToString();
                        break;
                    case "ASCII":
                        int len = Math.Min(p.Length, _data.Length - p.Offset);
                        if (len > 0)
                            return "\"" + Encoding.ASCII.GetString(_data, p.Offset, len).TrimEnd('\0') + "\"";
                        break;
                    case "HEX":
                    default:
                        return "-";
                }
            }
            catch { }
            return "-";
        }

        private void ApplyParamColoring()
        {
            // ヘッダ行 → ダークグレー
            string text = richTextBox.Text;
            int hdrEnd = text.IndexOf("─\r\n") + 4;
            if (hdrEnd > 3)
            {
                richTextBox.Select(0, hdrEnd);
                richTextBox.SelectionColor = Color.DarkGray;
                richTextBox.SelectionFont  = new Font("Courier New", 9f, FontStyle.Bold);
            }

            // 偶数行に薄い背景色（SelectionBackColorで対応）
            // HEX列を強調
            for (int i = 0; i < _params.Count; i++)
            {
                int hexStart = _hexCharStart[i];
                int hexLen   = _params[i].Length * 3 - 1;
                if (hexStart + hexLen <= text.Length)
                {
                    richTextBox.Select(hexStart, hexLen);
                    richTextBox.SelectionColor = Color.FromArgb(0, 150, 220);
                }
            }

            richTextBox.SelectionStart  = 0;
            richTextBox.SelectionLength = 0;
        }

        // ---- クリック → オーバーレイ表示 ----

        private void richTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (_data == null) return;

            int charIdx = richTextBox.GetCharIndexFromPosition(e.Location);
            int lineNo  = richTextBox.GetLineFromCharIndex(charIdx);

            // ヘッダ2行スキップ
            if (lineNo < 2) return;

            int paramIdx = lineNo - 2;
            if (paramIdx >= _params.Count) return;

            ShowOverlays(paramIdx, lineNo);
        }

        private void ShowOverlays(int paramIdx, int lineNo)
        {
            HideAllOverlays();
            _editParamIdx = paramIdx;

            var p = _params[paramIdx];
            int lineStart = richTextBox.GetFirstCharIndexFromLine(lineNo);
            // HEX列先頭文字インデックス
            int hexStart  = lineStart + 14 + 20;

            for (int b = 0; b < p.Length && b < _overlays.Length; b++)
            {
                int byteCharIdx = hexStart + b * 3; // "XX "  3文字ずつ
                if (byteCharIdx >= richTextBox.Text.Length) break;

                Point pos = richTextBox.GetPositionFromCharIndex(byteCharIdx);
                _overlays[b].Location = new Point(pos.X, pos.Y - 1);
                _overlays[b].Size     = new Size(_charW * 2 + 6, _lineH + 2);

                int dataIdx = p.Offset + b;
                _overlays[b].SetByteValue(dataIdx < _data.Length ? _data[dataIdx] : (byte)0);
                _overlays[b].Visible = true;
            }

            _overlays[0].Focus();
            _overlays[0].SelectAll();

            var param = _params[paramIdx];
            lblStatus.Text = string.Format(
                "編集中  [{0}] {1}  Offset:0x{2:X4}  Length:{3}byte  [Enter/Tab]:確定  [Esc]:キャンセル",
                param.Name, param.Description, param.Offset, param.Length);
        }

        private void CommitOverlays()
        {
            if (_editParamIdx < 0) return;

            var p = _params[_editParamIdx];
            bool valid = true;

            for (int b = 0; b < p.Length && b < _overlays.Length; b++)
            {
                if (!_overlays[b].Visible) continue;
                if (!_overlays[b].IsValidHex) { valid = false; break; }
            }

            if (!valid)
            {
                lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
                HideAllOverlays();
                _editParamIdx = -1;
                return;
            }

            for (int b = 0; b < p.Length && b < _overlays.Length; b++)
            {
                if (!_overlays[b].Visible) continue;
                byte? v = _overlays[b].GetByteValue();
                if (v.HasValue)
                {
                    int dataIdx = p.Offset + b;
                    if (dataIdx < _data.Length)
                        _data[dataIdx] = v.Value;
                }
            }

            lblStatus.Text = string.Format("更新完了  [{0}] {1}", p.Name, BuildHexStr(p));
            HideAllOverlays();
            _editParamIdx = -1;
            RefreshDisplay();
        }

        private void HideAllOverlays()
        {
            foreach (var ov in _overlays)
                ov.Visible = false;
        }

        private void Overlay_KeyDown(object sender, KeyEventArgs e, int overlayIdx)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                // 次のバイトへフォーカス移動、最後なら確定
                if (_editParamIdx >= 0)
                {
                    int len = _params[_editParamIdx].Length;
                    int nextIdx = overlayIdx + 1;
                    if (nextIdx < len && nextIdx < _overlays.Length && _overlays[nextIdx].Visible)
                    {
                        _overlays[nextIdx].Focus();
                        _overlays[nextIdx].SelectAll();
                    }
                    else
                    {
                        CommitOverlays();
                    }
                }
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HideAllOverlays();
                _editParamIdx = -1;
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void Overlay_LostFocus(object sender, EventArgs e)
        {
            // いずれかのオーバーレイにフォーカスが移った場合は確定しない
            foreach (var ov in _overlays)
                if (ov.Focused) return;

            if (_editParamIdx >= 0)
                CommitOverlays();
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideAllOverlays();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshDisplay();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)",
                        Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideAllOverlays();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("保存失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
