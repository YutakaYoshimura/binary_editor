using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面① RichTextBox ― バイナリ全体表示・編集
    /// ・HEXダンプ形式（スペース区切り "AA BB CC ..."）で全データ表示
    /// ・バイトをクリックすると HexEditControl がテキスト上に重なって表示され
    ///   そのまま値を修正できる
    /// </summary>
    public partial class RtbWholeForm : Form
    {
        // ---- フィールド ----
        private byte[]         _data;
        private const int      BYTES_PER_ROW = 16;

        // オーバーレイ
        private HexEditControl _overlay;
        private int            _editOffset = -1;

        // 1文字の幅（Courier New 固定幅）
        private int _charWidth  = 12;
        private int _lineHeight = 18;

        // ---- 初期化 ----

        public RtbWholeForm()
        {
            InitializeComponent();
            MeasureFont();
            InitOverlay();
            _data = BinaryParameter.GetSampleData();
            RefreshDump();
        }

        private void MeasureFont()
        {
            using (var g = richTextBox.CreateGraphics())
            {
                var sz = g.MeasureString("W", richTextBox.Font);
                _charWidth  = (int)Math.Ceiling(sz.Width);
                _lineHeight = (int)Math.Ceiling(sz.Height) + 2;
            }
        }

        private void InitOverlay()
        {
            _overlay = new HexEditControl();
            _overlay.Visible = false;
            _overlay.Size    = new Size(_charWidth * 2 + 4, _lineHeight + 2);
            _overlay.KeyDown    += Overlay_KeyDown;
            _overlay.LostFocus  += Overlay_LostFocus;
            richTextBox.Controls.Add(_overlay);
        }

        // ---- 表示 ----

        private void RefreshDump()
        {
            richTextBox.SuspendLayout();
            richTextBox.Clear();

            var sb = new StringBuilder();

            // ヘッダ
            sb.Append("Offset    ");
            for (int i = 0; i < BYTES_PER_ROW; i++)
                sb.AppendFormat("{0:X2} ", i);
            sb.Append("  ASCII\r\n");
            sb.Append(new string('─', 72) + "\r\n");

            // データ行
            for (int row = 0; row * BYTES_PER_ROW < _data.Length; row++)
            {
                int baseOfs = row * BYTES_PER_ROW;
                sb.AppendFormat("{0:X8}  ", baseOfs);

                var ascii = new StringBuilder();
                for (int col = 0; col < BYTES_PER_ROW; col++)
                {
                    int idx = baseOfs + col;
                    if (idx < _data.Length)
                    {
                        sb.AppendFormat("{0:X2} ", _data[idx]);
                        char c = (char)_data[idx];
                        ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                    }
                    else
                    {
                        sb.Append("   ");
                        ascii.Append(' ');
                    }
                }
                sb.Append(" ");
                sb.Append(ascii);
                sb.Append("\r\n");
            }

            richTextBox.Text = sb.ToString();
            ApplyColoring();
            richTextBox.ResumeLayout();
        }

        private void ApplyColoring()
        {
            // ヘッダ2行 → グレー
            int headerEnd = richTextBox.Text.IndexOf("─\r\n") + 4;
            if (headerEnd > 3)
            {
                richTextBox.Select(0, headerEnd);
                richTextBox.SelectionColor = Color.DarkGray;
            }

            // ゼロバイト → グレー  / FFバイト → 赤
            string text = richTextBox.Text;
            for (int i = headerEnd; i < text.Length - 2; i++)
            {
                if (i + 2 < text.Length && text[i + 2] == ' ')
                {
                    string tok = text.Substring(i, 2);
                    if (tok == "00")
                    {
                        richTextBox.Select(i, 2);
                        richTextBox.SelectionColor = Color.Gray;
                    }
                    else if (tok == "FF")
                    {
                        richTextBox.Select(i, 2);
                        richTextBox.SelectionColor = Color.OrangeRed;
                    }
                }
            }

            richTextBox.SelectionStart  = 0;
            richTextBox.SelectionLength = 0;
        }

        // ---- クリック → オーバーレイ表示 ----

        private void richTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (_data == null) return;

            int charIdx  = richTextBox.GetCharIndexFromPosition(e.Location);
            int lineNo   = richTextBox.GetLineFromCharIndex(charIdx);
            int lineStart= richTextBox.GetFirstCharIndexFromLine(lineNo);
            int col      = charIdx - lineStart;

            // ヘッダ2行スキップ
            if (lineNo < 2) return;

            int dataRow = lineNo - 2;
            // "XXXXXXXX  " = 10文字、各バイトは "XX " = 3文字
            const int COL_OFFSET = 10;
            int relCol = col - COL_OFFSET;
            if (relCol < 0) return;

            int byteCol = relCol / 3;
            if (byteCol >= BYTES_PER_ROW) return;

            int offset = dataRow * BYTES_PER_ROW + byteCol;
            if (offset >= _data.Length) return;

            ShowOverlay(offset, lineNo, byteCol);
        }

        private void ShowOverlay(int offset, int lineNo, int byteCol)
        {
            _editOffset = offset;

            int lineStart = richTextBox.GetFirstCharIndexFromLine(lineNo);
            int byteCharIdx = lineStart + 10 + byteCol * 3;
            Point pos = richTextBox.GetPositionFromCharIndex(byteCharIdx);

            _overlay.Location = new Point(pos.X, pos.Y - 1);
            _overlay.Size     = new Size(_charWidth * 2 + 6, _lineHeight + 2);
            _overlay.SetByteValue(_data[offset]);
            _overlay.Visible = true;
            _overlay.Focus();
            _overlay.SelectAll();

            lblStatus.Text = string.Format(
                "編集中  Offset: 0x{0:X4} ({0})　現在値: 0x{1:X2}　[Enter/Tab]:確定  [Esc]:キャンセル",
                offset, _data[offset]);
        }

        private void CommitOverlay()
        {
            if (_editOffset < 0 || !_overlay.Visible) return;

            if (_overlay.IsValidHex)
            {
                byte? v = _overlay.GetByteValue();
                if (v.HasValue)
                {
                    _data[_editOffset] = v.Value;
                    lblStatus.Text = string.Format(
                        "更新完了  Offset: 0x{0:X4} ({0})　新値: 0x{1:X2}", _editOffset, v.Value);
                }
            }
            else
            {
                lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
            }

            _overlay.Visible = false;
            _editOffset = -1;
            RefreshDump();
        }

        private void CancelOverlay()
        {
            _overlay.Visible = false;
            _editOffset = -1;
            lblStatus.Text = "編集キャンセル";
        }

        private void Overlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                CommitOverlay();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                CancelOverlay();
                e.Handled = true;
            }
        }

        private void Overlay_LostFocus(object sender, EventArgs e)
        {
            if (_overlay.Visible) CommitOverlay();
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            CancelOverlay();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshDump();
                    lblStatus.Text = string.Format("読込完了: {0}  ({1} bytes)",
                        Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            CancelOverlay();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("保存失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
