using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面② RichTextBox ― パラメータ毎表示・編集
    /// 表示: DataGridView
    /// 編集: RichTextBox をセル上に重ねて使用
    /// </summary>
    public partial class Form2_DgvRtbParamForm : Form
    {
        private byte[]                _data;
        private List<BinaryParameter> _params;

        // オーバーレイ用RichTextBox（編集時にセル上に重ねる）
        private RichTextBox _rtbOverlay;
        private int         _editRow = -1;

        // 列インデックス
        private const int COL_NAME   = 0;
        private const int COL_DESC   = 1;
        private const int COL_HEX    = 2;
        private const int COL_PARSED = 3;
        private const int COL_UNIT   = 4;
        private const int COL_OFFSET = 5;
        private const int COL_LEN    = 6;
        private const int COL_FMT    = 7;

        public Form2_DgvRtbParamForm()
        {
            InitializeComponent();
            _params = BinaryParameter.GetSampleParameters();
            _data   = BinaryParameter.GetSampleData();
            SetupGrid();
            InitRtbOverlay();
            RefreshGrid();
        }

        // ---- グリッド定義 ----

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            dataGridView.Columns.Add(MakeCol("colName",   "パラメータ名", 110, Color.FromArgb(232,234,248), Color.FromArgb(30,40,120),  true));
            dataGridView.Columns.Add(MakeCol("colDesc",   "説明",         185, Color.White,                Color.FromArgb(40,40,80),    false));
            dataGridView.Columns.Add(MakeCol("colHex",    "HEX値",         130, Color.FromArgb(255,252,220),Color.FromArgb(0,100,180),   false));
            dataGridView.Columns.Add(MakeCol("colParsed", "解析値",         90, Color.White,                Color.FromArgb(0,120,60),    false));
            dataGridView.Columns.Add(MakeCol("colUnit",   "単位",           55, Color.White,                Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colOffset", "Offset",         70, Color.FromArgb(242,242,250),Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colLen",    "Len",            38, Color.FromArgb(242,242,250),Color.DimGray,               false));
            dataGridView.Columns.Add(MakeCol("colFmt",    "形式",           70, Color.FromArgb(242,242,250),Color.DimGray,               false));

            var hdr = dataGridView.ColumnHeadersDefaultCellStyle;
            hdr.Font      = new Font("Meiryo UI", 9f, FontStyle.Bold);
            hdr.BackColor = Color.FromArgb(45, 75, 145);
            hdr.ForeColor = Color.White;
            hdr.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersHeight       = 26;
            dataGridView.RowHeadersWidth           = 4;
            dataGridView.AllowUserToAddRows        = false;
            dataGridView.AllowUserToDeleteRows     = false;
            dataGridView.AllowUserToResizeRows     = false;
            dataGridView.MultiSelect               = false;
            dataGridView.SelectionMode             = DataGridViewSelectionMode.FullRowSelect;
            dataGridView.GridColor                 = Color.FromArgb(200, 210, 230);
            dataGridView.BackgroundColor           = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 215, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick  += Grid_CellClick;
            dataGridView.Scroll     += (s, e) => HideOverlay();
            dataGridView.ResumeLayout();
        }

        private DataGridViewTextBoxColumn MakeCol(string name, string header,
            int width, Color back, Color fore, bool bold)
        {
            return new DataGridViewTextBoxColumn
            {
                Name      = name,
                HeaderText = header,
                Width     = width,
                ReadOnly  = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font      = new Font("Courier New", 9f, bold ? FontStyle.Bold : FontStyle.Regular),
                    BackColor = back,
                    ForeColor = fore,
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            };
        }

        // ---- RichTextBoxオーバーレイ初期化 ----

        private void InitRtbOverlay()
        {
            _rtbOverlay = new RichTextBox();
            _rtbOverlay.Visible    = false;
            _rtbOverlay.Font       = new Font("Courier New", 9.5f, FontStyle.Bold);
            _rtbOverlay.BackColor  = Color.FromArgb(255, 252, 180);   // 薄い黄色で編集中を強調
            _rtbOverlay.ForeColor  = Color.DarkRed;
            _rtbOverlay.BorderStyle = BorderStyle.FixedSingle;
            _rtbOverlay.ScrollBars = RichTextBoxScrollBars.None;
            _rtbOverlay.WordWrap   = false;
            _rtbOverlay.Multiline  = false;
            _rtbOverlay.KeyDown   += RtbOverlay_KeyDown;
            _rtbOverlay.KeyPress  += RtbOverlay_KeyPress;
            _rtbOverlay.LostFocus += RtbOverlay_LostFocus;
            dataGridView.Controls.Add(_rtbOverlay);
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            foreach (var p in _params)
            {
                int ri = dataGridView.Rows.Add(
                    p.Name,
                    p.Description,
                    p.BuildHexStr(_data),
                    p.ParseValue(_data),
                    p.Unit,
                    string.Format("0x{0:X4}", p.Offset),
                    p.Length.ToString(),
                    p.Format
                );
                dataGridView.Rows[ri].Height = 22;

                if (p.Name.StartsWith("Reserved"))
                    for (int c = 0; c < dataGridView.Columns.Count; c++)
                        dataGridView.Rows[ri].Cells[c].Style.ForeColor = Color.LightGray;
            }

            dataGridView.ResumeLayout();
        }

        // ---- セルクリック → RichTextBoxオーバーレイ表示 ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) { HideOverlay(); return; }
            // HEX値列のみ編集
            if (e.ColumnIndex != COL_HEX) { HideOverlay(); return; }
            ShowOverlay(e.RowIndex);
        }

        private void ShowOverlay(int rowIdx)
        {
            HideOverlay();
            _editRow = rowIdx;

            var p = _params[rowIdx];

            // HEXセルの矩形を取得してRichTextBoxを重ねる
            Rectangle rect = dataGridView.GetCellDisplayRectangle(COL_HEX, rowIdx, false);

            _rtbOverlay.Location = new Point(rect.Left + 1, rect.Top + 1);
            _rtbOverlay.Size     = new Size(rect.Width - 2, rect.Height - 2);
            _rtbOverlay.Text     = p.BuildHexStr(_data);
            _rtbOverlay.Visible  = true;
            _rtbOverlay.Focus();
            _rtbOverlay.SelectAll();

            lblStatus.Text = string.Format(
                "編集中(RichTextBox)  [{0}] {1}  Offset:0x{2:X4}  Length:{3}byte  形式:{4}  [Enter]:確定  [Esc]:キャンセル",
                p.Name, p.Description, p.Offset, p.Length, p.Format);
        }

        private void CommitOverlay()
        {
            if (_editRow < 0 || !_rtbOverlay.Visible) return;

            var p = _params[_editRow];
            string input = _rtbOverlay.Text.Replace(" ", "").Trim();

            // バイト数チェック
            if (input.Length != p.Length * 2)
            {
                lblStatus.Text = string.Format(
                    "入力エラー: {0}バイト分の16進数を入力してください ({1}文字)", p.Length, p.Length * 2);
                return;
            }

            // 全文字HEXチェック＆データ更新
            bool valid = true;
            var newBytes = new byte[p.Length];
            for (int b = 0; b < p.Length; b++)
            {
                string hex = input.Substring(b * 2, 2);
                try { newBytes[b] = Convert.ToByte(hex, 16); }
                catch { valid = false; break; }
            }

            if (!valid)
            {
                lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
                return;
            }

            for (int b = 0; b < p.Length; b++)
            {
                int idx = p.Offset + b;
                if (idx < _data.Length)
                    _data[idx] = newBytes[b];
            }

            dataGridView.Rows[_editRow].Cells[COL_HEX].Value    = p.BuildHexStr(_data);
            dataGridView.Rows[_editRow].Cells[COL_PARSED].Value  = p.ParseValue(_data);
            lblStatus.Text = string.Format("更新完了  [{0}]  {1}", p.Name, p.BuildHexStr(_data));

            HideOverlay();
        }

        private void HideOverlay()
        {
            _rtbOverlay.Visible = false;
            _editRow = -1;
        }

        private void RtbOverlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            { CommitOverlay(); e.Handled = true; }
            else if (e.KeyCode == Keys.Escape)
            { HideOverlay(); lblStatus.Text = "編集キャンセル"; e.Handled = true; }
            else if (e.KeyCode == Keys.Tab)
            {
                CommitOverlay();
                // 次の行へ
                int next = _editRow >= 0 ? _editRow + 1 : -1;
                if (next >= 0 && next < _params.Count)
                    ShowOverlay(next);
                e.Handled = true;
            }
        }

        private void RtbOverlay_KeyPress(object sender, KeyPressEventArgs e)
        {
            // HEX文字・スペース・BackSpace・Ctrl系のみ許可
            if (char.IsControl(e.KeyChar)) return;
            if (e.KeyChar == ' ') return;
            char c = char.ToUpper(e.KeyChar);
            if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F')))
            {
                e.Handled = true;
                System.Media.SystemSounds.Beep.Play();
            }
        }

        private void RtbOverlay_LostFocus(object sender, EventArgs e)
        {
            if (_rtbOverlay.Visible) CommitOverlay();
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshGrid();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)", Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                { MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                { MessageBox.Show("保存失敗\n" + ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }
    }
}
