using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面③ DataGridView ― バイナリ全体表示・編集
    /// ・1行16バイトのグリッドで全データを表示
    /// ・バイトセルをクリックすると HexEditControl がセル上に重なって表示され
    ///   そのまま値を修正できる
    /// </summary>
    public partial class GridWholeForm : Form
    {
        private byte[]         _data;
        private const int      BYTES_PER_ROW = 16;

        private HexEditControl _overlay;
        private int            _editRow    = -1;
        private int            _editCol    = -1;  // 1-based (col0=Offset, col1〜16=data, col17=ASCII)

        public GridWholeForm()
        {
            InitializeComponent();
            SetupGrid();
            InitOverlay();
            _data = BinaryParameter.GetSampleData();
            RefreshGrid();
        }

        // ---- グリッド定義 ----

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            // Offset列
            dataGridView.Columns.Add(MakeCol("colOfs", "Offset", 78, true,
                Color.FromArgb(228, 232, 245), Color.DimGray, FontStyle.Bold));

            // バイト列 × 16
            for (int i = 0; i < BYTES_PER_ROW; i++)
                dataGridView.Columns.Add(MakeCol("col" + i, i.ToString("X"), 34, true,
                    Color.White, Color.FromArgb(0, 80, 160), FontStyle.Regular));

            // ASCII列
            dataGridView.Columns.Add(MakeCol("colAscii", "ASCII", 140, true,
                Color.FromArgb(240, 255, 240), Color.DarkGreen, FontStyle.Regular));

            StyleGrid();
            dataGridView.CellClick += Grid_CellClick;
            dataGridView.Scroll    += (s, e) => HideOverlay();
            dataGridView.ResumeLayout();
        }

        private DataGridViewTextBoxColumn MakeCol(string name, string header,
            int width, bool readOnly, Color back, Color fore, FontStyle fs)
        {
            return new DataGridViewTextBoxColumn
            {
                Name    = name,
                HeaderText = header,
                Width   = width,
                ReadOnly = readOnly,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font       = new Font("Courier New", 9f, fs),
                    BackColor  = back,
                    ForeColor  = fore,
                    Alignment  = DataGridViewContentAlignment.MiddleCenter
                }
            };
        }

        private void StyleGrid()
        {
            var hdrStyle = dataGridView.ColumnHeadersDefaultCellStyle;
            hdrStyle.Font      = new Font("Courier New", 9f, FontStyle.Bold);
            hdrStyle.BackColor = Color.FromArgb(45, 75, 145);
            hdrStyle.ForeColor = Color.White;
            hdrStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersHeight       = 26;
            dataGridView.RowHeadersWidth           = 4;
            dataGridView.AllowUserToAddRows        = false;
            dataGridView.AllowUserToDeleteRows     = false;
            dataGridView.AllowUserToResizeRows     = false;
            dataGridView.MultiSelect               = false;
            dataGridView.SelectionMode             = DataGridViewSelectionMode.CellSelect;
            dataGridView.GridColor                 = Color.FromArgb(200, 210, 230);
            dataGridView.BackgroundColor           = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 210, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
        }

        private void InitOverlay()
        {
            _overlay = new HexEditControl();
            _overlay.Visible    = false;
            _overlay.KeyDown   += Overlay_KeyDown;
            _overlay.LostFocus += Overlay_LostFocus;
            dataGridView.Controls.Add(_overlay);
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            for (int row = 0; row * BYTES_PER_ROW < _data.Length; row++)
            {
                int baseOfs = row * BYTES_PER_ROW;
                var vals = new object[BYTES_PER_ROW + 2];
                vals[0] = baseOfs.ToString("X8");

                var ascii = new StringBuilder();
                for (int col = 0; col < BYTES_PER_ROW; col++)
                {
                    int idx = baseOfs + col;
                    if (idx < _data.Length)
                    {
                        vals[col + 1] = _data[idx].ToString("X2");
                        char c = (char)_data[idx];
                        ascii.Append(c >= 0x20 && c < 0x7F ? c : '.');
                    }
                    else
                    {
                        vals[col + 1] = "";
                        ascii.Append(' ');
                    }
                }
                vals[BYTES_PER_ROW + 1] = ascii.ToString();

                int ri = dataGridView.Rows.Add(vals);
                dataGridView.Rows[ri].Height = 22;
            }

            ColorizeGridCells();
            dataGridView.ResumeLayout();
        }

        private void ColorizeGridCells()
        {
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                for (int c = 1; c <= BYTES_PER_ROW; c++)
                {
                    var cell = row.Cells[c];
                    string v = cell.Value?.ToString() ?? "";
                    if (v == "00")
                    {
                        cell.Style.ForeColor = Color.LightGray;
                    }
                    else if (v == "FF")
                    {
                        cell.Style.ForeColor  = Color.OrangeRed;
                        cell.Style.BackColor  = Color.FromArgb(255, 242, 240);
                    }
                }
            }
        }

        // ---- セルクリック → オーバーレイ ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 1 || e.ColumnIndex > BYTES_PER_ROW)
            {
                HideOverlay();
                return;
            }
            int offset = e.RowIndex * BYTES_PER_ROW + (e.ColumnIndex - 1);
            if (offset >= _data.Length) { HideOverlay(); return; }

            _editRow = e.RowIndex;
            _editCol = e.ColumnIndex;

            Rectangle rect = dataGridView.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
            _overlay.Location = new Point(rect.Left + 1, rect.Top + 1);
            _overlay.Size     = new Size(rect.Width - 2, rect.Height - 2);
            _overlay.SetByteValue(_data[offset]);
            _overlay.Visible = true;
            _overlay.Focus();
            _overlay.SelectAll();

            lblStatus.Text = string.Format(
                "編集中  Offset:0x{0:X4} ({0})  現在値:0x{1:X2}  [Enter/Tab]:確定・次へ  [Esc]:キャンセル",
                offset, _data[offset]);
        }

        private void CommitOverlay()
        {
            if (_editRow < 0 || !_overlay.Visible) return;
            int offset = _editRow * BYTES_PER_ROW + (_editCol - 1);
            if (offset >= _data.Length) { HideOverlay(); return; }

            if (_overlay.IsValidHex)
            {
                byte? v = _overlay.GetByteValue();
                if (v.HasValue)
                {
                    _data[offset] = v.Value;
                    dataGridView.Rows[_editRow].Cells[_editCol].Value = v.Value.ToString("X2");
                    UpdateAsciiCell(_editRow);
                    RefreshCellColor(_editRow, _editCol, v.Value);
                    lblStatus.Text = string.Format(
                        "更新完了  Offset:0x{0:X4} ({0})  新値:0x{1:X2}", offset, v.Value);
                }
            }
            else
            {
                lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
            }
            HideOverlay();
        }

        private void HideOverlay()
        {
            _overlay.Visible = false;
            _editRow = -1;
            _editCol = -1;
        }

        private void UpdateAsciiCell(int rowIdx)
        {
            int baseOfs = rowIdx * BYTES_PER_ROW;
            var sb = new StringBuilder();
            for (int c = 0; c < BYTES_PER_ROW; c++)
            {
                int idx = baseOfs + c;
                if (idx < _data.Length)
                {
                    char ch = (char)_data[idx];
                    sb.Append(ch >= 0x20 && ch < 0x7F ? ch : '.');
                }
                else sb.Append(' ');
            }
            dataGridView.Rows[rowIdx].Cells[BYTES_PER_ROW + 1].Value = sb.ToString();
        }

        private void RefreshCellColor(int rowIdx, int colIdx, byte val)
        {
            var cell = dataGridView.Rows[rowIdx].Cells[colIdx];
            if (val == 0x00)
            {
                cell.Style.ForeColor = Color.LightGray;
                cell.Style.BackColor = Color.White;
            }
            else if (val == 0xFF)
            {
                cell.Style.ForeColor = Color.OrangeRed;
                cell.Style.BackColor = Color.FromArgb(255, 242, 240);
            }
            else
            {
                cell.Style.ForeColor = Color.FromArgb(0, 80, 160);
                cell.Style.BackColor = Color.White;
            }
        }

        private void Overlay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                CommitOverlay();
                MoveToNext();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HideOverlay();
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void Overlay_LostFocus(object sender, EventArgs e)
        {
            if (_overlay.Visible) CommitOverlay();
        }

        private void MoveToNext()
        {
            if (_editRow < 0) return;
            int nc = _editCol + 1;
            int nr = _editRow;
            if (nc > BYTES_PER_ROW) { nc = 1; nr++; }
            if (nr < dataGridView.Rows.Count)
                Grid_CellClick(this, new DataGridViewCellEventArgs(nc, nr));
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshGrid();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)",
                        Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideOverlay();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("保存失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
