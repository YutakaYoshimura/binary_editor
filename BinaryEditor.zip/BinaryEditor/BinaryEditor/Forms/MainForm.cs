using System;
using System.Windows.Forms;
using System.Drawing;

namespace BinaryEditor.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnRichText_Click(object sender, EventArgs e)
        {
            var form = new RichTextBinaryForm();
            form.Show();
        }

        private void btnGrid_Click(object sender, EventArgs e)
        {
            var form = new GridBinaryForm();
            form.Show();
        }
    }
}
