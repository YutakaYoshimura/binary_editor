using System;
using System.Windows.Forms;

namespace BinaryEditor.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnForm1_Click(object sender, EventArgs e)
        {
            new Form1_RtbWholeForm().Show();
        }

        private void btnForm2_Click(object sender, EventArgs e)
        {
            new Form2_DgvRtbParamForm().Show();
        }

        private void btnForm3_Click(object sender, EventArgs e)
        {
            new Form3_DgvWholeForm().Show();
        }

        private void btnForm4_Click(object sender, EventArgs e)
        {
            new Form4_DgvDgvParamForm().Show();
        }
    }
}
