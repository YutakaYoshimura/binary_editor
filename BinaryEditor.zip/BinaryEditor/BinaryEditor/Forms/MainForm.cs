using System;
using System.Windows.Forms;

namespace BinaryEditor.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnRtbWhole_Click(object sender, EventArgs e)
        {
            new RtbWholeForm().Show();
        }

        private void btnRtbParam_Click(object sender, EventArgs e)
        {
            new RtbParamForm().Show();
        }

        private void btnGridWhole_Click(object sender, EventArgs e)
        {
            new GridWholeForm().Show();
        }

        private void btnGridParam_Click(object sender, EventArgs e)
        {
            new GridParamForm().Show();
        }
    }
}
