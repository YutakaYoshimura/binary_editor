namespace BinaryEditor.Forms
{
    partial class RichTextBinaryForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnNew = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();

            // panelTop
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Height = 70;
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(240, 244, 255);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Controls.Add(this.btnNew);
            this.panelTop.Controls.Add(this.btnOpen);
            this.panelTop.Controls.Add(this.btnSave);

            // lblTitle
            this.lblTitle.AutoSize = false;
            this.lblTitle.Location = new System.Drawing.Point(8, 6);
            this.lblTitle.Size = new System.Drawing.Size(300, 22);
            this.lblTitle.Font = new System.Drawing.Font("Meiryo UI", 10f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Text = "RichTextBox バイナリエディタ";

            // btnNew
            this.btnNew.Location = new System.Drawing.Point(8, 34);
            this.btnNew.Size = new System.Drawing.Size(80, 26);
            this.btnNew.Text = "新規";
            this.btnNew.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);

            // btnOpen
            this.btnOpen.Location = new System.Drawing.Point(96, 34);
            this.btnOpen.Size = new System.Drawing.Size(80, 26);
            this.btnOpen.Text = "開く";
            this.btnOpen.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);

            // btnSave
            this.btnSave.Location = new System.Drawing.Point(184, 34);
            this.btnSave.Size = new System.Drawing.Size(80, 26);
            this.btnSave.Text = "保存";
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // richTextBox
            this.richTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox.Font = new System.Drawing.Font("Courier New", 9.5f);
            this.richTextBox.BackColor = System.Drawing.Color.FromArgb(18, 18, 30);
            this.richTextBox.ForeColor = System.Drawing.Color.LightGreen;
            this.richTextBox.ReadOnly = false;
            this.richTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Both;
            this.richTextBox.WordWrap = false;
            this.richTextBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.richTextBox_MouseClick);

            // lblStatus
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.Height = 24;
            this.lblStatus.BackColor = System.Drawing.Color.FromArgb(220, 230, 255);
            this.lblStatus.Font = new System.Drawing.Font("Meiryo UI", 8.5f);
            this.lblStatus.Text = "ヘックスダンプ上のバイトをクリックして編集できます";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);

            // RichTextBinaryForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblStatus);
            this.Font = new System.Drawing.Font("Meiryo UI", 9f);
            this.Name = "RichTextBinaryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "バイナリエディタ - RichTextBox";
            this.panelTop.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblTitle;
    }
}
