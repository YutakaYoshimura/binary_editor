namespace BinaryEditor.Forms
{
    partial class GridBinaryForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.lblStatus = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblHelp = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();

            // panelTop
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Height = 80;
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(235, 242, 255);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Controls.Add(this.btnNew);
            this.panelTop.Controls.Add(this.btnOpen);
            this.panelTop.Controls.Add(this.btnSave);
            this.panelTop.Controls.Add(this.lblHelp);

            // lblTitle
            this.lblTitle.AutoSize = false;
            this.lblTitle.Location = new System.Drawing.Point(8, 6);
            this.lblTitle.Size = new System.Drawing.Size(350, 22);
            this.lblTitle.Font = new System.Drawing.Font("Meiryo UI", 10f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Text = "DataGridView バイナリエディタ";

            // btnNew
            this.btnNew.Location = new System.Drawing.Point(8, 34);
            this.btnNew.Size = new System.Drawing.Size(80, 26);
            this.btnNew.Text = "新規";
            this.btnNew.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);

            // btnOpen
            this.btnOpen.Location = new System.Drawing.Point(96, 34);
            this.btnOpen.Size = new System.Drawing.Size(80, 26);
            this.btnOpen.Text = "開く";
            this.btnOpen.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);

            // btnSave
            this.btnSave.Location = new System.Drawing.Point(184, 34);
            this.btnSave.Size = new System.Drawing.Size(80, 26);
            this.btnSave.Text = "保存";
            this.btnSave.BackColor = System.Drawing.Color.LightGreen;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // lblHelp
            this.lblHelp.AutoSize = false;
            this.lblHelp.Location = new System.Drawing.Point(8, 62);
            this.lblHelp.Size = new System.Drawing.Size(700, 16);
            this.lblHelp.Font = new System.Drawing.Font("Meiryo UI", 8f);
            this.lblHelp.ForeColor = System.Drawing.Color.DimGray;
            this.lblHelp.Text = "操作: バイトセルをクリック → HEX入力オーバーレイが表示 → 2桁HEX入力 → Enter/Tab: 確定・次へ移動  Esc: キャンセル";

            // dataGridView
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.Name = "dataGridView";

            // lblStatus
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.Height = 24;
            this.lblStatus.BackColor = System.Drawing.Color.FromArgb(220, 230, 255);
            this.lblStatus.Font = new System.Drawing.Font("Meiryo UI", 8.5f);
            this.lblStatus.Text = "バイトセルをクリックすると編集できます";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);

            // GridBinaryForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 600);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblStatus);
            this.Font = new System.Drawing.Font("Meiryo UI", 9f);
            this.Name = "GridBinaryForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "バイナリエディタ - DataGridView";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblHelp;
    }
}
