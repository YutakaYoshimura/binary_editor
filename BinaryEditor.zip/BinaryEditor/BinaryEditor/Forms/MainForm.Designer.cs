namespace BinaryEditor.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle       = new System.Windows.Forms.Label();
            this.lblRtb         = new System.Windows.Forms.Label();
            this.lblGrid        = new System.Windows.Forms.Label();
            this.btnRtbWhole    = new System.Windows.Forms.Button();
            this.btnRtbParam    = new System.Windows.Forms.Button();
            this.btnGridWhole   = new System.Windows.Forms.Button();
            this.btnGridParam   = new System.Windows.Forms.Button();
            this.panelMain      = new System.Windows.Forms.Panel();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();

            // panelMain
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Padding = new System.Windows.Forms.Padding(20);
            this.panelMain.Controls.Add(this.lblTitle);
            this.panelMain.Controls.Add(this.lblRtb);
            this.panelMain.Controls.Add(this.btnRtbWhole);
            this.panelMain.Controls.Add(this.btnRtbParam);
            this.panelMain.Controls.Add(this.lblGrid);
            this.panelMain.Controls.Add(this.btnGridWhole);
            this.panelMain.Controls.Add(this.btnGridParam);

            // lblTitle
            this.lblTitle.AutoSize  = false;
            this.lblTitle.Location  = new System.Drawing.Point(20, 16);
            this.lblTitle.Size      = new System.Drawing.Size(360, 32);
            this.lblTitle.Font      = new System.Drawing.Font("Meiryo UI", 13f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(30, 60, 120);
            this.lblTitle.Text      = "バイナリエディタ";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // lblRtb
            this.lblRtb.AutoSize  = false;
            this.lblRtb.Location  = new System.Drawing.Point(20, 60);
            this.lblRtb.Size      = new System.Drawing.Size(360, 20);
            this.lblRtb.Font      = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblRtb.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblRtb.Text      = "── RichTextBox エディタ ──────────────";

            // btnRtbWhole
            this.btnRtbWhole.Location   = new System.Drawing.Point(20, 86);
            this.btnRtbWhole.Size       = new System.Drawing.Size(360, 52);
            this.btnRtbWhole.Font       = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnRtbWhole.Text       = "① RichTextBox ― バイナリ全体表示・編集\r\n(HEXダンプ形式、バイト単位スペース区切り)";
            this.btnRtbWhole.BackColor  = System.Drawing.Color.SteelBlue;
            this.btnRtbWhole.ForeColor  = System.Drawing.Color.White;
            this.btnRtbWhole.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnRtbWhole.Click     += new System.EventHandler(this.btnRtbWhole_Click);

            // btnRtbParam
            this.btnRtbParam.Location   = new System.Drawing.Point(20, 146);
            this.btnRtbParam.Size       = new System.Drawing.Size(360, 52);
            this.btnRtbParam.Font       = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnRtbParam.Text       = "② RichTextBox ― パラメータ毎表示・編集\r\n(テキスト表示＋HexEditオーバーレイ入力)";
            this.btnRtbParam.BackColor  = System.Drawing.Color.CornflowerBlue;
            this.btnRtbParam.ForeColor  = System.Drawing.Color.White;
            this.btnRtbParam.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnRtbParam.Click     += new System.EventHandler(this.btnRtbParam_Click);

            // lblGrid
            this.lblGrid.AutoSize  = false;
            this.lblGrid.Location  = new System.Drawing.Point(20, 216);
            this.lblGrid.Size      = new System.Drawing.Size(360, 20);
            this.lblGrid.Font      = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this.lblGrid.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblGrid.Text      = "── DataGridView エディタ ───────────────";

            // btnGridWhole
            this.btnGridWhole.Location   = new System.Drawing.Point(20, 242);
            this.btnGridWhole.Size       = new System.Drawing.Size(360, 52);
            this.btnGridWhole.Font       = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnGridWhole.Text       = "③ DataGridView ― バイナリ全体表示・編集\r\n(グリッド形式、バイトセル毎にHexEdit入力)";
            this.btnGridWhole.BackColor  = System.Drawing.Color.SeaGreen;
            this.btnGridWhole.ForeColor  = System.Drawing.Color.White;
            this.btnGridWhole.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnGridWhole.Click     += new System.EventHandler(this.btnGridWhole_Click);

            // btnGridParam
            this.btnGridParam.Location   = new System.Drawing.Point(20, 302);
            this.btnGridParam.Size       = new System.Drawing.Size(360, 52);
            this.btnGridParam.Font       = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnGridParam.Text       = "④ DataGridView ― パラメータ毎表示・編集\r\n(パラメータ定義付き、HexEditオーバーレイ入力)";
            this.btnGridParam.BackColor  = System.Drawing.Color.MediumSeaGreen;
            this.btnGridParam.ForeColor  = System.Drawing.Color.White;
            this.btnGridParam.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnGridParam.Click     += new System.EventHandler(this.btnGridParam_Click);

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(400, 390);
            this.Controls.Add(this.panelMain);
            this.Font                = new System.Drawing.Font("Meiryo UI", 9f);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox         = false;
            this.Name                = "MainForm";
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "バイナリエディタ";
            this.panelMain.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label  lblTitle;
        private System.Windows.Forms.Label  lblRtb;
        private System.Windows.Forms.Label  lblGrid;
        private System.Windows.Forms.Button btnRtbWhole;
        private System.Windows.Forms.Button btnRtbParam;
        private System.Windows.Forms.Button btnGridWhole;
        private System.Windows.Forms.Button btnGridParam;
        private System.Windows.Forms.Panel  panelMain;
    }
}
