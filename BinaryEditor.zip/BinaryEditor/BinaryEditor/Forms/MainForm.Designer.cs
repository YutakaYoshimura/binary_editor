namespace BinaryEditor.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnRichText = new System.Windows.Forms.Button();
            this.btnGrid = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.AutoSize = false;
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Font = new System.Drawing.Font("Meiryo UI", 14f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitle.Height = 60;
            this.lblTitle.Text = "バイナリエディタ - エディタ選択";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // panel1
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Controls.Add(this.btnRichText);
            this.panel1.Controls.Add(this.btnGrid);

            // btnRichText
            this.btnRichText.Location = new System.Drawing.Point(60, 60);
            this.btnRichText.Size = new System.Drawing.Size(280, 80);
            this.btnRichText.Font = new System.Drawing.Font("Meiryo UI", 11f);
            this.btnRichText.Text = "① RichTextBox バイナリエディタ\r\n(テキスト形式でバイナリ全体表示)";
            this.btnRichText.BackColor = System.Drawing.Color.SteelBlue;
            this.btnRichText.ForeColor = System.Drawing.Color.White;
            this.btnRichText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRichText.Click += new System.EventHandler(this.btnRichText_Click);

            // btnGrid
            this.btnGrid.Location = new System.Drawing.Point(60, 170);
            this.btnGrid.Size = new System.Drawing.Size(280, 80);
            this.btnGrid.Font = new System.Drawing.Font("Meiryo UI", 11f);
            this.btnGrid.Text = "② DataGridView バイナリエディタ\r\n(グリッド形式でパラメータ毎に編集)";
            this.btnGrid.BackColor = System.Drawing.Color.SeaGreen;
            this.btnGrid.ForeColor = System.Drawing.Color.White;
            this.btnGrid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrid.Click += new System.EventHandler(this.btnGrid_Click);

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 320);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Meiryo UI", 9f);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "バイナリエディタ";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button btnRichText;
        private System.Windows.Forms.Button btnGrid;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panel1;
    }
}
