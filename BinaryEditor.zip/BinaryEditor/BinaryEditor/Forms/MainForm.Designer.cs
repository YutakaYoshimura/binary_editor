namespace BinaryEditor.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle   = new System.Windows.Forms.Label();
            this.btnForm1   = new System.Windows.Forms.Button();
            this.btnForm2   = new System.Windows.Forms.Button();
            this.btnForm3   = new System.Windows.Forms.Button();
            this.btnForm4   = new System.Windows.Forms.Button();
            this.lblSep1    = new System.Windows.Forms.Label();
            this.lblSep2    = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.Location  = new System.Drawing.Point(0, 0);
            this.lblTitle.Size      = new System.Drawing.Size(420, 44);
            this.lblTitle.Font      = new System.Drawing.Font("Meiryo UI", 13f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(30, 60, 120);
            this.lblTitle.BackColor = System.Drawing.Color.FromArgb(225, 235, 255);
            this.lblTitle.Text      = "バイナリエディタ　比較デモ";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Dock      = System.Windows.Forms.DockStyle.Top;

            // lblSep1
            this.lblSep1.Location  = new System.Drawing.Point(20, 58);
            this.lblSep1.Size      = new System.Drawing.Size(380, 18);
            this.lblSep1.Font      = new System.Drawing.Font("Meiryo UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblSep1.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblSep1.Text      = "── RichTextBox 使用 ───────────────────";

            // btnForm1
            this.btnForm1.Location  = new System.Drawing.Point(20, 80);
            this.btnForm1.Size      = new System.Drawing.Size(380, 56);
            this.btnForm1.Font      = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnForm1.Text      = "画面①　RichTextBox ― バイナリ全体表示・編集\r\n表示／編集ともに RichTextBox を使用";
            this.btnForm1.BackColor = System.Drawing.Color.SteelBlue;
            this.btnForm1.ForeColor = System.Drawing.Color.White;
            this.btnForm1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1.Click    += new System.EventHandler(this.btnForm1_Click);

            // btnForm2
            this.btnForm2.Location  = new System.Drawing.Point(20, 144);
            this.btnForm2.Size      = new System.Drawing.Size(380, 56);
            this.btnForm2.Font      = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnForm2.Text      = "画面②　RichTextBox ― パラメータ毎表示・編集\r\n表示: DataGridView　編集: RichTextBox を重ねる";
            this.btnForm2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnForm2.ForeColor = System.Drawing.Color.White;
            this.btnForm2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm2.Click    += new System.EventHandler(this.btnForm2_Click);

            // lblSep2
            this.lblSep2.Location  = new System.Drawing.Point(20, 214);
            this.lblSep2.Size      = new System.Drawing.Size(380, 18);
            this.lblSep2.Font      = new System.Drawing.Font("Meiryo UI", 8.5f, System.Drawing.FontStyle.Bold);
            this.lblSep2.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblSep2.Text      = "── DataGridView 使用 ──────────────────";

            // btnForm3
            this.btnForm3.Location  = new System.Drawing.Point(20, 236);
            this.btnForm3.Size      = new System.Drawing.Size(380, 56);
            this.btnForm3.Font      = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnForm3.Text      = "画面③　DataGridView ― バイナリ全体表示・編集\r\n表示／編集ともに DataGridView を使用";
            this.btnForm3.BackColor = System.Drawing.Color.SeaGreen;
            this.btnForm3.ForeColor = System.Drawing.Color.White;
            this.btnForm3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm3.Click    += new System.EventHandler(this.btnForm3_Click);

            // btnForm4
            this.btnForm4.Location  = new System.Drawing.Point(20, 300);
            this.btnForm4.Size      = new System.Drawing.Size(380, 56);
            this.btnForm4.Font      = new System.Drawing.Font("Meiryo UI", 10f);
            this.btnForm4.Text      = "画面④　DataGridView ― パラメータ毎表示・編集\r\n表示: DataGridView　編集: DataGridView を重ねる";
            this.btnForm4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnForm4.ForeColor = System.Drawing.Color.White;
            this.btnForm4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm4.Click    += new System.EventHandler(this.btnForm4_Click);

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(420, 380);
            this.Controls.Add(this.btnForm4);
            this.Controls.Add(this.btnForm3);
            this.Controls.Add(this.lblSep2);
            this.Controls.Add(this.btnForm2);
            this.Controls.Add(this.btnForm1);
            this.Controls.Add(this.lblSep1);
            this.Controls.Add(this.lblTitle);
            this.Font                = new System.Drawing.Font("Meiryo UI", 9f);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox         = false;
            this.Name                = "MainForm";
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "バイナリエディタ";
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label  lblTitle;
        private System.Windows.Forms.Label  lblSep1;
        private System.Windows.Forms.Label  lblSep2;
        private System.Windows.Forms.Button btnForm1;
        private System.Windows.Forms.Button btnForm2;
        private System.Windows.Forms.Button btnForm3;
        private System.Windows.Forms.Button btnForm4;
    }
}
