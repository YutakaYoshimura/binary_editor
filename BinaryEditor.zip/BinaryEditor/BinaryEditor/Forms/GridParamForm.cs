using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using BinaryEditor.Controls;
using BinaryEditor.Models;

namespace BinaryEditor.Forms
{
    /// <summary>
    /// 画面④ DataGridView ― パラメータ毎表示・編集
    /// ・パラメータ定義に基づき1パラメータ1行で表示
    /// ・HEX値セルクリック時、バイト数分の HexEditControl がセル上に重なって表示される
    /// </summary>
    public partial class GridParamForm : Form
    {
        private byte[]                _data;
        private List<BinaryParameter> _params;

        // オーバーレイ（最大4バイト分）
        private HexEditControl[] _overlays;
        private int              _editRow      = -1;

        // 列インデックス定数
        private const int COL_NAME   = 0;
        private const int COL_DESC   = 1;
        private const int COL_HEX    = 2;
        private const int COL_PARSED = 3;
        private const int COL_UNIT   = 4;
        private const int COL_OFFSET = 5;
        private const int COL_LEN    = 6;
        private const int COL_FMT    = 7;

        public GridParamForm()
        {
            InitializeComponent();
            _params = BinaryParameter.GetSampleParameters();
            _data   = BinaryParameter.GetSampleData();

            SetupGrid();
            InitOverlays();
            RefreshGrid();
        }

        // ---- グリッド定義 ----

        private void SetupGrid()
        {
            dataGridView.SuspendLayout();

            dataGridView.Columns.Add(MakeCol("colName",   "パラメータ名", 110, true,  Color.FromArgb(232,234,248), Color.FromArgb(30,40,120),  FontStyle.Bold));
            dataGridView.Columns.Add(MakeCol("colDesc",   "説明",         180, true,  Color.White,                Color.FromArgb(40,40,80),    FontStyle.Regular));
            dataGridView.Columns.Add(MakeCol("colHex",    "HEX値",         130, true,  Color.FromArgb(255,252,220),Color.FromArgb(0,100,180),   FontStyle.Bold));
            dataGridView.Columns.Add(MakeCol("colParsed", "解析値",        100, true,  Color.White,                Color.FromArgb(0,120,60),    FontStyle.Regular));
            dataGridView.Columns.Add(MakeCol("colUnit",   "単位",           60, true,  Color.White,                Color.DimGray,               FontStyle.Regular));
            dataGridView.Columns.Add(MakeCol("colOffset", "Offset",         72, true,  Color.FromArgb(240,240,248),Color.DimGray,               FontStyle.Regular));
            dataGridView.Columns.Add(MakeCol("colLen",    "Len",            40, true,  Color.FromArgb(240,240,248),Color.DimGray,               FontStyle.Regular));
            dataGridView.Columns.Add(MakeCol("colFmt",    "形式",           72, true,  Color.FromArgb(240,240,248),Color.DimGray,               FontStyle.Regular));

            var hdrStyle = dataGridView.ColumnHeadersDefaultCellStyle;
            hdrStyle.Font      = new Font("Meiryo UI", 9f, FontStyle.Bold);
            hdrStyle.BackColor = Color.FromArgb(45, 75, 145);
            hdrStyle.ForeColor = Color.White;
            hdrStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView.EnableHeadersVisualStyles = false;
            dataGridView.ColumnHeadersHeight       = 26;
            dataGridView.RowHeadersWidth           = 4;
            dataGridView.AllowUserToAddRows        = false;
            dataGridView.AllowUserToDeleteRows     = false;
            dataGridView.AllowUserToResizeRows     = false;
            dataGridView.MultiSelect               = false;
            dataGridView.SelectionMode             = DataGridViewSelectionMode.FullRowSelect;
            dataGridView.GridColor                 = Color.FromArgb(200, 210, 230);
            dataGridView.BackgroundColor           = Color.FromArgb(245, 248, 255);
            dataGridView.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(190, 215, 255);
            dataGridView.RowsDefaultCellStyle.SelectionForeColor = Color.DarkBlue;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 255);

            dataGridView.CellClick  += Grid_CellClick;
            dataGridView.Scroll     += (s, e) => HideAllOverlays();

            dataGridView.ResumeLayout();
        }

        private DataGridViewTextBoxColumn MakeCol(string name, string header,
            int width, bool readOnly, Color back, Color fore, FontStyle fs)
        {
            return new DataGridViewTextBoxColumn
            {
                Name     = name,
                HeaderText = header,
                Width    = width,
                ReadOnly = readOnly,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font      = new Font("Courier New", 9f, fs),
                    BackColor = back,
                    ForeColor = fore,
                    Alignment = DataGridViewContentAlignment.MiddleLeft
                }
            };
        }

        // ---- オーバーレイ初期化 ----

        private void InitOverlays()
        {
            _overlays = new HexEditControl[4];
            for (int i = 0; i < _overlays.Length; i++)
            {
                _overlays[i] = new HexEditControl();
                _overlays[i].Visible  = false;
                int idx = i;
                _overlays[i].KeyDown   += (s, e) => Overlay_KeyDown(s, e, idx);
                _overlays[i].LostFocus += Overlay_LostFocus;
                dataGridView.Controls.Add(_overlays[i]);
            }
        }

        // ---- データ表示 ----

        private void RefreshGrid()
        {
            dataGridView.SuspendLayout();
            dataGridView.Rows.Clear();

            for (int i = 0; i < _params.Count; i++)
            {
                var p = _params[i];
                int ri = dataGridView.Rows.Add(
                    p.Name,
                    p.Description,
                    BuildHexStr(p),
                    ParseValue(p),
                    p.Unit,
                    string.Format("0x{0:X4}", p.Offset),
                    p.Length.ToString(),
                    p.Format
                );
                dataGridView.Rows[ri].Height = 22;

                // 予約領域は薄いグレーで表示
                if (p.Name.StartsWith("Reserved"))
                {
                    for (int c = 0; c < dataGridView.Columns.Count; c++)
                        dataGridView.Rows[ri].Cells[c].Style.ForeColor = Color.LightGray;
                }
            }

            dataGridView.ResumeLayout();
        }

        private string BuildHexStr(BinaryParameter p)
        {
            var sb = new StringBuilder();
            for (int b = 0; b < p.Length; b++)
            {
                int idx = p.Offset + b;
                sb.AppendFormat(idx < _data.Length ? "{0:X2} " : "?? ", idx < _data.Length ? _data[idx] : 0);
            }
            return sb.ToString().TrimEnd();
        }

        private string ParseValue(BinaryParameter p)
        {
            try
            {
                switch (p.Format)
                {
                    case "UINT8":
                        if (p.Offset < _data.Length)
                            return _data[p.Offset].ToString();
                        break;
                    case "UINT16BE":
                        if (p.Offset + 1 < _data.Length)
                            return ((_data[p.Offset] << 8) | _data[p.Offset + 1]).ToString();
                        break;
                    case "UINT16LE":
                        if (p.Offset + 1 < _data.Length)
                            return (_data[p.Offset] | (_data[p.Offset + 1] << 8)).ToString();
                        break;
                    case "ASCII":
                        int len = Math.Min(p.Length, _data.Length - p.Offset);
                        if (len > 0)
                            return "\"" + Encoding.ASCII.GetString(_data, p.Offset, len).TrimEnd('\0') + "\"";
                        break;
                    case "HEX":
                    default:
                        return "-";
                }
            }
            catch { }
            return "-";
        }

        // ---- セルクリック → オーバーレイ ----

        private void Grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) { HideAllOverlays(); return; }

            // HEX列のみ編集対象
            if (e.ColumnIndex != COL_HEX) { HideAllOverlays(); return; }

            ShowOverlays(e.RowIndex);
        }

        private void ShowOverlays(int rowIdx)
        {
            HideAllOverlays();
            _editRow = rowIdx;

            var p = _params[rowIdx];

            // HEXセルの矩形を取得
            Rectangle hexRect = dataGridView.GetCellDisplayRectangle(COL_HEX, rowIdx, false);

            // バイト数分のオーバーレイをHEXセル内に並べる
            // 幅: (HEXセル幅 - 4) を p.Length 等分
            int byteCount = Math.Min(p.Length, _overlays.Length);
            int byteWidth = (hexRect.Width - 4) / byteCount;

            for (int b = 0; b < byteCount; b++)
            {
                int x = hexRect.Left + 2 + b * (byteWidth + 2);
                int dataIdx = p.Offset + b;

                _overlays[b].Location = new Point(x, hexRect.Top + 1);
                _overlays[b].Size     = new Size(byteWidth, hexRect.Height - 2);
                _overlays[b].SetByteValue(dataIdx < _data.Length ? _data[dataIdx] : (byte)0);
                _overlays[b].Visible = true;
            }

            _overlays[0].Focus();
            _overlays[0].SelectAll();

            lblStatus.Text = string.Format(
                "編集中  [{0}] {1}  Offset:0x{2:X4}  Length:{3}byte  形式:{4}  [Enter/Tab]:次バイト or 確定  [Esc]:キャンセル",
                p.Name, p.Description, p.Offset, p.Length, p.Format);
        }

        private void CommitOverlays()
        {
            if (_editRow < 0) return;

            var p = _params[_editRow];
            int byteCount = Math.Min(p.Length, _overlays.Length);
            bool valid = true;

            for (int b = 0; b < byteCount; b++)
            {
                if (!_overlays[b].Visible) continue;
                if (!_overlays[b].IsValidHex) { valid = false; break; }
            }

            if (!valid)
            {
                lblStatus.Text = "無効な値 ― 16進数(00〜FF)を入力してください";
                HideAllOverlays();
                _editRow = -1;
                return;
            }

            for (int b = 0; b < byteCount; b++)
            {
                if (!_overlays[b].Visible) continue;
                byte? v = _overlays[b].GetByteValue();
                int dataIdx = p.Offset + b;
                if (v.HasValue && dataIdx < _data.Length)
                    _data[dataIdx] = v.Value;
            }

            // セル表示を更新
            dataGridView.Rows[_editRow].Cells[COL_HEX].Value    = BuildHexStr(p);
            dataGridView.Rows[_editRow].Cells[COL_PARSED].Value  = ParseValue(p);

            lblStatus.Text = string.Format("更新完了  [{0}]  {1}", p.Name, BuildHexStr(p));
            HideAllOverlays();
            _editRow = -1;
        }

        private void HideAllOverlays()
        {
            foreach (var ov in _overlays)
                ov.Visible = false;
        }

        private void Overlay_KeyDown(object sender, KeyEventArgs e, int overlayIdx)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                if (_editRow >= 0)
                {
                    int byteCount = Math.Min(_params[_editRow].Length, _overlays.Length);
                    int next = overlayIdx + 1;
                    if (next < byteCount && _overlays[next].Visible)
                    {
                        _overlays[next].Focus();
                        _overlays[next].SelectAll();
                    }
                    else
                    {
                        CommitOverlays();
                        // 次のパラメータ行へ移動
                        int nextRow = _editRow >= 0 ? _editRow + 1 : -1;
                        if (nextRow >= 0 && nextRow < _params.Count)
                            ShowOverlays(nextRow);
                    }
                }
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                HideAllOverlays();
                _editRow = -1;
                lblStatus.Text = "編集キャンセル";
                e.Handled = true;
            }
        }

        private void Overlay_LostFocus(object sender, EventArgs e)
        {
            foreach (var ov in _overlays)
                if (ov.Focused) return;

            if (_editRow >= 0)
                CommitOverlays();
        }

        // ---- ファイル操作 ----

        private void btnOpen_Click(object sender, EventArgs e)
        {
            HideAllOverlays();
            using (var dlg = new OpenFileDialog { Filter = "すべてのファイル (*.*)|*.*|バイナリ (*.bin)|*.bin" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    _data = File.ReadAllBytes(dlg.FileName);
                    RefreshGrid();
                    lblStatus.Text = string.Format("読込完了: {0} ({1} bytes)",
                        Path.GetFileName(dlg.FileName), _data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("読み込み失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            HideAllOverlays();
            using (var dlg = new SaveFileDialog { Filter = "バイナリ (*.bin)|*.bin|すべてのファイル (*.*)|*.*" })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                try
                {
                    File.WriteAllBytes(dlg.FileName, _data);
                    lblStatus.Text = "保存完了: " + Path.GetFileName(dlg.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("保存失敗\n" + ex.Message, "エラー",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
