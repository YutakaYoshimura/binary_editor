using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace BinaryEditor.Controls
{
    /// <summary>
    /// バイナリエディタ用カスタムコントロール
    /// 16進数値の入力・表示専用テキストボックス
    /// </summary>
    public class HexEditControl : TextBox
    {
        private bool _isByteMode = true; // 1バイト(2桁HEX)モード

        public HexEditControl()
        {
            this.Font = new Font("Courier New", 9f, FontStyle.Regular);
            this.BackColor = Color.FromArgb(255, 255, 200); // 薄い黄色で編集中を強調
            this.ForeColor = Color.DarkBlue;
            this.BorderStyle = BorderStyle.FixedSingle;
            this.MaxLength = _isByteMode ? 2 : 8;
            this.TextAlign = HorizontalAlignment.Center;
            this.CharacterCasing = CharacterCasing.Upper;
            this.KeyPress += HexEditControl_KeyPress;
            this.TextChanged += HexEditControl_TextChanged;
        }

        /// <summary>
        /// 入力を16進数文字のみに制限
        /// </summary>
        private void HexEditControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar))
                return;

            if (!IsHexChar(e.KeyChar))
            {
                e.Handled = true;
                System.Media.SystemSounds.Beep.Play();
            }
        }

        private void HexEditControl_TextChanged(object sender, EventArgs e)
        {
            // 最大長を超えたら自動確定
            if (_isByteMode && this.Text.Length >= 2)
            {
                // 入力完了時にフォーカスを次へ
            }
        }

        private bool IsHexChar(char c)
        {
            return (c >= '0' && c <= '9') ||
                   (c >= 'a' && c <= 'f') ||
                   (c >= 'A' && c <= 'F');
        }

        /// <summary>
        /// 現在のテキストをバイト値として取得
        /// </summary>
        public byte? GetByteValue()
        {
            if (string.IsNullOrEmpty(this.Text))
                return null;
            try
            {
                return Convert.ToByte(this.Text, 16);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// バイト値をテキストにセット
        /// </summary>
        public void SetByteValue(byte value)
        {
            this.Text = value.ToString("X2");
        }

        /// <summary>
        /// 入力値が有効な16進数かチェック
        /// </summary>
        public bool IsValidHex
        {
            get
            {
                if (string.IsNullOrEmpty(this.Text)) return false;
                try
                {
                    Convert.ToByte(this.Text, 16);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }
    }
}
