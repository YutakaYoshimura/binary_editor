using System;
using System.Drawing;
using System.Windows.Forms;

namespace BinaryEditor.Controls
{
    /// <summary>
    /// バイナリエディタ用カスタムHEX入力コントロール。
    /// テキストコントロールの上に重ねて使用し、16進数入力のみ受け付ける。
    /// </summary>
    public class HexEditControl : TextBox
    {
        public HexEditControl()
        {
            this.Font        = new Font("Courier New", 9.5f, FontStyle.Bold);
            this.BackColor   = Color.FromArgb(255, 252, 180);  // 薄い黄色
            this.ForeColor   = Color.DarkRed;
            this.BorderStyle = BorderStyle.FixedSingle;
            this.MaxLength   = 2;
            this.TextAlign   = HorizontalAlignment.Center;
            this.CharacterCasing = CharacterCasing.Upper;

            this.KeyPress   += OnHexKeyPress;
        }

        // ---- 入力制限 ----

        private void OnHexKeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar)) return;
            if (!IsHexChar(e.KeyChar))
            {
                e.Handled = true;
                System.Media.SystemSounds.Beep.Play();
            }
        }

        private static bool IsHexChar(char c)
            => (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');

        // ---- 値アクセス ----

        public bool IsValidHex
        {
            get
            {
                if (string.IsNullOrEmpty(this.Text)) return false;
                try { Convert.ToByte(this.Text, 16); return true; }
                catch { return false; }
            }
        }

        public byte? GetByteValue()
        {
            if (!IsValidHex) return null;
            return Convert.ToByte(this.Text, 16);
        }

        public void SetByteValue(byte value)
        {
            this.Text = value.ToString("X2");
        }
    }
}
