using System;
using System.Drawing;
using System.Windows.Forms;

namespace BinaryEditor.Controls
{
    /// <summary>
    /// バイナリエディタ用カスタムHEX入力コントロール。
    /// TextBoxを継承し、16進数文字のみ受け付ける。
    /// 表示中のテキストコントロールの上に重ねて使用する。
    /// </summary>
    public class HexEditControl : TextBox
    {
        public HexEditControl()
        {
            this.Font            = new Font("Courier New", 9.5f, FontStyle.Bold);
            this.BackColor       = Color.FromArgb(255, 252, 180);
            this.ForeColor       = Color.DarkRed;
            this.BorderStyle     = BorderStyle.FixedSingle;
            this.MaxLength       = 2;
            this.TextAlign       = HorizontalAlignment.Center;
            this.CharacterCasing = CharacterCasing.Upper;
            this.KeyPress       += OnHexKeyPress;
        }

        private void OnHexKeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar)) return;
            if (!IsHexChar(e.KeyChar))
            {
                e.Handled = true;
                System.Media.SystemSounds.Beep.Play();
            }
        }

        private static bool IsHexChar(char c)
            => (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');

        public bool IsValidHex
        {
            get
            {
                if (string.IsNullOrEmpty(this.Text)) return false;
                try { Convert.ToByte(this.Text, 16); return true; }
                catch { return false; }
            }
        }

        public byte? GetByteValue()
        {
            if (!IsValidHex) return null;
            return Convert.ToByte(this.Text, 16);
        }

        public void SetByteValue(byte value)
        {
            this.Text = value.ToString("X2");
        }
    }
}
