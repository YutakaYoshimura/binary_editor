using System;
using System.Windows.Forms;

namespace MergedHeaderGrid
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // 高DPI対応・見た目のモダン化
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new Form1());
        }
    }
}
