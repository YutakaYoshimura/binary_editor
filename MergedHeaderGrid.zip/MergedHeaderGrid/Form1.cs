using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MergedHeaderGrid
{
    /// <summary>
    /// DataGridViewで
    ///  ・ヘッダーを2段表示し、一部の列を大分類としてまとめる
    ///  ・データ部分でも特定の列(部門)を縦方向に結合表示する
    ///  ・結合したブロックごとに背景色を変える
    /// ことを実現するサンプルフォーム。
    /// </summary>
    public class Form1 : Form
    {
        private DataGridView dgv = new DataGridView();

        // ==============================================================
        // 列インデックス定数(読みやすさのため名前を付けておく)
        // ==============================================================
        private const int COL_DEPT = 0;         // 部門(データ部分を縦結合する列)
        private const int COL_NO = 1;           // 番号
        private const int COL_TAXIN_PRICE = 2;  // 税込単価
        private const int COL_TAXIN_SALES = 3;  // 税込売上
        private const int COL_TAXOUT_PRICE = 4; // 税抜単価
        private const int COL_TAXOUT_SALES = 5; // 税抜売上

        // ==============================================================
        // ヘッダーの大分類グループ定義(列インデックス → グループ名)
        // ここに登録された列は、ヘッダー上段にグループ名がまとめて表示される
        // ==============================================================
        private readonly Dictionary<int, string> headerGroupMap = new Dictionary<int, string>
        {
            { COL_TAXIN_PRICE,  "税込" }, { COL_TAXIN_SALES,  "税込" },
            { COL_TAXOUT_PRICE, "税抜" }, { COL_TAXOUT_SALES, "税抜" },
        };

        // ==============================================================
        // データ部分の縦結合ブロック情報
        // (開始行インデックス, 終了行インデックス, 値) のリスト。
        // 例えば 部門="営業部" が0〜2行目に連続していれば (0, 2, "営業部") となる。
        // ==============================================================
        private List<(int Start, int End, string Value)> deptBlocks = new List<(int, int, string)>();

        // 結合ブロックごとに交互に使う背景色(奇数番目/偶数番目のブロックで色を変える)
        private readonly Color[] blockColors = new Color[]
        {
            Color.FromArgb(224, 238, 255), // 薄い青
            Color.FromArgb(255, 250, 224), // 薄い黄
        };

        public Form1()
        {
            Text = "2段ヘッダー + データ結合サンプル";
            Width = 900;
            Height = 500;

            dgv.Dock = DockStyle.Fill;
            dgv.AllowUserToAddRows = false;   // 末尾の空行を非表示
            dgv.RowHeadersVisible = false;    // 左端の行ヘッダーは非表示(見た目をすっきりさせる)

            // --- 列の定義 ---
            dgv.Columns.Add("dept", "部門");
            dgv.Columns.Add("no", "番号");
            dgv.Columns.Add("taxin_price", "単価");
            dgv.Columns.Add("taxin_sales", "売上");
            dgv.Columns.Add("taxout_price", "単価");
            dgv.Columns.Add("taxout_sales", "売上");

            // --- ヘッダーを自前描画に切り替えるための設定 ---
            // EnableHeadersVisualStyles = false にしないと、
            // OSのテーマ描画がCellPaintingでの描画結果を上書きしてしまう
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ColumnHeadersHeight = 40; // 2段分の高さを確保
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.WhiteSmoke;

            // サンプルデータを投入
            LoadSampleData();

            // 部門列の「連続して同じ値の範囲」を計算しておく(結合表示の元データ)
            BuildDeptBlocks();

            // ヘッダー・データ双方のセル描画をこのイベント1つでハンドルする
            dgv.CellPainting += Dgv_CellPainting;

            Controls.Add(dgv);
        }

        /// <summary>
        /// サンプルデータの投入。
        /// 部門列の値が意図的に連続するように並べている(結合表示のデモのため)。
        /// </summary>
        private void LoadSampleData()
        {
            var data = new (string Dept, int No, decimal InPrice, decimal InSales, decimal OutPrice, decimal OutSales)[]
            {
                ("営業部", 1, 110, 1100, 100, 1000),
                ("営業部", 2, 220, 2200, 200, 2000),
                ("営業部", 3, 330, 3300, 300, 3000),
                ("開発部", 4, 440, 4400, 400, 4000),
                ("開発部", 5, 550, 5500, 500, 5000),
                ("総務部", 6, 660, 6600, 600, 6000),
                ("総務部", 7, 770, 7700, 700, 7000),
                ("総務部", 8, 880, 8800, 800, 8000),
                ("経理部", 9, 990, 9900, 900, 9000),
            };

            foreach (var row in data)
            {
                dgv.Rows.Add(row.Dept, row.No, row.InPrice, row.InSales, row.OutPrice, row.OutSales);
            }
        }

        /// <summary>
        /// 部門列(COL_DEPT)の値が連続して同じになっている行の範囲を検出し、
        /// deptBlocks に (開始行, 終了行, 値) として格納する。
        /// ※行の追加・削除・並び替えを行った場合は、都度このメソッドを呼び直す必要がある。
        /// </summary>
        private void BuildDeptBlocks()
        {
            deptBlocks.Clear();
            if (dgv.Rows.Count == 0) return;

            int start = 0;
            for (int r = 1; r <= dgv.Rows.Count; r++)
            {
                // 最終行に到達した、または前の行と値が変わったら「ブロックの区切り」とみなす
                bool isBoundary = r == dgv.Rows.Count ||
                    Convert.ToString(dgv.Rows[r].Cells[COL_DEPT].Value) !=
                    Convert.ToString(dgv.Rows[start].Cells[COL_DEPT].Value);

                if (isBoundary)
                {
                    deptBlocks.Add((start, r - 1, Convert.ToString(dgv.Rows[start].Cells[COL_DEPT].Value)));
                    start = r;
                }
            }
        }

        /// <summary>
        /// ヘッダー行・データ行いずれのセル描画もここで振り分ける。
        /// </summary>
        private void Dgv_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.ColumnIndex < 0) return;

            if (e.RowIndex == -1)
            {
                // ヘッダー行(2段+大分類結合)
                PaintHeader(e);
            }
            else if (e.ColumnIndex == COL_DEPT)
            {
                // データ部分のうち、縦結合したい「部門」列
                PaintMergedDeptCell(e);
            }
            // それ以外のデータセル(番号・単価・売上など)は既定の描画のまま
            // (e.Handled を true にしないので、DataGridViewが通常通り描画する)
        }

        // ==============================================================
        // ヘッダー(2段表示 + 大分類のまとめ)の描画
        // ==============================================================
        private void PaintHeader(DataGridViewCellPaintingEventArgs e)
        {
            e.PaintBackground(e.ClipBounds, true);

            int headerHeight = dgv.ColumnHeadersHeight;
            int topHeight = headerHeight / 2;      // 上段(大分類)の高さ
            var cell = e.CellBounds;               // このセル(1列分)の描画領域

            var font = dgv.ColumnHeadersDefaultCellStyle.Font;
            var fore = dgv.ColumnHeadersDefaultCellStyle.ForeColor;
            var back = dgv.ColumnHeadersDefaultCellStyle.BackColor;

            using (var backBrush = new SolidBrush(back))
            {
                if (headerGroupMap.TryGetValue(e.ColumnIndex, out string groupName))
                {
                    // --- 同じグループに属する列一覧(列インデックス昇順) ---
                    var groupCols = headerGroupMap.Where(kv => kv.Value == groupName)
                                                   .Select(kv => kv.Key).OrderBy(x => x).ToList();
                    int first = groupCols.First(); // グループの先頭(一番左)の列

                    // グループ先頭列から現在セルまでの累積幅(左方向のオフセット)
                    int leftOffset = 0;
                    for (int i = first; i < e.ColumnIndex; i++)
                        leftOffset += dgv.Columns[i].Width;

                    int groupWidth = groupCols.Sum(i => dgv.Columns[i].Width);

                    // 上段(大分類): グループ全体をまたぐ横長の矩形
                    var topRect = new Rectangle(cell.X - leftOffset, cell.Y, groupWidth, topHeight);
                    // 下段(列名): このセル1列分のみ
                    var bottomRect = new Rectangle(cell.X, cell.Y + topHeight, cell.Width, headerHeight - topHeight);

                    e.Graphics.FillRectangle(backBrush, topRect);
                    e.Graphics.FillRectangle(backBrush, bottomRect);

                    // 大分類ラベルはグループ先頭列を描くときだけ1回描画(重複描画防止)
                    if (e.ColumnIndex == first)
                    {
                        e.Graphics.DrawRectangle(Pens.Gray, topRect.X, topRect.Y, topRect.Width - 1, topRect.Height - 1);
                        TextRenderer.DrawText(e.Graphics, groupName, font, topRect, fore,
                            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                    }

                    // 下段(通常の列名)は毎回描画
                    e.Graphics.DrawRectangle(Pens.Gray, cell.X, cell.Y + topHeight, cell.Width - 1, (headerHeight - topHeight) - 1);
                    TextRenderer.DrawText(e.Graphics, e.FormattedValue?.ToString(), font, bottomRect, fore,
                        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                }
                else
                {
                    // グループ化されない単独列(番号列など): 通常通り1段で中央に描画
                    e.Graphics.FillRectangle(backBrush, cell);
                    e.Graphics.DrawRectangle(Pens.Gray, cell.X, cell.Y, cell.Width - 1, cell.Height - 1);
                    TextRenderer.DrawText(e.Graphics, e.FormattedValue?.ToString(), font, cell, fore,
                        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                }
            }

            e.Handled = true; // 既定描画をスキップさせる
        }

        // ==============================================================
        // データ部分:部門列の縦結合 + ブロックごとの色分け描画
        // ==============================================================
        private void PaintMergedDeptCell(DataGridViewCellPaintingEventArgs e)
        {
            // このセル(行)がどの結合ブロックに属するかを検索
            var block = deptBlocks.FirstOrDefault(b => e.RowIndex >= b.Start && e.RowIndex <= b.End);
            int blockIndex = deptBlocks.IndexOf(block);

            // ブロックの並び順(偶数/奇数)で背景色を交互に切り替える
            Color bg = blockColors[blockIndex % blockColors.Length];

            using (var brush = new SolidBrush(bg))
            {
                e.Graphics.FillRectangle(brush, e.CellBounds);
            }

            // --- 枠線の描画 ---
            // 左右の枠線は常に描画する
            e.Graphics.DrawLine(Pens.Gray, e.CellBounds.Left, e.CellBounds.Top, e.CellBounds.Left, e.CellBounds.Bottom);
            e.Graphics.DrawLine(Pens.Gray, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom);

            // ブロックの先頭行のときだけ上枠線を描く
            if (e.RowIndex == block.Start)
                e.Graphics.DrawLine(Pens.Gray, e.CellBounds.Left, e.CellBounds.Top, e.CellBounds.Right, e.CellBounds.Top);

            // ブロックの最終行のときだけ下枠線を描く(=結合セルの下端)
            if (e.RowIndex == block.End)
                e.Graphics.DrawLine(Pens.Gray, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right, e.CellBounds.Bottom - 1);

            // ブロック内の行同士の間には線を引かない
            // → これにより見た目上「複数行がひとつのセルに結合されている」ように見える

            // 文字はブロックの先頭行を描画するときだけ、結合範囲全体を対象に中央揃えで描く
            if (e.RowIndex == block.Start)
            {
                int mergedHeight = 0;
                for (int r = block.Start; r <= block.End; r++)
                    mergedHeight += dgv.Rows[r].Height;

                var mergedRect = new Rectangle(e.CellBounds.X, e.CellBounds.Y, e.CellBounds.Width, mergedHeight);
                TextRenderer.DrawText(e.Graphics, e.FormattedValue?.ToString(), dgv.Font, mergedRect, Color.Black,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }

            e.Handled = true; // 既定描画をスキップさせる
        }
    }
}
