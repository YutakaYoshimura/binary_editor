using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace HexBoxOverlay
{
    // =====================================================================
    //  矩形選択1件の情報
    // =====================================================================
    public class RectSelInfo
    {
        public Rectangle PixelRect   { get; private set; }
        public long      StartOffset { get; private set; }
        public long      EndOffset   { get; private set; }
        public long      ByteCount   { get; private set; }

        public RectSelInfo(Rectangle pxRect,
            int hexAreaLeft, int cellW, int lineH,
            int bytesPerLine, int firstLineY, long scrollOffset)
        {
            PixelRect = pxRect;

            int col0 = (pxRect.Left  - hexAreaLeft) / cellW;
            int col1 = (pxRect.Right - hexAreaLeft) / cellW;
            int row0 = (pxRect.Top    - firstLineY) / lineH;
            int row1 = (pxRect.Bottom - firstLineY) / lineH;

            col0 = Math.Max(0, Math.Min(col0, bytesPerLine - 1));
            col1 = Math.Max(0, Math.Min(col1, bytesPerLine - 1));
            row0 = Math.Max(0, row0);
            row1 = Math.Max(0, row1);

            StartOffset = scrollOffset + (long)row0 * bytesPerLine + col0;
            EndOffset   = scrollOffset + (long)row1 * bytesPerLine + col1;
            ByteCount   = Math.Max(1L, EndOffset - StartOffset + 1L);
        }
    }

    public class SelConfirmedArgs : EventArgs
    {
        public RectSelInfo Selection { get; private set; }
        public SelConfirmedArgs(RectSelInfo s) { Selection = s; }
    }

    // =====================================================================
    //  透明オーバーレイパネル
    //  HexBox の上に Bounds を手動で合わせて重ねて使う。
    //  このパネル自体がマウスイベントを受け取り矩形を描画する。
    // =====================================================================
    public class TransparentOverlayPanel : Panel
    {
        private Point _dragStart;
        private Point _dragCurrent;
        private bool  _isDragging;

        private readonly List<RectSelInfo> _selections = new List<RectSelInfo>();

        // レイアウト情報
        private int  _hexAreaLeft  = 58;
        private int  _cellWidth    = 26;
        private int  _lineHeight   = 18;
        private int  _bytesPerLine = 16;
        private int  _firstLineY   = 4;
        private long _scrollOffset = 0;

        private static readonly Color C_Fill       = Color.FromArgb(60,  0, 120, 215);
        private static readonly Color C_Border     = Color.FromArgb(220, 0,  80, 180);
        private static readonly Color C_DragFill   = Color.FromArgb(50,  0, 160, 255);
        private static readonly Color C_DragBorder = Color.FromArgb(200, 0, 100, 220);
        private static readonly Color C_LabelBg    = Color.FromArgb(200, 0,  60, 160);

        public event EventHandler<SelConfirmedArgs> SelectionConfirmed;

        public IList<RectSelInfo> Selections
        {
            get { return _selections.AsReadOnly(); }
        }

        public TransparentOverlayPanel()
        {
            // 透明背景と高速描画
            SetStyle(
                ControlStyles.SupportsTransparentBackColor |
                ControlStyles.OptimizedDoubleBuffer        |
                ControlStyles.AllPaintingInWmPaint         |
                ControlStyles.UserPaint,
                true);
            BackColor = Color.Transparent;
            Cursor    = Cursors.Cross;
        }

        public void UpdateLayout(int hexAreaLeft, int cellWidth, int lineHeight,
                                  int bytesPerLine, int firstLineY, long scrollOffset)
        {
            _hexAreaLeft  = hexAreaLeft;
            _cellWidth    = cellWidth;
            _lineHeight   = lineHeight;
            _bytesPerLine = bytesPerLine;
            _firstLineY   = firstLineY;
            _scrollOffset = scrollOffset;
        }

        public void ClearSelections()
        {
            _selections.Clear();
            Invalidate();
        }

        // ---- マウス ----
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;

            _dragStart   = e.Location;
            _dragCurrent = e.Location;
            _isDragging  = true;

            if ((ModifierKeys & Keys.Control) == 0)
                _selections.Clear();

            Invalidate();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (!_isDragging) return;
            _dragCurrent = e.Location;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (!_isDragging || e.Button != MouseButtons.Left) return;

            _isDragging  = false;
            _dragCurrent = e.Location;

            Rectangle rect = NormalizeRect(_dragStart, _dragCurrent);
            // 最小サイズ以上の場合のみ選択として確定
            if (rect.Width > 4 && rect.Height > 4)
            {
                RectSelInfo info = new RectSelInfo(
                    rect,
                    _hexAreaLeft, _cellWidth, _lineHeight,
                    _bytesPerLine, _firstLineY, _scrollOffset);

                _selections.Add(info);
                if (SelectionConfirmed != null)
                    SelectionConfirmed(this, new SelConfirmedArgs(info));
            }
            Invalidate();
        }

        // ---- 描画 ----
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;

            // 確定済み矩形
            using (SolidBrush fillBr  = new SolidBrush(C_Fill))
            using (Pen        borderPn = new Pen(C_Border, 2f))
            using (SolidBrush labelFg  = new SolidBrush(Color.White))
            using (SolidBrush labelBg  = new SolidBrush(C_LabelBg))
            using (Font       lFont    = new Font("Courier New", 7.5f, FontStyle.Bold))
            {
                for (int i = 0; i < _selections.Count; i++)
                {
                    RectSelInfo sel = _selections[i];
                    g.FillRectangle(fillBr, sel.PixelRect);
                    g.DrawRectangle(borderPn, sel.PixelRect);

                    string lbl = string.Format("[{0}] 0x{1:X4}-0x{2:X4} ({3}bytes)",
                        i + 1, sel.StartOffset, sel.EndOffset, sel.ByteCount);
                    SizeF  sz  = g.MeasureString(lbl, lFont);
                    float  ly  = sel.PixelRect.Y - sz.Height - 2f;
                    if (ly < 0) ly = sel.PixelRect.Bottom + 2f;
                    RectangleF lr = new RectangleF(sel.PixelRect.X, ly, sz.Width + 4f, sz.Height + 2f);
                    g.FillRectangle(labelBg, lr);
                    g.DrawString(lbl, lFont, labelFg, new PointF(lr.X + 2f, lr.Y + 1f));
                }
            }

            // ドラッグ中
            if (_isDragging)
            {
                Rectangle dr = NormalizeRect(_dragStart, _dragCurrent);
                using (SolidBrush df = new SolidBrush(C_DragFill))
                using (Pen        dp = new Pen(C_DragBorder, 1.5f))
                {
                    dp.DashStyle = DashStyle.Dash;
                    g.FillRectangle(df, dr);
                    g.DrawRectangle(dp, dr);
                }
            }
        }

        // WndProc をオーバーライドして透明背景を正しく描画
        protected override void WndProc(ref Message m)
        {
            // WM_ERASEBKGND を無視して透明を維持
            if (m.Msg == 0x0014)
            {
                m.Result = (IntPtr)1;
                return;
            }
            base.WndProc(ref m);
        }

        private static Rectangle NormalizeRect(Point a, Point b)
        {
            return Rectangle.FromLTRB(
                Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
                Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
        }
    }
}
