using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HexBoxOverlay")]
[assembly: AssemblyDescription("HexBox 矩形選択 - オーバーレイ方式 (NuGet不要)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HexBoxOverlay")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a1b2c3d4-e5f6-7890-abcd-ef1234567890")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
