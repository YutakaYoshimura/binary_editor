using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Be.Windows.Forms;

namespace HexBoxOverlay
{
    /// <summary>
    /// アプローチ①：Be.Windows.Forms.HexBox (NuGet 1.6.1) をそのまま使い、
    /// 上に TransparentOverlayPanel を重ねて矩形選択を視覚的に再現する。
    ///
    /// 重ね方の正しい実装:
    ///   Form に直接 HexBox を Dock=Fill で配置。
    ///   同じ Form に Overlay を追加し、Resize/Move イベントで
    ///   Overlay.Bounds を HexBox.Bounds に常に一致させる。
    ///   BringToFront() でオーバーレイを最前面に保つ。
    /// </summary>
    public class MainForm : Form
    {
        private HexBox                  _hexBox;
        private TransparentOverlayPanel _overlay;
        private Panel                   _mainPanel;   // HexBox + Overlay を入れるコンテナ
        private Panel                   _sidePanel;
        private ListBox                 _selList;
        private Label                   _statusLabel;
        private ToolStrip               _toolStrip;

        // Be.Windows.Forms.HexBox 1.6.1 / Courier New 9pt / 16列 の実測値
        // LineInfoVisible=true, ColumnInfoVisible=true の場合
        private const int BYTES_PER_LINE = 16;
        private const int HEX_AREA_LEFT  = 58;
        private const int CELL_WIDTH     = 26;
        private const int LINE_HEIGHT    = 18;
        private const int FIRST_LINE_Y   = 4;

        public MainForm()
        {
            InitializeComponent();
            LoadSampleData();
        }

        private void InitializeComponent()
        {
            this.Text          = "HexBox 矩形選択 - アプローチ① オーバーレイ (Be.Windows.Forms.HexBox 1.6.1)";
            this.Size          = new Size(1100, 700);
            this.MinimumSize   = new Size(900, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("MS UI Gothic", 9f);

            // ---- ToolStrip ----
            _toolStrip      = new ToolStrip();
            _toolStrip.Dock = DockStyle.Top;
            _toolStrip.Items.Add(new ToolStripButton("ファイルを開く") );
            ((ToolStripButton)_toolStrip.Items[0]).Click += new EventHandler(BtnOpen_Click);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(new ToolStripButton("選択クリア"));
            ((ToolStripButton)_toolStrip.Items[2]).Click += new EventHandler(BtnClear_Click);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(new ToolStripButton("サンプルデータ読込"));
            ((ToolStripButton)_toolStrip.Items[4]).Click += new EventHandler(BtnSample_Click);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(new ToolStripLabel("  ドラッグ:矩形選択  Ctrl+ドラッグ:複数追加"));

            // ---- ステータスバー ----
            _statusLabel           = new Label();
            _statusLabel.Dock      = DockStyle.Bottom;
            _statusLabel.Height    = 24;
            _statusLabel.BackColor = Color.FromArgb(0, 100, 0);
            _statusLabel.ForeColor = Color.White;
            _statusLabel.Font      = new Font("Courier New", 8.5f);
            _statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            _statusLabel.Padding   = new Padding(8, 0, 0, 0);
            _statusLabel.Text      = "ドラッグして矩形選択。Ctrl+ドラッグで複数追加。";

            // ---- サイドパネル ----
            _sidePanel           = new Panel();
            _sidePanel.Dock      = DockStyle.Right;
            _sidePanel.Width     = 280;
            _sidePanel.BackColor = Color.FromArgb(40, 40, 50);
            _sidePanel.Padding   = new Padding(6);

            Label lblTitle = new Label();
            lblTitle.Text      = "矩形選択リスト";
            lblTitle.Dock      = DockStyle.Top;
            lblTitle.ForeColor = Color.LightSkyBlue;
            lblTitle.Font      = new Font("MS UI Gothic", 10f, FontStyle.Bold);
            lblTitle.Height    = 28;

            _selList             = new ListBox();
            _selList.Dock        = DockStyle.Fill;
            _selList.BackColor   = Color.FromArgb(25, 25, 35);
            _selList.ForeColor   = Color.LightGreen;
            _selList.Font        = new Font("Courier New", 8f);
            _selList.BorderStyle = BorderStyle.None;
            _selList.SelectedIndexChanged += new EventHandler(SelList_SelectedIndexChanged);

            Label lblNote = new Label();
            lblNote.Text      = "※ リスト選択でHexBoxの\n  線形選択に反映します";
            lblNote.Dock      = DockStyle.Bottom;
            lblNote.ForeColor = Color.Gray;
            lblNote.Font      = new Font("MS UI Gothic", 8f);
            lblNote.Height    = 36;

            _sidePanel.Controls.Add(_selList);
            _sidePanel.Controls.Add(lblTitle);
            _sidePanel.Controls.Add(lblNote);

            // ---- メインパネル（HexBox と Overlay を重ねるコンテナ）----
            // Panel を使って Dock=Fill で残り領域を占有する
            _mainPanel           = new Panel();
            _mainPanel.Dock      = DockStyle.Fill;
            _mainPanel.BackColor = Color.Black;

            // ---- Be.Windows.Forms.HexBox ----
            _hexBox = new HexBox();
            _hexBox.Dock                 = DockStyle.Fill;
            _hexBox.Font                 = new Font("Courier New", 9f);
            _hexBox.BytesPerLine         = BYTES_PER_LINE;
            _hexBox.UseFixedBytesPerLine = true;
            _hexBox.VScrollBarVisible    = true;
            _hexBox.ColumnInfoVisible    = true;
            _hexBox.LineInfoVisible      = true;
            _hexBox.StringViewVisible    = true;
            _hexBox.BackColor            = Color.FromArgb(30, 30, 30);
            _hexBox.ForeColor            = Color.FromArgb(200, 230, 200);
            _hexBox.SelectionBackColor   = Color.FromArgb(80, 100, 180);
            _hexBox.SelectionForeColor   = Color.White;
            _hexBox.InfoForeColor        = Color.FromArgb(120, 120, 160);

            // ---- TransparentOverlayPanel ----
            // Dock は使わず、HexBox の Bounds に手動で合わせる
            _overlay           = new TransparentOverlayPanel();
            _overlay.BackColor = Color.Transparent;
            _overlay.SelectionConfirmed += new EventHandler<SelConfirmedArgs>(Overlay_SelectionConfirmed);

            // mainPanel に HexBox を追加してから Overlay を追加
            // → Controls の順序は最後が最前面
            _mainPanel.Controls.Add(_hexBox);
            _mainPanel.Controls.Add(_overlay);

            // HexBox リサイズ時に Overlay を追従させる
            _hexBox.Resize += new EventHandler(HexBox_Resize);
            // スクロール検知
            _hexBox.KeyUp      += new KeyEventHandler(HexBox_ScrollTrigger);
            _hexBox.MouseUp    += new MouseEventHandler(HexBox_MouseUp_Trigger);

            // ---- フォームへの追加順序が重要 ----
            // Dock=Right より先に Dock=Fill を追加するとレイアウトが崩れる
            // 正しい順序: Top → Bottom → Right → Fill
            this.Controls.Add(_mainPanel);   // Fill（最後）
            this.Controls.Add(_sidePanel);   // Right
            this.Controls.Add(_statusLabel); // Bottom
            this.Controls.Add(_toolStrip);   // Top

            // フォーム表示後に Overlay を正しい位置・サイズに設定
            this.Shown += new EventHandler(MainForm_Shown);
        }

        // ================================================================
        //  Overlay の Bounds を HexBox に合わせる
        // ================================================================
        private void AdjustOverlay()
        {
            if (_hexBox == null || _overlay == null) return;
            // HexBox の ClientRectangle を _mainPanel 座標系に変換
            _overlay.Bounds = _hexBox.Bounds;
            _overlay.BringToFront();
            SyncScrollOffset();
        }

        private void SyncScrollOffset()
        {
            long scrollOffset = 0;
            try
            {
                // Be.Windows.Forms.HexBox の内部 VScrollBar を子コントロールから探す
                foreach (Control child in _hexBox.Controls)
                {
                    VScrollBar vsb = child as VScrollBar;
                    if (vsb != null)
                    {
                        scrollOffset = (long)vsb.Value * BYTES_PER_LINE;
                        break;
                    }
                }
            }
            catch { }

            _overlay.UpdateLayout(
                HEX_AREA_LEFT, CELL_WIDTH, LINE_HEIGHT,
                BYTES_PER_LINE, FIRST_LINE_Y, scrollOffset);
        }

        // ================================================================
        //  イベントハンドラ
        // ================================================================
        private void MainForm_Shown(object sender, EventArgs e)
        {
            AdjustOverlay();
        }

        private void HexBox_Resize(object sender, EventArgs e)
        {
            AdjustOverlay();
        }

        private void HexBox_ScrollTrigger(object sender, KeyEventArgs e)
        {
            SyncScrollOffset();
            _overlay.Invalidate();
        }

        private void HexBox_MouseUp_Trigger(object sender, MouseEventArgs e)
        {
            SyncScrollOffset();
            _overlay.Invalidate();
        }

        private void Overlay_SelectionConfirmed(object sender, SelConfirmedArgs e)
        {
            RectSelInfo sel = e.Selection;
            string item = string.Format("[{0}] 0x{1:X4}～0x{2:X4} ({3}bytes)",
                _overlay.Selections.Count, sel.StartOffset, sel.EndOffset, sel.ByteCount);
            _selList.Items.Add(item);
            _selList.SelectedIndex = _selList.Items.Count - 1;

            try
            {
                _hexBox.SelectionStart  = sel.StartOffset;
                _hexBox.SelectionLength = sel.ByteCount;
            }
            catch { }

            _statusLabel.Text = string.Format(
                "選択確定: 0x{0:X4} ～ 0x{1:X4}  ({2} bytes)",
                sel.StartOffset, sel.EndOffset, sel.ByteCount);
        }

        private void SelList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = _selList.SelectedIndex;
            if (idx < 0 || idx >= _overlay.Selections.Count) return;
            RectSelInfo sel = _overlay.Selections[idx];
            try
            {
                _hexBox.SelectionStart  = sel.StartOffset;
                _hexBox.SelectionLength = sel.ByteCount;
            }
            catch { }
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title  = "バイナリファイルを開く";
            dlg.Filter = "すべてのファイル (*.*)|*.*";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                _hexBox.ByteProvider = new DynamicFileByteProvider(dlg.FileName);
                _overlay.ClearSelections();
                _selList.Items.Clear();
                FileInfo fi = new FileInfo(dlg.FileName);
                _statusLabel.Text = string.Format("読込完了: {0}  ({1:N0} bytes)",
                    dlg.FileName, fi.Length);
                SyncScrollOffset();
            }
            catch (Exception ex)
            {
                MessageBox.Show("読込エラー:\n" + ex.Message, "エラー",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            _overlay.ClearSelections();
            _selList.Items.Clear();
            _statusLabel.Text = "選択をクリアしました";
        }

        private void BtnSample_Click(object sender, EventArgs e)
        {
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            byte[] data = new byte[512];
            data[0]  = 0x89; data[1]  = 0x50; data[2]  = 0x4E; data[3]  = 0x47;
            data[4]  = 0x0D; data[5]  = 0x0A; data[6]  = 0x1A; data[7]  = 0x0A;
            data[8]  = 0x00; data[9]  = 0x00; data[10] = 0x00; data[11] = 0x0D;
            data[12] = 0x49; data[13] = 0x48; data[14] = 0x44; data[15] = 0x52;
            for (int i = 16; i < data.Length; i++)
                data[i] = (byte)(i & 0xFF);

            _hexBox.ByteProvider = new DynamicByteProvider(data);
            if (_overlay  != null) _overlay.ClearSelections();
            if (_selList  != null) _selList.Items.Clear();
            if (_statusLabel != null)
                _statusLabel.Text = string.Format(
                    "サンプルデータ ({0}bytes)。ドラッグして矩形選択してください。", data.Length);
        }
    }
}
