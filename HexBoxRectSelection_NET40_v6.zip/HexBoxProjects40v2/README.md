# HexBox 矩形選択サンプル (.NET Framework 4.0)

## 必要環境

- .NET Framework 4.0 以上
- Visual Studio 2013 以上（推奨: 2019 / 2022）
- Windows OS
- インターネット接続（NuGet パッケージ取得のため）

---

## プロジェクト構成

```
HexBoxRectSelection_NET40.sln
NuGet.Config                         ← packagesフォルダをソリューション直下に固定
packages\                            ← NuGet復元後に自動生成される
├── 1_OverlayApproach\HexBoxOverlay\ ← アプローチ① (Be.Windows.Forms.HexBox 使用)
└── 2_ForkedApproach\HexBoxForked\   ← アプローチ② (フォーク改修版 / NuGet不要)
```

---

## アプローチ①のビルド手順（重要）

### ステップ1：NuGet パッケージの復元

Visual Studio でソリューション `HexBoxRectSelection_NET40.sln` を開き、

```
ソリューション右クリック → NuGet パッケージの復元
```

復元後、以下のフォルダが自動生成されることを確認してください：

```
HexBoxProjects40v2\
  packages\
    Be.Windows.Forms.HexBox.1.6.1\
      lib\
        net40\
          Be.Windows.Forms.HexBox.dll  ← これが参照される
```

### ステップ2：ビルド

Visual Studio でそのままビルドしてください。

---

### NuGet 復元がうまくいかない場合（手動配置）

Visual Studio の NuGet パッケージ マネージャーコンソールで以下を実行：

```
Install-Package Be.Windows.Forms.HexBox -Version 1.6.1 -ProjectName HexBoxOverlay
```

または、DLL を手動でダウンロードして配置：

1. https://www.nuget.org/packages/Be.Windows.Forms.HexBox/1.6.1 からパッケージをダウンロード
2. `.nupkg` ファイルを `.zip` にリネームして展開
3. 中の `lib\net40\Be.Windows.Forms.HexBox.dll` を以下へコピー：
   ```
   HexBoxProjects40v2\packages\Be.Windows.Forms.HexBox.1.6.1\lib\net40\
   ```

---

## アプローチ②はそのままビルド可能

`HexBoxForked` は NuGet 依存なし。復元不要でそのままビルドできます。

---

## 操作方法（共通）

| 操作 | 動作 |
|---|---|
| ドラッグ | 矩形選択 |
| Ctrl + ドラッグ | 複数矩形を追加選択 |
| 「選択クリア」| 全矩形選択を解除 |
| 「ファイルを開く」| バイナリファイルを読み込み |
| 「サンプルデータ」| PNG ヘッダ含む 512 バイトを読み込み |

---

## アプローチ①の制限事項

Be.HexBox の内部レイアウト（セル幅・行高さ）を定数で合わせているため、
**フォントや BytesPerLine を変更した場合は MainForm.cs の定数を要調整**：

```csharp
private const int HEX_AREA_LEFT  = 58;  // アドレス列幅
private const int CELL_WIDTH     = 26;  // 1バイトセルの幅
private const int LINE_HEIGHT    = 18;  // 1行の高さ
private const int FIRST_LINE_Y   = 4;   // 先頭行の上余白
```
