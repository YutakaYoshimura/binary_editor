using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace HexBoxForked.HexBox
{
    // =====================================================================
    //  選択モード
    // =====================================================================
    public enum HexSelectionMode { Linear, Rect }

    // =====================================================================
    //  HexBoxCore
    //  矩形選択をネイティブサポートする独自 HexBox コントロール。
    //  NuGet 依存なし / .NET Framework 4.0 / C# 4.0 対応
    // =====================================================================
    public class HexBoxCore : Control
    {
        // ---- レイアウト定数 ----
        private const int ADDRESS_W  = 80;
        private const int HEX_CELL_W = 28;
        private const int ASCII_W    = 10;
        private const int PAD_TOP    = 6;
        private const int PAD_LEFT   = 6;
        private const int HEADER_H   = 22;

        // ---- フィールド ----
        private byte[]   _data;
        private int      _bytesPerLine;
        private int      _lineHeight;
        private long     _scrollOffset;
        private int      _visibleLines;

        private long     _linearSelStart;
        private long     _linearSelLength;

        private readonly RectSelectionCollection _rectSels;
        private bool     _isRectDragging;
        private Point    _dragStart;
        private Point    _dragCurrent;

        private VScrollBar _vScroll;

        // ---- 色 ----
        private static readonly Color C_Bg        = Color.FromArgb(30,  30,  30);
        private static readonly Color C_Fg        = Color.FromArgb(200, 230, 200);
        private static readonly Color C_Addr      = Color.FromArgb(120, 140, 180);
        private static readonly Color C_Header    = Color.FromArgb(70,  70,  90);
        private static readonly Color C_Grid      = Color.FromArgb(55,  55,  65);
        private static readonly Color C_AltRow    = Color.FromArgb(36,  36,  44);
        private static readonly Color C_LinBg     = Color.FromArgb(80,  100, 180);
        private static readonly Color C_LinFg     = Color.White;
        private static readonly Color C_RectFill  = Color.FromArgb(70,  0,   190, 100);
        private static readonly Color C_RectBdr   = Color.FromArgb(200, 0,   220, 120);
        private static readonly Color C_DragFill  = Color.FromArgb(40,  0,   200, 255);
        private static readonly Color C_DragBdr   = Color.FromArgb(180, 0,   150, 220);
        private static readonly Color C_LabelBg   = Color.FromArgb(180, 0,   120, 60);

        // =====================================================================
        //  プロパティ
        // =====================================================================
        public HexSelectionMode SelectionMode { get; set; }

        public int BytesPerLine
        {
            get { return _bytesPerLine; }
            set { _bytesPerLine = Math.Max(1, value); Invalidate(); }
        }

        public byte[] Data
        {
            get { return _data; }
            set
            {
                _data         = (value != null) ? value : new byte[0];
                _scrollOffset = 0;
                _rectSels.Clear();
                UpdateScrollBar();
                Invalidate();
            }
        }

        public IList<RectSelection> RectSelections
        {
            get { return _rectSels.Items; }
        }

        public long LinearSelectionStart
        {
            get { return _linearSelStart; }
            set { _linearSelStart = value; Invalidate(); }
        }

        public long LinearSelectionLength
        {
            get { return _linearSelLength; }
            set { _linearSelLength = value; Invalidate(); }
        }

        // =====================================================================
        //  イベント
        // =====================================================================
        public event EventHandler<RectSelectionConfirmedArgs> RectSelectionConfirmed;

        // =====================================================================
        //  コンストラクタ
        // =====================================================================
        public HexBoxCore()
        {
            _data            = new byte[0];
            _bytesPerLine    = 16;
            _lineHeight      = 20;
            _scrollOffset    = 0;
            _linearSelStart  = -1;
            _linearSelLength = 0;
            _rectSels        = new RectSelectionCollection();
            SelectionMode    = HexSelectionMode.Rect;

            SetStyle(
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.AllPaintingInWmPaint  |
                ControlStyles.UserPaint             |
                ControlStyles.ResizeRedraw,
                true);

            BackColor = C_Bg;
            Font      = new Font("Courier New", 10f);

            _vScroll             = new VScrollBar();
            _vScroll.Dock        = DockStyle.Right;
            _vScroll.Minimum     = 0;
            _vScroll.Maximum     = 0;
            _vScroll.SmallChange = 1;
            _vScroll.LargeChange = 10;
            _vScroll.ValueChanged += new EventHandler(VScroll_ValueChanged);
            Controls.Add(_vScroll);

            FontChanged += new EventHandler(FontChanged_Handler);
            RecalcLayout();
        }

        // =====================================================================
        //  レイアウト
        // =====================================================================
        private void RecalcLayout()
        {
            using (Graphics g = CreateGraphics())
            {
                SizeF sz = g.MeasureString("W", Font);
                _lineHeight = (int)sz.Height + 4;
            }
            UpdateScrollBar();
            Invalidate();
        }

        private void UpdateScrollBar()
        {
            int totalLines = _bytesPerLine > 0
                ? (int)Math.Ceiling((double)_data.Length / _bytesPerLine) : 0;
            _visibleLines = _lineHeight > 0
                ? Math.Max(1, (ClientHeight - HEADER_H - PAD_TOP) / _lineHeight) : 1;
            _vScroll.Minimum     = 0;
            _vScroll.Maximum     = Math.Max(0, totalLines - _visibleLines);
            _vScroll.LargeChange = _visibleLines;
        }

        private int ClientHeight { get { return ClientSize.Height; } }
        private int ClientWidth  { get { return ClientSize.Width - _vScroll.Width; } }

        // =====================================================================
        //  描画
        // =====================================================================
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.None;
            g.Clear(C_Bg);

            if (_data.Length == 0)
            {
                using (Font ef = new Font(Font.FontFamily, 9f))
                    g.DrawString("データがありません。ファイルを開くかサンプルデータを読み込んでください。",
                        ef, Brushes.Gray, new PointF(10f, 40f));
                return;
            }

            DrawHeader(g);
            DrawRows(g);
            DrawRectSelections(g);
            DrawDragging(g);
        }

        private void DrawHeader(Graphics g)
        {
            using (SolidBrush hBg = new SolidBrush(C_Header))
                g.FillRectangle(hBg, 0, PAD_TOP, ClientWidth, HEADER_H);

            using (Font hf       = new Font(Font.FontFamily, Font.Size - 1f, FontStyle.Bold))
            using (SolidBrush fg = new SolidBrush(Color.LightGray))
            {
                g.DrawString("Offset", hf, fg, new PointF(PAD_LEFT, PAD_TOP + 3));
                for (int col = 0; col < _bytesPerLine; col++)
                    g.DrawString(col.ToString("X2"), hf, fg,
                        new PointF(ADDRESS_W + col * HEX_CELL_W, PAD_TOP + 3));
                float ax = ADDRESS_W + _bytesPerLine * HEX_CELL_W + 8;
                g.DrawString("ASCII", hf, fg, new PointF(ax, PAD_TOP + 3));
            }
        }

        private void DrawRows(Graphics g)
        {
            long firstOff = _scrollOffset;
            using (SolidBrush addrBr  = new SolidBrush(C_Addr))
            using (SolidBrush fgBr    = new SolidBrush(C_Fg))
            using (SolidBrush linBg   = new SolidBrush(C_LinBg))
            using (SolidBrush linFg   = new SolidBrush(C_LinFg))
            using (SolidBrush altBr   = new SolidBrush(C_AltRow))
            using (Pen        gridPen = new Pen(C_Grid))
            {
                for (int li = 0; li < _visibleLines + 1; li++)
                {
                    long lineOff = firstOff + (long)li * _bytesPerLine;
                    if (lineOff >= _data.Length) break;

                    int y = PAD_TOP + HEADER_H + li * _lineHeight;
                    if (li % 2 == 0)
                        g.FillRectangle(altBr, 0, y, ClientWidth, _lineHeight);

                    g.DrawString(lineOff.ToString("X8"), Font, addrBr,
                        new PointF(PAD_LEFT, y + 1));
                    g.DrawLine(gridPen, ADDRESS_W - 4, y, ADDRESS_W - 4, y + _lineHeight);

                    for (int col = 0; col < _bytesPerLine; col++)
                    {
                        long off = lineOff + col;
                        if (off >= _data.Length) break;
                        float x  = ADDRESS_W + col * HEX_CELL_W;
                        bool  ls = IsLinSel(off);
                        if (ls) g.FillRectangle(linBg, x - 1, y, HEX_CELL_W, _lineHeight);
                        g.DrawString(_data[off].ToString("X2"), Font,
                            ls ? linFg : fgBr, new PointF(x, y + 1));
                    }

                    float ascX = ADDRESS_W + _bytesPerLine * HEX_CELL_W + 8;
                    for (int col = 0; col < _bytesPerLine; col++)
                    {
                        long off = lineOff + col;
                        if (off >= _data.Length) break;
                        byte b = _data[off];
                        char c = (b >= 0x20 && b <= 0x7E) ? (char)b : '.';
                        g.DrawString(c.ToString(), Font, fgBr,
                            new PointF(ascX + col * ASCII_W, y + 1));
                    }
                }
            }
        }

        private void DrawRectSelections(Graphics g)
        {
            if (_rectSels.Count == 0) return;
            int startLine = (int)(_scrollOffset / _bytesPerLine);

            using (SolidBrush fillBr  = new SolidBrush(C_RectFill))
            using (SolidBrush lbBr    = new SolidBrush(C_LabelBg))
            using (SolidBrush lfBr    = new SolidBrush(Color.White))
            using (Font       lFont   = new Font(Font.FontFamily, 7.5f, FontStyle.Bold))
            {
                for (int si = 0; si < _rectSels.Count; si++)
                {
                    RectSelection sel = _rectSels.Items[si];

                    for (int row = sel.StartRow; row <= sel.EndRow; row++)
                    {
                        int dl = row - startLine;
                        if (dl < 0 || dl >= _visibleLines + 1) continue;

                        int   y  = PAD_TOP + HEADER_H + dl * _lineHeight;
                        float x0 = ADDRESS_W + sel.StartCol * HEX_CELL_W - 1;
                        float x1 = ADDRESS_W + (sel.EndCol + 1) * HEX_CELL_W - 1;

                        g.FillRectangle(fillBr,
                            new RectangleF(x0, y, x1 - x0, _lineHeight));

                        using (Pen p = new Pen(C_RectBdr, 1.5f))
                        {
                            if (row == sel.StartRow)
                                g.DrawLine(p, x0, y, x1, y);
                            if (row == sel.EndRow)
                                g.DrawLine(p, x0, y + _lineHeight, x1, y + _lineHeight);
                            g.DrawLine(p, x0, y, x0, y + _lineHeight);
                            g.DrawLine(p, x1, y, x1, y + _lineHeight);
                        }
                    }

                    // ラベル
                    int ldl = sel.StartRow - startLine;
                    if (ldl >= 0 && ldl < _visibleLines + 1)
                    {
                        int    ly     = PAD_TOP + HEADER_H + ldl * _lineHeight;
                        float  lx     = ADDRESS_W + sel.StartCol * HEX_CELL_W;
                        string label  = string.Format(
                            "[{0}] 0x{1:X4}～0x{2:X4} ({3}B, {4}行x{5}列)",
                            si + 1,
                            sel.FirstOffset(_bytesPerLine, _scrollOffset),
                            sel.LastOffset (_bytesPerLine, _scrollOffset),
                            sel.TotalBytes, sel.RowCount, sel.ColCount);
                        SizeF  lSz   = g.MeasureString(label, lFont);
                        float  lTop  = ly - lSz.Height - 1f;
                        if (lTop < PAD_TOP + HEADER_H) lTop = ly + _lineHeight;
                        RectangleF lr = new RectangleF(lx, lTop, lSz.Width + 4f, lSz.Height + 2f);
                        g.FillRectangle(lbBr, lr);
                        g.DrawString(label, lFont, lfBr, new PointF(lr.X + 2f, lr.Y + 1f));
                    }
                }
            }
        }

        private void DrawDragging(Graphics g)
        {
            if (!_isRectDragging) return;
            Rectangle dr = NormRect(_dragStart, _dragCurrent);
            using (SolidBrush df = new SolidBrush(C_DragFill))
            using (Pen        dp = new Pen(C_DragBdr, 1f))
            {
                dp.DashStyle = DashStyle.Dash;
                g.FillRectangle(df, dr);
                g.DrawRectangle(dp, dr);
            }
        }

        // =====================================================================
        //  マウス
        // =====================================================================
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            this.Focus();

            if (SelectionMode == HexSelectionMode.Rect)
            {
                _isRectDragging = true;
                _dragStart      = e.Location;
                _dragCurrent    = e.Location;
                if ((ModifierKeys & Keys.Control) == 0)
                    _rectSels.Clear();
                Invalidate();
            }
            else
            {
                long off = HitTest(e.Location);
                if (off >= 0) { _linearSelStart = off; _linearSelLength = 1; Invalidate(); }
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (!_isRectDragging || e.Button != MouseButtons.Left) return;
            _dragCurrent = e.Location;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (!_isRectDragging || e.Button != MouseButtons.Left) return;
            _isRectDragging = false;
            _dragCurrent    = e.Location;

            int r0, c0, r1, c1;
            PixelToRowCol(_dragStart,   out r0, out c0);
            PixelToRowCol(_dragCurrent, out r1, out c1);

            if (r0 >= 0 && c0 >= 0 && r1 >= 0 && c1 >= 0)
            {
                RectSelection sel = new RectSelection(r0, c0, r1, c1);
                _rectSels.Add(sel);
                if (RectSelectionConfirmed != null)
                    RectSelectionConfirmed(this,
                        new RectSelectionConfirmedArgs(sel, _bytesPerLine, _scrollOffset));
            }
            Invalidate();
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            int delta  = -(e.Delta / 120) * 3;
            int newVal = Math.Max(_vScroll.Minimum,
                         Math.Min(_vScroll.Maximum, _vScroll.Value + delta));
            _vScroll.Value = newVal;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            UpdateScrollBar();
            Invalidate();
        }

        // =====================================================================
        //  公開API
        // =====================================================================
        public void ClearRectSelections() { _rectSels.Clear(); Invalidate(); }

        public void RemoveRectSelection(int idx) { _rectSels.Remove(idx); Invalidate(); }

        // =====================================================================
        //  ユーティリティ
        // =====================================================================
        private bool IsLinSel(long offset)
        {
            if (_linearSelStart < 0 || _linearSelLength <= 0) return false;
            return offset >= _linearSelStart && offset < _linearSelStart + _linearSelLength;
        }

        private long HitTest(Point pt)
        {
            int row, col;
            PixelToRowCol(pt, out row, out col);
            if (row < 0 || col < 0) return -1L;
            long off = (long)row * _bytesPerLine + col;
            return off < _data.Length ? off : -1L;
        }

        private void PixelToRowCol(Point pt, out int row, out int col)
        {
            int startLine = (int)(_scrollOffset / _bytesPerLine);
            int relY = pt.Y - PAD_TOP - HEADER_H;
            int relX = pt.X - ADDRESS_W;
            if (relY < 0 || relX < 0) { row = -1; col = -1; return; }
            row = startLine + relY / _lineHeight;
            col = Math.Max(0, Math.Min(relX / HEX_CELL_W, _bytesPerLine - 1));
        }

        private static Rectangle NormRect(Point a, Point b)
        {
            return Rectangle.FromLTRB(
                Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
                Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
        }

        private void VScroll_ValueChanged(object sender, EventArgs e)
        {
            _scrollOffset = (long)_vScroll.Value * _bytesPerLine;
            Invalidate();
        }

        private void FontChanged_Handler(object sender, EventArgs e)
        {
            RecalcLayout();
        }
    }
}
