using System;
using System.Collections.Generic;

namespace HexBoxForked.HexBox
{
    // =====================================================================
    //  矩形選択データモデル (.NET Framework 4.0 / C# 4.0)
    // =====================================================================

    public class RectSelection
    {
        private readonly int _startRow;
        private readonly int _endRow;
        private readonly int _startCol;
        private readonly int _endCol;

        public int StartRow { get { return _startRow; } }
        public int EndRow   { get { return _endRow;   } }
        public int StartCol { get { return _startCol; } }
        public int EndCol   { get { return _endCol;   } }

        public RectSelection(int startRow, int startCol, int endRow, int endCol)
        {
            _startRow = Math.Min(startRow, endRow);
            _endRow   = Math.Max(startRow, endRow);
            _startCol = Math.Min(startCol, endCol);
            _endCol   = Math.Max(startCol, endCol);
        }

        public IEnumerable<long> GetOffsets(int bytesPerLine, long scrollOffset)
        {
            for (int row = _startRow; row <= _endRow; row++)
                for (int col = _startCol; col <= _endCol; col++)
                    yield return scrollOffset + (long)row * bytesPerLine + col;
        }

        public long FirstOffset(int bytesPerLine, long scrollOffset)
        {
            return scrollOffset + (long)_startRow * bytesPerLine + _startCol;
        }

        public long LastOffset(int bytesPerLine, long scrollOffset)
        {
            return scrollOffset + (long)_endRow * bytesPerLine + _endCol;
        }

        public int RowCount  { get { return _endRow - _startRow + 1; } }
        public int ColCount  { get { return _endCol - _startCol + 1; } }
        public int TotalBytes { get { return RowCount * ColCount;    } }

        public override string ToString()
        {
            return string.Format("Rows[{0}-{1}] Cols[{2}-{3}] ({4}bytes)",
                _startRow, _endRow, _startCol, _endCol, TotalBytes);
        }
    }

    public class RectSelectionCollection
    {
        private readonly List<RectSelection> _items;

        public RectSelectionCollection()
        {
            _items = new List<RectSelection>();
        }

        public IList<RectSelection> Items
        {
            get { return _items.AsReadOnly(); }
        }

        public int Count { get { return _items.Count; } }

        public void Add(RectSelection sel) { _items.Add(sel); }

        public void Clear() { _items.Clear(); }

        public bool Remove(int index)
        {
            if (index < 0 || index >= _items.Count) return false;
            _items.RemoveAt(index);
            return true;
        }

        public bool Contains(long offset, int bytesPerLine, long scrollOffset)
        {
            foreach (RectSelection sel in _items)
            {
                long rel = offset - scrollOffset;
                if (rel < 0) continue;
                int row = (int)(rel / bytesPerLine);
                int col = (int)(rel % bytesPerLine);
                if (row >= sel.StartRow && row <= sel.EndRow &&
                    col >= sel.StartCol && col <= sel.EndCol)
                    return true;
            }
            return false;
        }
    }

    public class RectSelectionConfirmedArgs : EventArgs
    {
        private readonly RectSelection _sel;
        private readonly int           _bpl;
        private readonly long          _scroll;

        public RectSelection Selection    { get { return _sel;    } }
        public int           BytesPerLine { get { return _bpl;    } }
        public long          ScrollOffset { get { return _scroll; } }

        public RectSelectionConfirmedArgs(RectSelection sel, int bpl, long scroll)
        {
            _sel    = sel;
            _bpl    = bpl;
            _scroll = scroll;
        }

        public string Summary
        {
            get
            {
                return string.Format(
                    "0x{0:X4}～0x{1:X4} ({2}bytes, {3}行×{4}列)",
                    _sel.FirstOffset(_bpl, _scroll),
                    _sel.LastOffset (_bpl, _scroll),
                    _sel.TotalBytes,
                    _sel.RowCount,
                    _sel.ColCount);
            }
        }
    }
}
