using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using HexBoxForked.HexBox;

namespace HexBoxForked
{
    /// <summary>
    /// アプローチ②：HexBoxCore（フォーク版）を使ったデモフォーム
    /// .NET Framework 4.0 / NuGet 依存なし
    /// </summary>
    public class MainForm : Form
    {
        private HexBoxCore _hexBox;
        private Panel      _sidePanel;
        private ListBox    _selList;
        private Label      _statusLabel;
        private ToolStrip  _toolStrip;
        private Label      _modeLabel;

        public MainForm()
        {
            InitializeComponent();
            LoadSampleData();
        }

        private void InitializeComponent()
        {
            this.Text          = "HexBox 矩形選択 - アプローチ② フォーク改修版 (.NET FW 4.0 / NuGet不要)";
            this.Size          = new Size(1200, 720);
            this.MinimumSize   = new Size(900, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font          = new Font("MS UI Gothic", 9f);

            // ---- ToolStrip ----
            _toolStrip      = new ToolStrip();
            _toolStrip.Dock = DockStyle.Top;

            ToolStripButton btnOpen = new ToolStripButton("ファイルを開く");
            btnOpen.Click += new EventHandler(BtnOpen_Click);

            ToolStripButton btnSample = new ToolStripButton("サンプルデータ");
            btnSample.Click += new EventHandler(BtnSample_Click);

            ToolStripButton btnClear = new ToolStripButton("選択クリア");
            btnClear.Click += new EventHandler(BtnClear_Click);

            ToolStripButton btnRect   = new ToolStripButton("[矩形] 矩形選択");
            ToolStripButton btnLinear = new ToolStripButton("[線形] 線形選択");
            btnRect.CheckOnClick   = true;
            btnLinear.CheckOnClick = true;
            btnRect.Checked        = true;

            btnRect.Click += delegate(object s, EventArgs e) {
                btnLinear.Checked     = false;
                btnRect.Checked       = true;
                _hexBox.SelectionMode = HexSelectionMode.Rect;
                _modeLabel.Text       = "モード: 矩形選択 | Ctrl+ドラッグで追加";
            };
            btnLinear.Click += delegate(object s, EventArgs e) {
                btnRect.Checked       = false;
                btnLinear.Checked     = true;
                _hexBox.SelectionMode = HexSelectionMode.Linear;
                _modeLabel.Text       = "モード: 線形選択";
            };

            _toolStrip.Items.Add(btnOpen);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnSample);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnClear);
            _toolStrip.Items.Add(new ToolStripSeparator());
            _toolStrip.Items.Add(btnRect);
            _toolStrip.Items.Add(btnLinear);

            // ---- HexBoxCore ----
            _hexBox               = new HexBoxCore();
            _hexBox.Dock          = DockStyle.Fill;
            _hexBox.BytesPerLine  = 16;
            _hexBox.SelectionMode = HexSelectionMode.Rect;
            _hexBox.RectSelectionConfirmed
                += new EventHandler<RectSelectionConfirmedArgs>(HexBox_RectSelectionConfirmed);

            // ---- サイドパネル ----
            _sidePanel           = new Panel();
            _sidePanel.Dock      = DockStyle.Right;
            _sidePanel.Width     = 320;
            _sidePanel.BackColor = Color.FromArgb(40, 40, 55);
            _sidePanel.Padding   = new Padding(8);

            Label lblTitle = new Label();
            lblTitle.Text      = "矩形選択リスト";
            lblTitle.Dock      = DockStyle.Top;
            lblTitle.ForeColor = Color.LightSkyBlue;
            lblTitle.Font      = new Font("MS UI Gothic", 10f, FontStyle.Bold);
            lblTitle.Height    = 30;

            _selList            = new ListBox();
            _selList.Dock       = DockStyle.Fill;
            _selList.BackColor  = Color.FromArgb(22, 22, 32);
            _selList.ForeColor  = Color.LightGreen;
            _selList.Font       = new Font("Courier New", 8f);
            _selList.BorderStyle= BorderStyle.None;

            Button btnRemove = new Button();
            btnRemove.Text      = "選択した項目を削除";
            btnRemove.Dock      = DockStyle.Bottom;
            btnRemove.Height    = 30;
            btnRemove.BackColor = Color.FromArgb(80, 30, 30);
            btnRemove.ForeColor = Color.White;
            btnRemove.FlatStyle = FlatStyle.Flat;
            btnRemove.Click    += new EventHandler(BtnRemove_Click);

            Label lblFeature = new Label();
            lblFeature.Text = "【フォーク版の特徴】\r\n"
                + "  真の矩形選択（行×列で管理）\r\n"
                + "  非連続バイトも正確に選択可能\r\n"
                + "  矩形ごとの行数・列数を表示\r\n"
                + "  線形/矩形をモード切替で共存\r\n"
                + "  スクロールに追従して描画\r\n"
                + "  NuGet パッケージ依存なし";
            lblFeature.Dock      = DockStyle.Bottom;
            lblFeature.Height    = 120;
            lblFeature.ForeColor = Color.LightYellow;
            lblFeature.Font      = new Font("MS UI Gothic", 8f);
            lblFeature.Padding   = new Padding(4);

            _sidePanel.Controls.Add(_selList);
            _sidePanel.Controls.Add(lblTitle);
            _sidePanel.Controls.Add(btnRemove);
            _sidePanel.Controls.Add(lblFeature);

            // ---- ステータスバー ----
            _statusLabel           = new Label();
            _statusLabel.Dock      = DockStyle.Bottom;
            _statusLabel.Height    = 24;
            _statusLabel.BackColor = Color.FromArgb(0, 80, 0);
            _statusLabel.ForeColor = Color.White;
            _statusLabel.Font      = new Font("Courier New", 8.5f);
            _statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            _statusLabel.Padding   = new Padding(8, 0, 0, 0);
            _statusLabel.Text      = "ドラッグして矩形選択。Ctrl+ドラッグで複数追加。";

            // ---- モードラベル ----
            Panel modeBar = new Panel();
            modeBar.Dock      = DockStyle.Bottom;
            modeBar.Height    = 24;
            modeBar.BackColor = Color.FromArgb(30, 50, 30);

            _modeLabel          = new Label();
            _modeLabel.Text     = "モード: 矩形選択 | Ctrl+ドラッグで追加";
            _modeLabel.AutoSize = true;
            _modeLabel.ForeColor= Color.LightGreen;
            _modeLabel.Font     = new Font("MS UI Gothic", 8.5f);
            _modeLabel.Location = new Point(10, 4);
            modeBar.Controls.Add(_modeLabel);

            this.Controls.Add(_hexBox);
            this.Controls.Add(_sidePanel);
            this.Controls.Add(modeBar);
            this.Controls.Add(_statusLabel);
            this.Controls.Add(_toolStrip);
        }

        // ---- イベントハンドラ ----
        private void HexBox_RectSelectionConfirmed(object sender, RectSelectionConfirmedArgs e)
        {
            string item = string.Format("[{0}] {1}",
                _selList.Items.Count + 1, e.Summary);
            _selList.Items.Add(item);
            _selList.SelectedIndex = _selList.Items.Count - 1;
            _statusLabel.Text = "矩形選択確定: " + e.Summary;
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title  = "バイナリファイルを開く";
            dlg.Filter = "すべてのファイル (*.*)|*.*";
            if (dlg.ShowDialog() != DialogResult.OK) return;
            try
            {
                _hexBox.Data = File.ReadAllBytes(dlg.FileName);
                _selList.Items.Clear();
                _statusLabel.Text = string.Format("読込: {0}  ({1:N0} bytes)",
                    dlg.FileName, _hexBox.Data.Length);
            }
            catch (Exception ex)
            {
                MessageBox.Show("読込エラー:\n" + ex.Message, "エラー",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSample_Click(object sender, EventArgs e) { LoadSampleData(); }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            _hexBox.ClearRectSelections();
            _selList.Items.Clear();
            _statusLabel.Text = "矩形選択をすべてクリアしました";
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            int idx = _selList.SelectedIndex;
            if (idx < 0) return;
            _hexBox.RemoveRectSelection(idx);
            _selList.Items.RemoveAt(idx);
        }

        private void LoadSampleData()
        {
            byte[] data = new byte[512];
            data[0]  = 0x89; data[1]  = 0x50; data[2]  = 0x4E; data[3]  = 0x47;
            data[4]  = 0x0D; data[5]  = 0x0A; data[6]  = 0x1A; data[7]  = 0x0A;
            data[8]  = 0x00; data[9]  = 0x00; data[10] = 0x00; data[11] = 0x0D;
            data[12] = 0x49; data[13] = 0x48; data[14] = 0x44; data[15] = 0x52;
            for (int i = 16; i < data.Length; i++) data[i] = (byte)(i & 0xFF);

            _hexBox.Data = data;
            if (_selList     != null) _selList.Items.Clear();
            if (_statusLabel != null)
                _statusLabel.Text = string.Format(
                    "サンプルデータ ({0}bytes)。ドラッグで矩形選択してください。",
                    data.Length);
        }
    }
}
