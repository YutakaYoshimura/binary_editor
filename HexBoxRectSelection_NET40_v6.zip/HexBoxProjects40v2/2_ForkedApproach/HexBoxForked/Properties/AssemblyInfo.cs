using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HexBoxForked")]
[assembly: AssemblyDescription("HexBox 矩形選択 - フォーク改修版")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HexBoxForked")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b2c3d4e5-f6a7-8901-bcde-f12345678901")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
