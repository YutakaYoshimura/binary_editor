namespace HexBoxDemo
{
    partial class FormMain
    {
        private System.ComponentModel.IContainer components = null;

        // ── コントロール宣言 ──────────────────────────────
        private System.Windows.Forms.Panel          _panelHex;
        private System.Windows.Forms.GroupBox       _grpHex;
        private System.Windows.Forms.GroupBox       _grpStatus;
        private System.Windows.Forms.GroupBox       _grpButtons;
        private System.Windows.Forms.GroupBox       _grpHexView;

        private System.Windows.Forms.Label          _lblTitle;
        private System.Windows.Forms.Label          _lblByteCountCaption;
        private System.Windows.Forms.Label          _lblByteCount;
        private System.Windows.Forms.Label          _lblLimit;
        private System.Windows.Forms.Label          _lblHexViewCaption;
        private System.Windows.Forms.TextBox        _txtHexView;
        private System.Windows.Forms.ProgressBar    _progressBytes;

        private System.Windows.Forms.Button         _btnClear;
        private System.Windows.Forms.Button         _btnFill;
        private System.Windows.Forms.Button         _btnCopy;
        private System.Windows.Forms.Button         _btnDetail;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components          = new System.ComponentModel.Container();
            this._panelHex           = new System.Windows.Forms.Panel();
            this._grpHex             = new System.Windows.Forms.GroupBox();
            this._grpStatus          = new System.Windows.Forms.GroupBox();
            this._grpButtons         = new System.Windows.Forms.GroupBox();
            this._grpHexView         = new System.Windows.Forms.GroupBox();
            this._lblTitle           = new System.Windows.Forms.Label();
            this._lblByteCountCaption= new System.Windows.Forms.Label();
            this._lblByteCount       = new System.Windows.Forms.Label();
            this._lblLimit           = new System.Windows.Forms.Label();
            this._txtHexView         = new System.Windows.Forms.TextBox();
            this._progressBytes      = new System.Windows.Forms.ProgressBar();
            this._btnClear           = new System.Windows.Forms.Button();
            this._btnFill            = new System.Windows.Forms.Button();
            this._btnCopy            = new System.Windows.Forms.Button();
            this._btnDetail          = new System.Windows.Forms.Button();

            this._grpHex.SuspendLayout();
            this._grpStatus.SuspendLayout();
            this._grpButtons.SuspendLayout();
            this._grpHexView.SuspendLayout();
            this.SuspendLayout();

            // ── _lblTitle ──────────────────────────────────
            this._lblTitle.Text      = "HexBox 入力制限デモ　（1行 × 8バイト = 最大8バイト）";
            this._lblTitle.Font      = new System.Drawing.Font("Meiryo UI", 11f, System.Drawing.FontStyle.Bold);
            this._lblTitle.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this._lblTitle.AutoSize  = false;
            this._lblTitle.Location  = new System.Drawing.Point(12, 12);
            this._lblTitle.Size      = new System.Drawing.Size(640, 28);
            this._lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // ── _grpHex ────────────────────────────────────
            this._grpHex.Text     = "HEX 入力エリア";
            this._grpHex.Font     = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this._grpHex.Location = new System.Drawing.Point(12, 48);
            this._grpHex.Size     = new System.Drawing.Size(648, 110);
            this._grpHex.Controls.Add(this._panelHex);

            // ── _panelHex ──────────────────────────────────
            this._panelHex.Dock    = System.Windows.Forms.DockStyle.Fill;
            this._panelHex.Padding = new System.Windows.Forms.Padding(8, 6, 8, 6);

            // ── _grpStatus ─────────────────────────────────
            this._grpStatus.Text     = "入力状況";
            this._grpStatus.Font     = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this._grpStatus.Location = new System.Drawing.Point(12, 168);
            this._grpStatus.Size     = new System.Drawing.Size(648, 90);

            // _lblByteCountCaption
            this._lblByteCountCaption.Text      = "バイト数:";
            this._lblByteCountCaption.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._lblByteCountCaption.Location  = new System.Drawing.Point(12, 24);
            this._lblByteCountCaption.Size      = new System.Drawing.Size(64, 20);
            this._lblByteCountCaption.AutoSize  = false;

            // _lblByteCount
            this._lblByteCount.Text      = "0 / 8 バイト";
            this._lblByteCount.Font      = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this._lblByteCount.Location  = new System.Drawing.Point(80, 24);
            this._lblByteCount.Size      = new System.Drawing.Size(160, 20);
            this._lblByteCount.AutoSize  = false;

            // _progressBytes
            this._progressBytes.Location = new System.Drawing.Point(12, 50);
            this._progressBytes.Size     = new System.Drawing.Size(420, 18);
            this._progressBytes.Minimum  = 0;
            this._progressBytes.Maximum  = 8;
            this._progressBytes.Value    = 0;
            this._progressBytes.Style    = System.Windows.Forms.ProgressBarStyle.Continuous;

            // _lblLimit
            this._lblLimit.Text      = "残り 8 バイト入力できます";
            this._lblLimit.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._lblLimit.ForeColor = System.Drawing.Color.DarkGreen;
            this._lblLimit.Location  = new System.Drawing.Point(440, 50);
            this._lblLimit.Size      = new System.Drawing.Size(196, 20);
            this._lblLimit.AutoSize  = false;

            this._grpStatus.Controls.Add(this._lblByteCountCaption);
            this._grpStatus.Controls.Add(this._lblByteCount);
            this._grpStatus.Controls.Add(this._progressBytes);
            this._grpStatus.Controls.Add(this._lblLimit);

            // ── _grpHexView ────────────────────────────────
            this._grpHexView.Text     = "現在の入力内容（16進数）";
            this._grpHexView.Font     = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this._grpHexView.Location = new System.Drawing.Point(12, 268);
            this._grpHexView.Size     = new System.Drawing.Size(648, 60);

            this._txtHexView.Font       = new System.Drawing.Font("Courier New", 10f);
            this._txtHexView.Location   = new System.Drawing.Point(12, 22);
            this._txtHexView.Size       = new System.Drawing.Size(620, 24);
            this._txtHexView.ReadOnly   = true;
            this._txtHexView.BackColor  = System.Drawing.Color.FromArgb(245, 245, 255);
            this._txtHexView.Text       = "（未入力）";
            this._txtHexView.BorderStyle= System.Windows.Forms.BorderStyle.Fixed3D;

            this._grpHexView.Controls.Add(this._txtHexView);

            // ── _grpButtons ────────────────────────────────
            this._grpButtons.Text     = "操作";
            this._grpButtons.Font     = new System.Drawing.Font("Meiryo UI", 9f, System.Drawing.FontStyle.Bold);
            this._grpButtons.Location = new System.Drawing.Point(12, 338);
            this._grpButtons.Size     = new System.Drawing.Size(648, 60);

            // _btnClear
            this._btnClear.Text      = "🗑 クリア";
            this._btnClear.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._btnClear.Location  = new System.Drawing.Point(12, 22);
            this._btnClear.Size      = new System.Drawing.Size(110, 28);
            this._btnClear.BackColor = System.Drawing.Color.FromArgb(255, 235, 235);
            this._btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnClear.Click    += new System.EventHandler(this.BtnClear_Click);

            // _btnFill
            this._btnFill.Text      = "📋 サンプル入力";
            this._btnFill.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._btnFill.Location  = new System.Drawing.Point(130, 22);
            this._btnFill.Size      = new System.Drawing.Size(130, 28);
            this._btnFill.BackColor = System.Drawing.Color.FromArgb(235, 245, 255);
            this._btnFill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnFill.Click    += new System.EventHandler(this.BtnFill_Click);

            // _btnCopy
            this._btnCopy.Text      = "📄 クリップボードへコピー";
            this._btnCopy.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._btnCopy.Location  = new System.Drawing.Point(268, 22);
            this._btnCopy.Size      = new System.Drawing.Size(180, 28);
            this._btnCopy.BackColor = System.Drawing.Color.FromArgb(235, 255, 235);
            this._btnCopy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnCopy.Click    += new System.EventHandler(this.BtnCopy_Click);

            // _btnDetail
            this._btnDetail.Text      = "🔍 データ詳細";
            this._btnDetail.Font      = new System.Drawing.Font("Meiryo UI", 9f);
            this._btnDetail.Location  = new System.Drawing.Point(456, 22);
            this._btnDetail.Size      = new System.Drawing.Size(120, 28);
            this._btnDetail.BackColor = System.Drawing.Color.FromArgb(255, 250, 220);
            this._btnDetail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._btnDetail.Click    += new System.EventHandler(this.BtnDetail_Click);

            this._grpButtons.Controls.Add(this._btnClear);
            this._grpButtons.Controls.Add(this._btnFill);
            this._grpButtons.Controls.Add(this._btnCopy);
            this._grpButtons.Controls.Add(this._btnDetail);

            // ── FormMain ───────────────────────────────────
            this.Text            = "HexBox 入力制限デモ";
            this.Font            = new System.Drawing.Font("Meiryo UI", 9f);
            this.ClientSize      = new System.Drawing.Size(676, 414);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor       = System.Drawing.Color.FromArgb(248, 248, 252);

            this.Controls.Add(this._lblTitle);
            this.Controls.Add(this._grpHex);
            this.Controls.Add(this._grpStatus);
            this.Controls.Add(this._grpHexView);
            this.Controls.Add(this._grpButtons);

            this._grpHex.ResumeLayout(false);
            this._grpStatus.ResumeLayout(false);
            this._grpButtons.ResumeLayout(false);
            this._grpHexView.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
