using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TreeViewIconMethodsSample
{
    /// <summary>
    /// 「1ノードに複数アイコン/状態を表示する」方法のうち、
    /// ① StateImageList と ② オーナードロー(バッジ重ね) の2つを、
    /// 実運用に近いツリー構造(自局配下の機器構成)で比較できるサンプル。
    /// </summary>
    public class MainForm : Form
    {
        // 状態を表す文字列の定数
        private const string StateOk = "ok";
        private const string StateWarning = "warning";
        private const string StateError = "error";

        public MainForm()
        {
            Text = "TreeNode 複数アイコン表示 - 方法比較サンプル";
            Width = 480;
            Height = 560;
            StartPosition = FormStartPosition.CenterScreen;

            TabControl tabs = new TabControl();
            tabs.Dock = DockStyle.Fill;
            tabs.TabPages.Add(BuildStateImageListTab());
            tabs.TabPages.Add(BuildOwnerDrawBadgeTab());
            Controls.Add(tabs);
        }

        // ------------------------------------------------------------
        // 方法1: StateImageList (メインアイコンの左に状態アイコンを表示)
        // ------------------------------------------------------------
        private TabPage BuildStateImageListTab()
        {
            TabPage page = new TabPage("① StateImageList");

            ImageList mainImages = new ImageList();
            mainImages.ImageSize = new Size(16, 16);
            mainImages.ColorDepth = ColorDepth.Depth32Bit;
            mainImages.Images.Add(IconFactory.FolderClosed()); // 0: フォルダー(自局/アダプタ/スキャナ/機器A/機器B)
            mainImages.Images.Add(IconFactory.File());          // 1: 個別項目(受信/タブ/送信)

            // StateImageList は index=0 が「状態なし」として扱われる点に注意。
            // 実際に状態を表す画像は index=1 以降を使う。
            ImageList stateImages = new ImageList();
            stateImages.ImageSize = new Size(16, 16);
            stateImages.ColorDepth = ColorDepth.Depth32Bit;
            stateImages.Images.Add(new Bitmap(16, 16));            // 0: 状態なし(透明)
            stateImages.Images.Add(IconFactory.CheckCircle());     // 1: 正常
            stateImages.Images.Add(IconFactory.WarningTriangle()); // 2: 警告
            stateImages.Images.Add(IconFactory.ErrorCircle());     // 3: エラー

            TreeView tree = new TreeView();
            tree.Dock = DockStyle.Fill;
            tree.ImageList = mainImages;
            tree.StateImageList = stateImages;

            Dictionary<TreeNode, string> states;
            TreeNode root = BuildSampleHierarchy(out states);

            ApplyStateImageIndexRecursive(root, states);
            tree.Nodes.Add(root);
            tree.ExpandAll();

            page.Controls.Add(tree);
            page.Controls.Add(Note(
                "メインアイコンの左側に「状態アイコン」がもう1つ並びます。\n" +
                "node.StateImageIndex を切り替えるだけで実装できて手軽ですが、\n" +
                "表示位置は固定(左側)でカスタマイズ性は低めです。"));
            return page;
        }

        private static void ApplyStateImageIndexRecursive(TreeNode node, Dictionary<TreeNode, string> states)
        {
            string state;
            if (states.TryGetValue(node, out state))
            {
                if (state == StateOk) node.StateImageIndex = 1;
                else if (state == StateWarning) node.StateImageIndex = 2;
                else if (state == StateError) node.StateImageIndex = 3;
                else node.StateImageIndex = 0;
            }
            else
            {
                node.StateImageIndex = 0;
            }

            foreach (TreeNode child in node.Nodes)
            {
                ApplyStateImageIndexRecursive(child, states);
            }
        }

        // ------------------------------------------------------------
        // 方法2: オーナードローでバッジ(小アイコン)を重ねて表示
        // ------------------------------------------------------------
        private TabPage BuildOwnerDrawBadgeTab()
        {
            TabPage page = new TabPage("② オーナードロー(バッジ重ね)");

            ImageList images = new ImageList();
            images.ImageSize = new Size(16, 16);
            images.ColorDepth = ColorDepth.Depth32Bit;
            images.Images.Add(IconFactory.FolderClosed()); // 0
            images.Images.Add(IconFactory.File());          // 1

            Image badgeOk = IconFactory.CheckCircle(10);
            Image badgeWarn = IconFactory.WarningTriangle(10);
            Image badgeError = IconFactory.ErrorCircle(10);

            TreeView tree = new TreeView();
            tree.Dock = DockStyle.Fill;
            tree.ImageList = images;
            tree.DrawMode = TreeViewDrawMode.OwnerDrawText;

            Dictionary<TreeNode, string> states;
            TreeNode root = BuildSampleHierarchy(out states);

            ApplyTagRecursive(root, states);
            tree.Nodes.Add(root);
            tree.ExpandAll();

            tree.DrawNode += delegate (object s, DrawTreeNodeEventArgs e)
            {
                e.DrawDefault = true; // アイコン・テキストは標準描画に任せる

                string tag = e.Node != null ? e.Node.Tag as string : null;
                Image badge = null;
                if (tag == StateOk) badge = badgeOk;
                else if (tag == StateWarning) badge = badgeWarn;
                else if (tag == StateError) badge = badgeError;

                if (badge != null)
                {
                    // メインアイコンはテキスト領域(e.Bounds)の左側、幅16px+余白で描画されている
                    int iconLeft = e.Bounds.Left - 18;
                    int x = iconLeft + 16 - badge.Width + 2;
                    int y = e.Bounds.Top + 16 - badge.Height + 2;
                    e.Graphics.DrawImage(badge, x, y, badge.Width, badge.Height);
                }
            };

            page.Controls.Add(tree);
            page.Controls.Add(Note(
                "DrawMode = OwnerDrawText にして DrawNode イベント内で標準描画の上から\n" +
                "小さいバッジ画像を重ねています。位置・個数を自由に決められるため\n" +
                "最も柔軟ですが、描画コードは自分で書く必要があります。"));
            return page;
        }

        private static void ApplyTagRecursive(TreeNode node, Dictionary<TreeNode, string> states)
        {
            string state;
            if (states.TryGetValue(node, out state))
            {
                node.Tag = state;
            }

            foreach (TreeNode child in node.Nodes)
            {
                ApplyTagRecursive(child, states);
            }
        }

        // ------------------------------------------------------------
        // ツリー構造の組み立て(2つのタブで共通)
        //
        // 自局
        // ┣アダプタ
        // ┃┣受信01
        // ┃┗受信02
        // ┣タブ
        // ┗スキャナ
        //   ┣機器A
        //   ┃┣機器A-送信01
        //   ┃┗機器A-送信02
        //   ┗機器B
        //     ┣機器B-送信01
        //     ┗機器B-送信02
        // ------------------------------------------------------------
        private TreeNode BuildSampleHierarchy(out Dictionary<TreeNode, string> states)
        {
            states = new Dictionary<TreeNode, string>();

            TreeNode root = MakeNode("自局", true);

            TreeNode adapter = MakeNode("アダプタ", true);
            TreeNode rx1 = MakeNode("受信01", false);
            TreeNode rx2 = MakeNode("受信02", false);
            states[rx1] = StateOk;
            states[rx2] = StateWarning;
            adapter.Nodes.Add(rx1);
            adapter.Nodes.Add(rx2);

            TreeNode tab = MakeNode("タブ", false);
            states[tab] = StateOk;

            TreeNode scanner = MakeNode("スキャナ", true);

            TreeNode deviceA = MakeNode("機器A", true);
            TreeNode aTx1 = MakeNode("機器A-送信01", false);
            TreeNode aTx2 = MakeNode("機器A-送信02", false);
            states[aTx1] = StateOk;
            states[aTx2] = StateError;
            deviceA.Nodes.Add(aTx1);
            deviceA.Nodes.Add(aTx2);

            TreeNode deviceB = MakeNode("機器B", true);
            TreeNode bTx1 = MakeNode("機器B-送信01", false);
            TreeNode bTx2 = MakeNode("機器B-送信02", false);
            states[bTx1] = StateOk;
            states[bTx2] = StateWarning;
            deviceB.Nodes.Add(bTx1);
            deviceB.Nodes.Add(bTx2);

            scanner.Nodes.Add(deviceA);
            scanner.Nodes.Add(deviceB);

            root.Nodes.Add(adapter);
            root.Nodes.Add(tab);
            root.Nodes.Add(scanner);

            return root;
        }

        private static TreeNode MakeNode(string text, bool isFolder)
        {
            TreeNode node = new TreeNode(text);
            node.ImageIndex = isFolder ? 0 : 1;
            node.SelectedImageIndex = isFolder ? 0 : 1;
            return node;
        }

        private static Label Note(string text)
        {
            Label label = new Label();
            label.Dock = DockStyle.Bottom;
            label.Height = 70;
            label.Text = text;
            label.ForeColor = Color.DimGray;
            label.Padding = new Padding(6);
            return label;
        }
    }
}
