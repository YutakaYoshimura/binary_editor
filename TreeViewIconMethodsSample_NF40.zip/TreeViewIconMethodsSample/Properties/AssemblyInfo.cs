using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TreeViewIconMethodsSample")]
[assembly: AssemblyDescription("TreeNode 複数アイコン表示 - 方法比較サンプル (.NET Framework 4.0)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TreeViewIconMethodsSample")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("a07e03e2-e833-4dd6-be92-7b2088d75952")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
