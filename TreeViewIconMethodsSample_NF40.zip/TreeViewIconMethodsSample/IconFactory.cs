using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace TreeViewIconMethodsSample
{
    /// <summary>
    /// 外部の画像ファイルを使わず、コードだけで16x16のサンプルアイコンを生成するヘルパー。
    /// 実際のプロジェクトでは png/ico ファイルを Image.FromFile 等で読み込んでも同じ仕組みで使えます。
    /// </summary>
    internal static class IconFactory
    {
        public static Bitmap FolderClosed()
        {
            return DrawFolder(false);
        }

        public static Bitmap FolderOpen()
        {
            return DrawFolder(true);
        }

        public static Bitmap File()
        {
            Bitmap bmp = New();
            using (Graphics g = Gfx(bmp))
            {
                Rectangle body = new Rectangle(3, 1, 10, 14);
                g.FillRectangle(Brushes.WhiteSmoke, body);
                g.DrawRectangle(Pens.Gray, body);
                using (Pen linePen = new Pen(Color.LightSlateGray))
                {
                    for (int y = 4; y <= 11; y += 3)
                    {
                        g.DrawLine(linePen, 5, y, 11, y);
                    }
                }
            }
            return bmp;
        }

        public static Bitmap Star(int size = 16)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Gfx(bmp))
            {
                float c = size / 2f;
                PointF[] pts = StarPoints(new PointF(c, c), c - 1, (c - 1) / 2.2f);
                g.FillPolygon(Brushes.Gold, pts);
                g.DrawPolygon(Pens.DarkGoldenrod, pts);
            }
            return bmp;
        }

        public static Bitmap WarningTriangle(int size = 16)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Gfx(bmp))
            {
                PointF[] tri = new PointF[]
                {
                    new PointF(size / 2f, 1),
                    new PointF(size - 1, size - 2),
                    new PointF(1, size - 2)
                };
                g.FillPolygon(Brushes.Gold, tri);
                g.DrawPolygon(Pens.DarkOrange, tri);
                if (size >= 14)
                {
                    using (Font font = new Font("Arial", size * 0.5f, FontStyle.Bold))
                    {
                        g.DrawString("!", font, Brushes.Black, size * 0.34f, size * 0.28f);
                    }
                }
            }
            return bmp;
        }

        public static Bitmap CheckCircle(int size = 16)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Gfx(bmp))
            {
                g.FillEllipse(Brushes.MediumSeaGreen, 0, 0, size - 1, size - 1);
                using (Pen pen = new Pen(Color.White, 2f))
                {
                    PointF[] check = new PointF[]
                    {
                        new PointF(size * 0.25f, size * 0.52f),
                        new PointF(size * 0.42f, size * 0.72f),
                        new PointF(size * 0.78f, size * 0.28f)
                    };
                    g.DrawLines(pen, check);
                }
            }
            return bmp;
        }

        public static Bitmap ErrorCircle(int size = 16)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Gfx(bmp))
            {
                g.FillEllipse(Brushes.IndianRed, 0, 0, size - 1, size - 1);
                using (Pen pen = new Pen(Color.White, 2f))
                {
                    g.DrawLine(pen, size * 0.28f, size * 0.28f, size * 0.72f, size * 0.72f);
                    g.DrawLine(pen, size * 0.72f, size * 0.28f, size * 0.28f, size * 0.72f);
                }
            }
            return bmp;
        }

        public static Bitmap SyncArrows(int size = 16)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Gfx(bmp))
            {
                using (Pen pen = new Pen(Color.SteelBlue, 2f))
                {
                    pen.EndCap = LineCap.ArrowAnchor;
                    g.DrawArc(pen, 1, 1, size - 3, size - 3, -30, 200);
                    g.DrawArc(pen, 1, 1, size - 3, size - 3, 150, 200);
                }
            }
            return bmp;
        }

        /// <summary>
        /// ベースアイコンの右下に小さいバッジ画像を重ねて1枚に合成する。
        /// 「事前合成アイコン」方式と、オーナードローでのリアルタイム合成の両方で利用できる。
        /// </summary>
        public static Bitmap Overlay(Image baseIcon, Image badge, int badgeSize = 9)
        {
            Bitmap bmp = new Bitmap(baseIcon.Width, baseIcon.Height);
            using (Graphics g = Gfx(bmp))
            {
                g.DrawImage(baseIcon, 0, 0);
                int x = baseIcon.Width - badgeSize;
                int y = baseIcon.Height - badgeSize;
                g.DrawImage(badge, x, y, badgeSize, badgeSize);
            }
            return bmp;
        }

        // ---- 内部ヘルパー ----

        private static Bitmap New()
        {
            return new Bitmap(16, 16);
        }

        private static Graphics Gfx(Bitmap bmp)
        {
            Graphics g = Graphics.FromImage(bmp);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            return g;
        }

        private static Bitmap DrawFolder(bool open)
        {
            Bitmap bmp = New();
            using (Graphics g = Gfx(bmp))
            {
                Color body = Color.FromArgb(255, 222, 170, 60);
                Color tab = Color.FromArgb(255, 200, 145, 40);
                using (SolidBrush tabBrush = new SolidBrush(tab))
                {
                    g.FillRectangle(tabBrush, 1, 3, 6, 3);
                }

                if (open)
                {
                    PointF[] outerFlap = new PointF[]
                    {
                        new PointF(1, 6), new PointF(15, 6), new PointF(13, 14), new PointF(0, 14)
                    };
                    PointF[] innerFlap = new PointF[]
                    {
                        new PointF(2, 5), new PointF(14, 5), new PointF(12, 11), new PointF(2, 11)
                    };
                    using (SolidBrush bodyBrush = new SolidBrush(body))
                    {
                        g.FillPolygon(bodyBrush, outerFlap);
                    }
                    using (SolidBrush lightBrush = new SolidBrush(Color.FromArgb(255, 245, 200, 100)))
                    {
                        g.FillPolygon(lightBrush, innerFlap);
                    }
                }
                else
                {
                    using (SolidBrush bodyBrush = new SolidBrush(body))
                    {
                        g.FillRectangle(bodyBrush, 1, 6, 14, 8);
                    }
                }
                g.DrawRectangle(Pens.SaddleBrown, 0, 5, 15, 9);
            }
            return bmp;
        }

        private static PointF[] StarPoints(PointF center, float outerR, float innerR)
        {
            PointF[] pts = new PointF[10];
            for (int i = 0; i < 10; i++)
            {
                double angle = Math.PI / 2 * 3 + i * Math.PI / 5;
                float r = (i % 2 == 0) ? outerR : innerR;
                pts[i] = new PointF(center.X + r * (float)Math.Cos(angle), center.Y + r * (float)Math.Sin(angle));
            }
            return pts;
        }
    }
}
