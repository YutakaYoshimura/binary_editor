namespace CustomHexBoxProject
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this._toolStrip  = new System.Windows.Forms.ToolStrip();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._statusLabel = new System.Windows.Forms.ToolStripStatusLabel();

            // ToolStrip
            var lblDelete = new System.Windows.Forms.ToolStripLabel("Deleteモード:");
            var btnFillZero = new System.Windows.Forms.ToolStripButton("FillZero");
            var btnShrink   = new System.Windows.Forms.ToolStripButton("Shrink");
            var sep1        = new System.Windows.Forms.ToolStripSeparator();
            var lblPaste    = new System.Windows.Forms.ToolStripLabel("Pasteモード:");
            var btnOverwrite= new System.Windows.Forms.ToolStripButton("Overwrite");
            var btnInsert   = new System.Windows.Forms.ToolStripButton("Insert");

            btnFillZero.Click  += btnDeleteFillZero_Click;
            btnShrink.Click    += btnDeleteShrink_Click;
            btnOverwrite.Click += btnPasteOverwrite_Click;
            btnInsert.Click    += btnPasteInsert_Click;

            this._toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[]
            {
                lblDelete, btnFillZero, btnShrink,
                sep1,
                lblPaste, btnOverwrite, btnInsert
            });

            // StatusStrip
            this._statusLabel.Text = "準備完了";
            this._statusStrip.Items.Add(this._statusLabel);

            // Form
            this.SuspendLayout();
            this.Controls.Add(this._toolStrip);
            this.Controls.Add(this._statusStrip);
            this.ClientSize = new System.Drawing.Size(900, 600);
            this.Text       = "CustomHexBox サンプル";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
