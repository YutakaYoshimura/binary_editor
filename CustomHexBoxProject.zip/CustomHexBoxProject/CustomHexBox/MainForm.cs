using System;
using System.Windows.Forms;
using Be.Windows.Forms;
using CustomHexBoxProject.Events;
using CustomHexBoxProject.Strategies.Delete;
using CustomHexBoxProject.Strategies.Paste;

namespace CustomHexBoxProject
{
    /// <summary>
    /// CustomHexBoxを使用したメインフォームのサンプル実装。
    /// </summary>
    public partial class MainForm : Form
    {
        private CustomHexBox _hexBox;
        private ToolStrip    _toolStrip;
        private StatusStrip  _statusStrip;
        private ToolStripStatusLabel _statusLabel;

        public MainForm()
        {
            InitializeComponent();
            InitializeCustomHexBox();
            LoadSampleData();
        }

        // ============================================================
        // CustomHexBoxの初期化
        // ============================================================

        private void InitializeCustomHexBox()
        {
            _hexBox = new CustomHexBox
            {
                Dock            = DockStyle.Fill,
                Font            = new System.Drawing.Font("Courier New", 9F),
                LineInfoVisible = true,
                StringViewVisible = true,
                VScrollBarVisible = true,

                // --- 動作モードの設定 ---
                DeleteBehavior = DeleteMode.FillZero,   // 0x00で埋める
                PasteBehavior  = PasteMode.Overwrite,   // 上書きペースト
            };

            // --- イベントの登録 ---

            // Delete前の確認（大量削除時に警告）
            _hexBox.BeforeDelete += HexBox_BeforeDelete;

            // Delete後のステータス更新
            _hexBox.AfterDelete += HexBox_AfterDelete;

            // Paste前の確認
            _hexBox.BeforePaste += HexBox_BeforePaste;

            // Paste後のステータス更新
            _hexBox.AfterPaste += HexBox_AfterPaste;

            this.Controls.Add(_hexBox);
        }

        // ============================================================
        // イベントハンドラ
        // ============================================================

        private void HexBox_BeforeDelete(object sender, DeleteEventArgs e)
        {
            // 1KB以上の削除は確認ダイアログを表示
            if (e.Length > 1024)
            {
                var result = MessageBox.Show(
                    string.Format("{0} バイトを削除しますか？", e.Length),
                    "削除の確認",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.No)
                    e.Cancel = true; // 処理中断
            }
        }

        private void HexBox_AfterDelete(object sender, DeleteEventArgs e)
        {
            _statusLabel.Text = string.Format(
                "削除完了: オフセット 0x{0:X8} から {1} バイト ({2}モード)",
                e.Position,
                e.Length,
                _hexBox.DeleteBehavior);
        }

        private void HexBox_BeforePaste(object sender, PasteEventArgs e)
        {
            // 必要に応じてペースト前の検証を実装
            // 例: e.Cancel = true; で中断可能
        }

        private void HexBox_AfterPaste(object sender, PasteEventArgs e)
        {
            _statusLabel.Text = string.Format(
                "ペースト完了: オフセット 0x{0:X8} へ {1} バイト ({2}モード)",
                e.Position,
                e.Data.Length,
                _hexBox.PasteBehavior);
        }

        // ============================================================
        // サンプルデータのロード
        // ============================================================

        private void LoadSampleData()
        {
            // サンプル: 256バイトのデータをロード
            byte[] sampleData = new byte[256];
            for (int i = 0; i < sampleData.Length; i++)
                sampleData[i] = (byte)i;

            _hexBox.ByteProvider = new DynamicByteProvider(sampleData);
        }

        // ============================================================
        // ToolStripメニューのハンドラ（モード切り替え）
        // ============================================================

        private void btnDeleteFillZero_Click(object sender, EventArgs e)
        {
            _hexBox.DeleteBehavior = DeleteMode.FillZero;
            _statusLabel.Text = "Deleteモード: FillZero (0x00で埋め)";
        }

        private void btnDeleteShrink_Click(object sender, EventArgs e)
        {
            _hexBox.DeleteBehavior = DeleteMode.Shrink;
            _statusLabel.Text = "Deleteモード: Shrink (データを詰める)";
        }

        private void btnPasteOverwrite_Click(object sender, EventArgs e)
        {
            _hexBox.PasteBehavior = PasteMode.Overwrite;
            _statusLabel.Text = "Pasteモード: Overwrite (上書き)";
        }

        private void btnPasteInsert_Click(object sender, EventArgs e)
        {
            _hexBox.PasteBehavior = PasteMode.Insert;
            _statusLabel.Text = "Pasteモード: Insert (挿入)";
        }
    }
}
