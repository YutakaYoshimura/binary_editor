using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace CustomHexBoxProject.Converters
{
    /// <summary>
    /// クリップボードのテキストをバイト配列に変換するユーティリティクラス。
    /// HEX文字列（スペース区切り、コロン区切り、連続など）に対応します。
    /// </summary>
    public static class ClipboardConverter
    {
        // HEXトークンを抽出する正規表現（2桁の16進数）
        private static readonly Regex HexTokenRegex =
            new Regex(@"\b([0-9A-Fa-f]{2})\b", RegexOptions.Compiled);

        // 純粋なHEX文字列（スペース・区切りなし）の判定
        private static readonly Regex PureHexRegex =
            new Regex(@"^[0-9A-Fa-f]+$", RegexOptions.Compiled);

        /// <summary>
        /// 文字列をHEX形式として解析し、バイト配列への変換を試みます。
        /// </summary>
        /// <param name="text">解析対象の文字列</param>
        /// <param name="bytes">変換結果のバイト配列（失敗時はnull）</param>
        /// <returns>変換成功の場合true</returns>
        public static bool TryParseHex(string text, out byte[] bytes)
        {
            bytes = null;

            if (string.IsNullOrEmpty(text)) return false;

            string trimmed = text.Trim();

            // パターン1: 純粋なHEX連続文字列（例: "DEADBEEF"）
            if (PureHexRegex.IsMatch(trimmed) && trimmed.Length % 2 == 0)
            {
                bytes = ParsePureHex(trimmed);
                return bytes != null;
            }

            // パターン2: 区切り文字ありHEX（例: "DE AD BE EF" / "DE:AD:BE:EF"）
            var matches = HexTokenRegex.Matches(trimmed);
            if (matches.Count > 0)
            {
                var list = new List<byte>();
                foreach (Match m in matches)
                {
                    list.Add(Convert.ToByte(m.Value, 16));
                }
                bytes = list.ToArray();
                return true;
            }

            return false;
        }

        /// <summary>
        /// スペースなしのHEX文字列を2文字ずつ分割してバイト配列に変換します。
        /// </summary>
        private static byte[] ParsePureHex(string hex)
        {
            try
            {
                byte[] result = new byte[hex.Length / 2];
                for (int i = 0; i < result.Length; i++)
                {
                    result[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
                }
                return result;
            }
            catch
            {
                return null;
            }
        }
    }
}
