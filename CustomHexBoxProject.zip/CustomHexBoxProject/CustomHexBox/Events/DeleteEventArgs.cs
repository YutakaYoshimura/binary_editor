using System;

namespace CustomHexBoxProject.Events
{
    /// <summary>
    /// Delete処理のイベント引数クラス。
    /// BeforeDeleteイベントでCancelをtrueにすると処理を中断できます。
    /// </summary>
    public class DeleteEventArgs : EventArgs
    {
        /// <summary>削除開始位置（バイトオフセット）</summary>
        public long Position { get; }

        /// <summary>削除バイト数</summary>
        public long Length { get; }

        /// <summary>
        /// trueに設定するとDelete処理を中断します（BeforeDeleteイベントでのみ有効）。
        /// </summary>
        public bool Cancel { get; set; }

        /// <summary>
        /// DeleteEventArgsを初期化します。
        /// </summary>
        /// <param name="position">削除開始位置</param>
        /// <param name="length">削除バイト数</param>
        public DeleteEventArgs(long position, long length)
        {
            Position = position;
            Length   = length;
            Cancel   = false;
        }
    }
}
