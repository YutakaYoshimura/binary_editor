using System;

namespace CustomHexBoxProject.Events
{
    /// <summary>
    /// Paste処理のイベント引数クラス。
    /// BeforePasteイベントでCancelをtrueにすると処理を中断できます。
    /// </summary>
    public class PasteEventArgs : EventArgs
    {
        /// <summary>ペースト開始位置（バイトオフセット）</summary>
        public long Position { get; }

        /// <summary>ペーストするバイトデータ</summary>
        public byte[] Data { get; }

        /// <summary>
        /// trueに設定するとPaste処理を中断します（BeforePasteイベントでのみ有効）。
        /// </summary>
        public bool Cancel { get; set; }

        /// <summary>
        /// PasteEventArgsを初期化します。
        /// </summary>
        /// <param name="position">ペースト開始位置</param>
        /// <param name="data">ペーストするバイトデータ</param>
        public PasteEventArgs(long position, byte[] data)
        {
            Position = position;
            Data     = data;
            Cancel   = false;
        }
    }
}
