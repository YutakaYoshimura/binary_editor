using System;
using System.Windows.Forms;
using Be.Windows.Forms;
using CustomHexBoxProject.Converters;
using CustomHexBoxProject.Events;
using CustomHexBoxProject.Strategies.Delete;
using CustomHexBoxProject.Strategies.Paste;

namespace CustomHexBoxProject
{
    /// <summary>
    /// Be.HexBoxを継承したカスタムバイナリエディタコントロール。
    /// DeleteキーおよびPaste（Ctrl+V）の動作を独自実装で上書きします。
    /// </summary>
    public class CustomHexBox : HexBox
    {
        // ============================================================
        // イベント
        // ============================================================

        /// <summary>Delete処理の実行前に発生します。Cancelをtrueにすると処理を中断できます。</summary>
        public event EventHandler<DeleteEventArgs> BeforeDelete;

        /// <summary>Delete処理の実行後に発生します。</summary>
        public event EventHandler<DeleteEventArgs> AfterDelete;

        /// <summary>Paste処理の実行前に発生します。Cancelをtrueにすると処理を中断できます。</summary>
        public event EventHandler<PasteEventArgs> BeforePaste;

        /// <summary>Paste処理の実行後に発生します。</summary>
        public event EventHandler<PasteEventArgs> AfterPaste;

        // ============================================================
        // プロパティ
        // ============================================================

        /// <summary>
        /// Deleteキー押下時の動作モードを取得または設定します。
        /// <list type="bullet">
        ///   <item><see cref="DeleteMode.FillZero"/> : 選択範囲を 0x00 で埋めます（デフォルト）</item>
        ///   <item><see cref="DeleteMode.Shrink"/>   : 選択範囲のバイトを削除してデータを詰めます</item>
        /// </list>
        /// </summary>
        public DeleteMode DeleteBehavior { get; set; } = DeleteMode.FillZero;

        /// <summary>
        /// Ctrl+V（ペースト）時の動作モードを取得または設定します。
        /// <list type="bullet">
        ///   <item><see cref="PasteMode.Overwrite"/> : カーソル位置から上書きします（デフォルト）</item>
        ///   <item><see cref="PasteMode.Insert"/>    : カーソル位置にバイトを挿入します</item>
        /// </list>
        /// </summary>
        public PasteMode PasteBehavior { get; set; } = PasteMode.Overwrite;

        // ============================================================
        // キー入力の横取り
        // ============================================================

        /// <summary>
        /// WinForms のキー処理フック。DeleteキーおよびCtrl+Vを独自処理に切り替えます。
        /// </summary>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Delete:
                    HandleDelete();
                    return true; // 基底クラスのDelete処理をキャンセル

                case Keys.Control | Keys.V:
                    HandlePaste();
                    return true; // 基底クラスのPaste処理をキャンセル
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        // ============================================================
        // カスタムDelete処理
        // ============================================================

        /// <summary>
        /// Deleteキー押下時のカスタム処理。
        /// BeforeDeleteイベントでキャンセル可能。
        /// DeleteBehaviorプロパティで動作モードを切り替えます。
        /// </summary>
        private void HandleDelete()
        {
            if (ByteProvider == null) return;
            if (SelectionLength <= 0) return;

            var args = new DeleteEventArgs(SelectionStart, SelectionLength);

            // Before イベント（キャンセル可能）
            BeforeDelete?.Invoke(this, args);
            if (args.Cancel) return;

            // 戦略パターンで処理を実行
            IDeleteStrategy strategy = DeleteStrategyFactory.Create(DeleteBehavior);
            strategy.Execute(ByteProvider, SelectionStart, SelectionLength);

            // After イベント
            AfterDelete?.Invoke(this, args);

            Invalidate(); // 再描画
        }

        // ============================================================
        // カスタムPaste処理
        // ============================================================

        /// <summary>
        /// Ctrl+V 押下時のカスタムPaste処理。
        /// BeforePasteイベントでキャンセル可能。
        /// PasteBehaviorプロパティで動作モードを切り替えます。
        /// クリップボードの内容はHEX文字列またはバイナリデータに対応します。
        /// </summary>
        private void HandlePaste()
        {
            if (ByteProvider == null) return;

            byte[] pasteData = GetClipboardBytes();
            if (pasteData == null || pasteData.Length == 0) return;

            var args = new PasteEventArgs(SelectionStart, pasteData);

            // Before イベント（キャンセル可能）
            BeforePaste?.Invoke(this, args);
            if (args.Cancel) return;

            // 戦略パターンで処理を実行
            IPasteStrategy strategy = PasteStrategyFactory.Create(PasteBehavior);
            strategy.Execute(ByteProvider, SelectionStart, pasteData);

            // After イベント
            AfterPaste?.Invoke(this, args);

            Invalidate(); // 再描画
        }

        // ============================================================
        // クリップボードデータの取得
        // ============================================================

        /// <summary>
        /// クリップボードからバイト配列を取得します。
        /// 優先順位: バイナリデータ → HEX文字列 → テキスト（エンコード変換）
        /// </summary>
        private byte[] GetClipboardBytes()
        {
            // 1. バイナリデータが直接存在する場合
            if (Clipboard.ContainsData("BinaryData"))
            {
                return Clipboard.GetData("BinaryData") as byte[];
            }

            // 2. テキスト形式の場合（HEX文字列 or 通常テキスト）
            if (Clipboard.ContainsText())
            {
                string text = Clipboard.GetText();

                // HEX文字列としてパース試行
                if (ClipboardConverter.TryParseHex(text, out byte[] hexBytes))
                    return hexBytes;

                // 通常テキストとしてバイト変換
                return System.Text.Encoding.Default.GetBytes(text);
            }

            return null;
        }
    }
}
