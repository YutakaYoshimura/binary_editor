using Be.Windows.Forms;

namespace CustomHexBoxProject.Strategies.Delete
{
    /// <summary>
    /// Delete処理の戦略インターフェース。
    /// 新しい削除動作を追加する場合はこのインターフェースを実装してください。
    /// </summary>
    public interface IDeleteStrategy
    {
        /// <summary>
        /// Delete処理を実行します。
        /// </summary>
        /// <param name="provider">操作対象のバイトプロバイダー</param>
        /// <param name="start">削除開始位置（バイトオフセット）</param>
        /// <param name="length">削除バイト数</param>
        void Execute(IByteProvider provider, long start, long length);
    }
}
