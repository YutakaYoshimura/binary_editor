using System;

namespace CustomHexBoxProject.Strategies.Delete
{
    /// <summary>
    /// DeleteModeに対応するIDeleteStrategyを生成するファクトリクラス。
    /// 新しいDeleteModeを追加した場合は、このクラスにも対応するcaseを追加してください。
    /// </summary>
    public static class DeleteStrategyFactory
    {
        /// <summary>
        /// 指定されたモードに対応する削除戦略を返します。
        /// </summary>
        /// <param name="mode">削除モード</param>
        /// <returns>対応するIDeleteStrategyの実装</returns>
        /// <exception cref="ArgumentOutOfRangeException">未定義のモードが指定された場合</exception>
        public static IDeleteStrategy Create(DeleteMode mode)
        {
            switch (mode)
            {
                case DeleteMode.FillZero:
                    return new FillZeroDeleteStrategy();

                case DeleteMode.Shrink:
                    return new ShrinkDeleteStrategy();

                default:
                    throw new ArgumentOutOfRangeException("mode",
                        string.Format("未定義のDeleteModeです: {0}", mode));
            }
        }
    }
}
