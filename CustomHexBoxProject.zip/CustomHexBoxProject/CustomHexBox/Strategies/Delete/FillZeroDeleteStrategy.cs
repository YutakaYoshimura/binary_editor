using Be.Windows.Forms;

namespace CustomHexBoxProject.Strategies.Delete
{
    /// <summary>
    /// 選択範囲のバイトを 0x00 で上書きするDelete戦略。
    /// ファイルサイズは変化しません。
    /// </summary>
    public class FillZeroDeleteStrategy : IDeleteStrategy
    {
        /// <summary>
        /// 指定範囲のバイトをすべて 0x00 で上書きします。
        /// </summary>
        /// <param name="provider">操作対象のバイトプロバイダー</param>
        /// <param name="start">開始位置（バイトオフセット）</param>
        /// <param name="length">対象バイト数</param>
        public void Execute(IByteProvider provider, long start, long length)
        {
            for (long i = start; i < start + length; i++)
            {
                provider.WriteByte(i, 0x00);
            }
        }
    }
}
