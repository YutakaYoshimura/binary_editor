namespace CustomHexBoxProject.Strategies.Delete
{
    /// <summary>
    /// Deleteキー押下時の動作モードを定義します。
    /// </summary>
    public enum DeleteMode
    {
        /// <summary>選択範囲のバイトを 0x00 で上書きします（ファイルサイズ不変）。</summary>
        FillZero,

        /// <summary>選択範囲のバイトを削除し、後続データを前に詰めます（ファイルサイズ縮小）。</summary>
        Shrink
    }
}
