using Be.Windows.Forms;

namespace CustomHexBoxProject.Strategies.Delete
{
    /// <summary>
    /// 選択範囲のバイトを削除し、後続データを前に詰めるDelete戦略。
    /// ファイルサイズが削除バイト数分だけ縮小します。
    /// IByteProviderがDynamicByteProviderなど削除対応である必要があります。
    /// </summary>
    public class ShrinkDeleteStrategy : IDeleteStrategy
    {
        /// <summary>
        /// 指定範囲のバイトを先頭から1バイトずつ削除します。
        /// </summary>
        /// <param name="provider">操作対象のバイトプロバイダー（削除サポート必須）</param>
        /// <param name="start">開始位置（バイトオフセット）</param>
        /// <param name="length">削除バイト数</param>
        public void Execute(IByteProvider provider, long start, long length)
        {
            // DeleteBytesをサポートしているか確認
            if (!provider.SupportsDeleteBytes())
            {
                // 削除非対応の場合はFillZeroにフォールバック
                for (long i = start; i < start + length; i++)
                    provider.WriteByte(i, 0x00);
                return;
            }

            for (long i = 0; i < length; i++)
            {
                // 同じ位置を繰り返し削除することで詰めていく
                provider.DeleteBytes(start, 1);
            }
        }
    }
}
