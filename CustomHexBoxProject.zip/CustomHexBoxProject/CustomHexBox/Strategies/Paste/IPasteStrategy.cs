using Be.Windows.Forms;

namespace CustomHexBoxProject.Strategies.Paste
{
    /// <summary>
    /// Paste処理の戦略インターフェース。
    /// 新しいペースト動作を追加する場合はこのインターフェースを実装してください。
    /// </summary>
    public interface IPasteStrategy
    {
        /// <summary>
        /// Paste処理を実行します。
        /// </summary>
        /// <param name="provider">操作対象のバイトプロバイダー</param>
        /// <param name="start">ペースト開始位置（バイトオフセット）</param>
        /// <param name="data">ペーストするバイトデータ</param>
        void Execute(IByteProvider provider, long start, byte[] data);
    }
}
