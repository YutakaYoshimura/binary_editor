using Be.Windows.Forms;

namespace CustomHexBoxProject.Strategies.Paste
{
    /// <summary>
    /// カーソル位置にデータを挿入するPaste戦略。
    /// 後続データは挿入バイト数分だけ後ろにずれ、ファイルサイズが増加します。
    /// IByteProviderがDynamicByteProviderなど挿入対応である必要があります。
    /// </summary>
    public class InsertPasteStrategy : IPasteStrategy
    {
        /// <summary>
        /// 指定位置にデータを一括挿入します。
        /// </summary>
        /// <param name="provider">操作対象のバイトプロバイダー（挿入サポート必須）</param>
        /// <param name="start">挿入開始位置（バイトオフセット）</param>
        /// <param name="data">ペーストするバイトデータ</param>
        public void Execute(IByteProvider provider, long start, byte[] data)
        {
            // InsertBytesをサポートしているか確認
            if (!provider.SupportsInsertBytes())
            {
                // 挿入非対応の場合はOverwriteにフォールバック
                long capacity = provider.Length;
                for (int i = 0; i < data.Length; i++)
                {
                    long targetPos = start + i;
                    if (targetPos >= capacity) break;
                    provider.WriteByte(targetPos, data[i]);
                }
                return;
            }

            // DynamicByteProviderのInsertBytesは一括挿入に対応
            provider.InsertBytes(start, data);
        }
    }
}
