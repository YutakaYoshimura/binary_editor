using Be.Windows.Forms;

namespace CustomHexBoxProject.Strategies.Paste
{
    /// <summary>
    /// カーソル位置から既存データに上書きするPaste戦略。
    /// ファイルサイズは変化しません。
    /// ペーストデータがファイル末尾を超える場合、末尾で打ち切られます。
    /// </summary>
    public class OverwritePasteStrategy : IPasteStrategy
    {
        /// <summary>
        /// 指定位置からデータを上書きします。
        /// </summary>
        /// <param name="provider">操作対象のバイトプロバイダー</param>
        /// <param name="start">上書き開始位置（バイトオフセット）</param>
        /// <param name="data">ペーストするバイトデータ</param>
        public void Execute(IByteProvider provider, long start, byte[] data)
        {
            long capacity = provider.Length;

            for (int i = 0; i < data.Length; i++)
            {
                long targetPos = start + i;

                // ファイル末尾を超えたら中断
                if (targetPos >= capacity) break;

                provider.WriteByte(targetPos, data[i]);
            }
        }
    }
}
