using System;

namespace CustomHexBoxProject.Strategies.Paste
{
    /// <summary>
    /// PasteModeに対応するIPasteStrategyを生成するファクトリクラス。
    /// 新しいPasteModeを追加した場合は、このクラスにも対応するcaseを追加してください。
    /// </summary>
    public static class PasteStrategyFactory
    {
        /// <summary>
        /// 指定されたモードに対応するペースト戦略を返します。
        /// </summary>
        /// <param name="mode">ペーストモード</param>
        /// <returns>対応するIPasteStrategyの実装</returns>
        /// <exception cref="ArgumentOutOfRangeException">未定義のモードが指定された場合</exception>
        public static IPasteStrategy Create(PasteMode mode)
        {
            switch (mode)
            {
                case PasteMode.Overwrite:
                    return new OverwritePasteStrategy();

                case PasteMode.Insert:
                    return new InsertPasteStrategy();

                default:
                    throw new ArgumentOutOfRangeException("mode",
                        string.Format("未定義のPasteModeです: {0}", mode));
            }
        }
    }
}
