namespace CustomHexBoxProject.Strategies.Paste
{
    /// <summary>
    /// Ctrl+V（ペースト）時の動作モードを定義します。
    /// </summary>
    public enum PasteMode
    {
        /// <summary>カーソル位置から既存データに上書きします（ファイルサイズ不変）。</summary>
        Overwrite,

        /// <summary>カーソル位置にデータを挿入し、後続データを後ろにずらします（ファイルサイズ増加）。</summary>
        Insert
    }
}
