# CustomHexBox プロジェクト

Be.HexBox を継承してDelete・Paste動作をカスタマイズしたバイナリエディタ。

## 動作環境
- C# / .NET Framework 4.0
- Visual Studio 2019
- WinForms
- Be.Windows.Forms.HexBox（NuGet または DLL参照）

## セットアップ

1. Be.HexBox の DLL を `libs/` フォルダに配置するか、NuGet でインストール
2. `.csproj` の `<HintPath>` を実際のパスに合わせて修正
3. Visual Studio でソリューションを開いてビルド

## プロジェクト構成

```
CustomHexBox/
├── CustomHexBox.cs                    # メインの継承クラス
├── Events/
│   ├── DeleteEventArgs.cs             # Delete処理のイベント引数
│   └── PasteEventArgs.cs             # Paste処理のイベント引数
├── Strategies/
│   ├── Delete/
│   │   ├── DeleteMode.cs              # 削除モードのEnum
│   │   ├── IDeleteStrategy.cs         # 削除戦略インターフェース
│   │   ├── DeleteStrategyFactory.cs   # ファクトリ
│   │   ├── FillZeroDeleteStrategy.cs  # 0x00埋め実装
│   │   └── ShrinkDeleteStrategy.cs    # データ詰め実装
│   └── Paste/
│       ├── PasteMode.cs               # ペーストモードのEnum
│       ├── IPasteStrategy.cs          # ペースト戦略インターフェース
│       ├── PasteStrategyFactory.cs    # ファクトリ
│       ├── OverwritePasteStrategy.cs  # 上書き実装
│       └── InsertPasteStrategy.cs     # 挿入実装
├── Converters/
│   └── ClipboardConverter.cs          # HEX文字列パーサー
├── MainForm.cs / .Designer.cs         # サンプルフォーム
└── Program.cs                         # エントリポイント
```

## 使い方

```csharp
var hexBox = new CustomHexBox
{
    DeleteBehavior = DeleteMode.FillZero,  // or Shrink
    PasteBehavior  = PasteMode.Overwrite,  // or Insert
};

// Delete前に処理を割り込む（Cancelで中断可能）
hexBox.BeforeDelete += (s, e) => {
    if (e.Length > 1024) e.Cancel = true;
};

// Paste後にステータス更新
hexBox.AfterPaste += (s, e) => {
    Console.WriteLine($"{e.Data.Length}バイトをペーストしました");
};
```

## 新しい動作モードの追加方法

1. `DeleteMode` または `PasteMode` に新しいEnum値を追加
2. `IDeleteStrategy` または `IPasteStrategy` を実装したクラスを作成
3. 対応するFactoryクラスに `case` を追加

**CustomHexBox本体は修正不要です。**
