namespace TreeViewIconSample;

internal static class Program
{
    /// <summary>
    /// アプリケーションのエントリーポイント
    /// </summary>
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new Form1());
    }
}
