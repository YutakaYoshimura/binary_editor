namespace TreeViewIconSample;

/// <summary>
/// TreeView + ImageList でアイコン表示を行うサンプルフォーム。
/// ・フォルダー(閉じる/開く)でアイコンを切り替える
/// ・ファイル、お気に入り(星)、警告などノードごとに異なるアイコンを割り当てる
/// </summary>
public partial class Form1 : Form
{
    // ImageList内のインデックスを定数化しておくと可読性が上がる
    private const int IconFolderClosed = 0;
    private const int IconFolderOpen = 1;
    private const int IconFile = 2;
    private const int IconStar = 3;
    private const int IconWarning = 4;

    private readonly TreeView _treeView;
    private readonly ImageList _imageList;
    private readonly Label _infoLabel;

    public Form1()
    {
        Text = "TreeView アイコン表示サンプル";
        Width = 480;
        Height = 520;
        StartPosition = FormStartPosition.CenterScreen;

        // ---- ImageList の準備 ----
        _imageList = new ImageList
        {
            ImageSize = new Size(16, 16),
            ColorDepth = ColorDepth.Depth32Bit
        };
        _imageList.Images.Add(CreateFolderIcon(open: false));
        _imageList.Images.Add(CreateFolderIcon(open: true));
        _imageList.Images.Add(CreateFileIcon());
        _imageList.Images.Add(CreateStarIcon());
        _imageList.Images.Add(CreateWarningIcon());

        // ---- TreeView の準備 ----
        _treeView = new TreeView
        {
            Dock = DockStyle.Fill,
            ImageList = _imageList,
            // ノードごとに ImageIndex を指定しない場合のデフォルト値
            ImageIndex = IconFolderClosed,
            SelectedImageIndex = IconFolderOpen,
            ShowNodeToolTips = true
        };

        _infoLabel = new Label
        {
            Dock = DockStyle.Bottom,
            Height = 28,
            TextAlign = ContentAlignment.MiddleLeft,
            Text = "ノードをクリックすると詳細が表示されます。"
        };

        Controls.Add(_treeView);
        Controls.Add(_infoLabel);

        BuildSampleTree();

        // フォルダーを開閉したときにアイコンを切り替えるイベント
        _treeView.BeforeExpand += TreeView_BeforeExpand;
        _treeView.BeforeCollapse += TreeView_BeforeCollapse;
        _treeView.AfterSelect += TreeView_AfterSelect;

        _treeView.ExpandAll();
    }

    /// <summary>
    /// サンプル用のツリー構造を組み立てる
    /// </summary>
    private void BuildSampleTree()
    {
        // ルート: ドキュメント(フォルダー)
        var docsNode = new TreeNode("ドキュメント")
        {
            ImageIndex = IconFolderClosed,
            SelectedImageIndex = IconFolderOpen,
            ToolTipText = "資料をまとめたフォルダーです"
        };
        docsNode.Nodes.Add(CreateFileNode("議事録.docx"));
        docsNode.Nodes.Add(CreateFileNode("仕様書.docx"));

        var subFolder = new TreeNode("旧バージョン")
        {
            ImageIndex = IconFolderClosed,
            SelectedImageIndex = IconFolderOpen
        };
        subFolder.Nodes.Add(CreateFileNode("仕様書_v1.docx"));
        subFolder.Nodes.Add(CreateWarningNode("破損ファイル.docx", "このファイルは開けない可能性があります"));
        docsNode.Nodes.Add(subFolder);

        // ルート: お気に入り(フォルダー)
        var favNode = new TreeNode("お気に入り")
        {
            ImageIndex = IconFolderClosed,
            SelectedImageIndex = IconFolderOpen
        };
        favNode.Nodes.Add(CreateStarNode("重要な提案書.pptx"));
        favNode.Nodes.Add(CreateStarNode("契約書.pdf"));

        // ルート: 画像(フォルダー・空)
        var imagesNode = new TreeNode("画像")
        {
            ImageIndex = IconFolderClosed,
            SelectedImageIndex = IconFolderOpen
        };
        imagesNode.Nodes.Add(CreateFileNode("logo.png"));
        imagesNode.Nodes.Add(CreateFileNode("photo.jpg"));

        _treeView.Nodes.Add(docsNode);
        _treeView.Nodes.Add(favNode);
        _treeView.Nodes.Add(imagesNode);
    }

    private static TreeNode CreateFileNode(string name) => new(name)
    {
        ImageIndex = IconFile,
        SelectedImageIndex = IconFile
    };

    private static TreeNode CreateStarNode(string name) => new(name)
    {
        ImageIndex = IconStar,
        SelectedImageIndex = IconStar,
        ToolTipText = "お気に入りに登録されています"
    };

    private static TreeNode CreateWarningNode(string name, string tooltip) => new(name)
    {
        ImageIndex = IconWarning,
        SelectedImageIndex = IconWarning,
        ToolTipText = tooltip
    };

    /// <summary>
    /// フォルダーを展開したときに「開いたフォルダー」アイコンへ切り替える
    /// </summary>
    private void TreeView_BeforeExpand(object? sender, TreeViewCancelEventArgs e)
    {
        if (e.Node is { ImageIndex: IconFolderClosed })
        {
            e.Node.ImageIndex = IconFolderOpen;
            e.Node.SelectedImageIndex = IconFolderOpen;
        }
    }

    /// <summary>
    /// フォルダーを折りたたんだときに「閉じたフォルダー」アイコンへ戻す
    /// </summary>
    private void TreeView_BeforeCollapse(object? sender, TreeViewCancelEventArgs e)
    {
        if (e.Node is { ImageIndex: IconFolderOpen })
        {
            e.Node.ImageIndex = IconFolderClosed;
            e.Node.SelectedImageIndex = IconFolderClosed;
        }
    }

    private void TreeView_AfterSelect(object? sender, TreeViewEventArgs e)
    {
        var node = e.Node;
        if (node == null) return;

        string kind = node.ImageIndex switch
        {
            IconFolderClosed or IconFolderOpen => "フォルダー",
            IconStar => "お気に入りファイル",
            IconWarning => "警告ファイル",
            _ => "ファイル"
        };

        _infoLabel.Text = $"選択中: 「{node.Text}」 種類: {kind}";
    }

    // ------------------------------------------------------------
    // 以下、外部の画像ファイルを使わずコードだけでアイコンを描画する処理。
    // 実際のプロジェクトでは Properties.Resources や png ファイルを
    // ImageList に読み込む方法でも構いません。
    // ------------------------------------------------------------

    private static Bitmap CreateFolderIcon(bool open)
    {
        var bmp = new Bitmap(16, 16);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        Color body = Color.FromArgb(255, 222, 170, 60);
        Color tab = Color.FromArgb(255, 200, 145, 40);

        // フォルダーのつまみ部分
        g.FillRectangle(new SolidBrush(tab), 1, 3, 6, 3);
        if (open)
        {
            // 開いている見た目: 少し斜めにしたフタを描く
            g.FillPolygon(new SolidBrush(body), new PointF[]
            {
                new(1, 6), new(15, 6), new(13, 14), new(0, 14)
            });
            g.FillPolygon(new SolidBrush(Color.FromArgb(255, 245, 200, 100)), new PointF[]
            {
                new(2, 5), new(14, 5), new(12, 11), new(2, 11)
            });
        }
        else
        {
            g.FillRectangle(new SolidBrush(body), 1, 6, 14, 8);
        }

        g.DrawRectangle(Pens.SaddleBrown, 0, 5, 15, 9);
        return bmp;
    }

    private static Bitmap CreateFileIcon()
    {
        var bmp = new Bitmap(16, 16);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        var body = new Rectangle(3, 1, 10, 14);
        g.FillRectangle(Brushes.WhiteSmoke, body);
        g.DrawRectangle(Pens.Gray, body);

        // 折れ線(テキスト行)を数本描く
        using var linePen = new Pen(Color.LightSlateGray);
        for (int y = 4; y <= 11; y += 3)
        {
            g.DrawLine(linePen, 5, y, 11, y);
        }
        return bmp;
    }

    private static Bitmap CreateStarIcon()
    {
        var bmp = new Bitmap(16, 16);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        PointF[] star = BuildStarPoints(new PointF(8, 8), 7, 3);
        g.FillPolygon(Brushes.Gold, star);
        g.DrawPolygon(Pens.DarkGoldenrod, star);
        return bmp;
    }

    private static Bitmap CreateWarningIcon()
    {
        var bmp = new Bitmap(16, 16);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        PointF[] triangle = { new(8, 1), new(15, 14), new(1, 14) };
        g.FillPolygon(Brushes.Gold, triangle);
        g.DrawPolygon(Pens.DarkOrange, triangle);

        using var font = new Font("Arial", 9, FontStyle.Bold);
        g.DrawString("!", font, Brushes.Black, 5.5f, 4.5f);
        return bmp;
    }

    private static PointF[] BuildStarPoints(PointF center, float outerRadius, float innerRadius)
    {
        var points = new PointF[10];
        for (int i = 0; i < 10; i++)
        {
            double angle = Math.PI / 2 * 3 + i * Math.PI / 5;
            float radius = (i % 2 == 0) ? outerRadius : innerRadius;
            points[i] = new PointF(
                center.X + radius * (float)Math.Cos(angle),
                center.Y + radius * (float)Math.Sin(angle));
        }
        return points;
    }
}
